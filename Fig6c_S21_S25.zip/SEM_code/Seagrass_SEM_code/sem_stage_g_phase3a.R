#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr)
  library(lavaan); library(furrr); library(future)
})
ROOT <- "/Fig6"
DATA_IN <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
PH2_CSV <- file.path(ROOT, "phase2_sr_pair_C3skeleton_results.csv")
OUT_CSV <- file.path(ROOT, "phase3a_qualified6_ModelA_results.csv")
Q_CSV   <- file.path(ROOT, "phase2_qualified6_pairs.csv")

dat <- read_csv(DATA_IN, show_col_types = FALSE)
ph2 <- read_csv(PH2_CSV, show_col_types = FALSE)
qual <- ph2 %>% filter(pvalue >= 0.10, cfi >= 0.95, srmr <= 0.08,
                       rmsea <= 0.06, sr1_p < 0.05, sr2_p < 0.05) %>%
  arrange(desc(pvalue), srmr) %>%
  transmute(sr1, sr2, ph2_pvalue = pvalue, ph2_cfi = cfi,
            ph2_srmr = srmr, ph2_wrmr = wrmr)
write_csv(qual, Q_CSV)
cat(sprintf("[Phase3a] Qualified pairs (from Phase 2): %d\n", nrow(qual)))
print(qual)

DOWN <- c("B_Desulfobulbaceae",
          "B_bacterium_enrichment_culture_clone_22_2013",
          "E_Intramacronucleata",
          "B_uncultured_Aminicenantes_bacterium",
          "chemical_NO3_N_log","chemical_CEC_log","chemical_K2O_log")

fit_one <- function(sr1, sr2, dat) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  mod <- '
    Seagrass ~ .SR1 + .SR2
    B_Desulfobulbaceae + B_bacterium_enrichment_culture_clone_22_2013 +
    E_Intramacronucleata + B_uncultured_Aminicenantes_bacterium +
    chemical_NO3_N_log + chemical_CEC_log + chemical_K2O_log ~ Seagrass
  '
  tryCatch({
    fit <- lavaan::sem(mod, data=d, ordered="Seagrass", estimator="WLSMV", se="robust")
    fm <- lavaan::fitMeasures(fit, c("chisq.scaled","df","pvalue.scaled",
            "cfi.scaled","tli.scaled","rmsea.scaled","srmr","wrmr","gfi","agfi"))
    pe <- lavaan::parameterEstimates(fit, standardized=TRUE)
    getp <- function(lhs, rhs) {
      r <- pe[pe$lhs==lhs & pe$op=="~" & pe$rhs==rhs, ]
      if (nrow(r)==0) c(NA,NA) else c(r$std.all[1], r$pvalue[1])
    }
    b1 <- getp("Seagrass",".SR1"); b2 <- getp("Seagrass",".SR2")
    out <- tibble(sr1=sr1, sr2=sr2,
           converged=lavaan::lavInspect(fit,"converged"),
           chisq=unname(fm["chisq.scaled"]), df=unname(fm["df"]),
           pvalue=unname(fm["pvalue.scaled"]),
           cfi=unname(fm["cfi.scaled"]), tli=unname(fm["tli.scaled"]),
           rmsea=unname(fm["rmsea.scaled"]),
           srmr=unname(fm["srmr"]), wrmr=unname(fm["wrmr"]),
           gfi=unname(fm["gfi"]), agfi=unname(fm["agfi"]),
           sr1_std=b1[1], sr1_p=b1[2], sr2_std=b2[1], sr2_p=b2[2])
    for (nm in DOWN) {
      v <- getp(nm, "Seagrass")
      out[[paste0(nm,"_std")]] <- v[1]; out[[paste0(nm,"_p")]] <- v[2]
    }
    out$error <- NA_character_; out
  }, error=function(e) tibble(sr1=sr1, sr2=sr2, converged=FALSE,
                              error=conditionMessage(e)))
}

plan(multisession, workers = 24)
cat("\n[Phase3a] Fitting 6 Model-A SEMs (df=14)...\n")
t0 <- Sys.time()
res <- future_map2_dfr(qual$sr1, qual$sr2, ~ fit_one(.x,.y,dat),
         .options=furrr_options(seed=TRUE), .progress=TRUE)
cat(sprintf("[Phase3a] Done in %.1f sec\n", as.numeric(Sys.time()-t0,units="secs")))

res <- res %>% left_join(qual, by=c("sr1","sr2")) %>% arrange(desc(pvalue), srmr)
write_csv(res, OUT_CSV)
cat("[Phase3a] Wrote -> ", OUT_CSV, "\n", sep="")

cat("\n[Phase3a] Ranked (Model A, df=14). Prev Model A benchmark: p=0.852, cfi=1.000, srmr=0.067\n")
print(res %>% select(sr1, sr2, pvalue, cfi, tli, rmsea, srmr, wrmr,
                     sr1_std, sr1_p, sr2_std, sr2_p,
                     ph2_pvalue, ph2_srmr), n=10, width=Inf)

cat("\n[Phase3a] Downstream path significance (std, p) by pair:\n")
lab <- c("Desulfo","bact22","Intra","Amini","NO3","CEC","K2O")
for (i in seq_len(nrow(res))) {
  cat(sprintf("\n[%d] %s x %s  (Model A pvalue=%.3f, srmr=%.3f)\n",
              i, res$sr1[i], res$sr2[i], res$pvalue[i], res$srmr[i]))
  for (j in seq_along(DOWN)) {
    s <- res[[paste0(DOWN[j],"_std")]][i]; p <- res[[paste0(DOWN[j],"_p")]][i]
    flag <- ifelse(!is.na(p) && p < 0.05, "*", " ")
    cat(sprintf("    %s %-8s std=%+.3f p=%.4f\n", flag, lab[j], s, p))
  }
}
cat("\n=== Phase 3a complete ===\n")

    #! /bin/sh



#####Qiime2によるプロセス#####
### MiSeqのアウトプットをこのスクリプトを置いたディレクトリ上に置いた「reads」ディレクトリに置く
### このスクリプトを置いたディレクトリ上にカレントディレクトリを移動して実行
###
### 必要なもの
##### 1．readsフォルダ（シーケンスデータファイルを改名せずに解凍もせずにそのまま入れる・使わない配列やファイルは入れないこと）
##### 2．sample-metadata.tsv（サンプル名や実験区などを記載したデータ。名前を変えないこと。サンプル名はシーケンスデータファイル名の付いている固有ID部分（シーケンス時に入力したもの）
##### 3．このスクリプト
### 以上を同じディレクトリ（フォルダ）にいれ、Terminal上でそのディレクトリにcdコマンドで移動しておく


#QIIME2環境に入る：これは手動で実行する・以下の先頭の#を除いたコマンドを実行
conda activate qiime2-2021.4


#ここ以下はスクリプトとして自動実行可能（このスクリプトは必ずreadsのあるディレクトリにcdコマンドで移動して実行する）

#実行権限を付与する
#chmod u+x /Full/path/to/working/directory/02_qiime2_pipeline_16S_V3V4.sh

#実行する（逐次結果が表示される形式）
#/Full/path/to/working/directory/02_qiime2_pipeline_16S_V3V4.sh

#または以下を実行する（バックグラウンドで実行・エラーなどは作業ディレクトリに保存される 02_log.txt か 02_err.txt ファイルに書き込まれる）
#nohup /Full/path/to/working/directory/02_qiime2_pipeline_16S_V3V4.sh > 02_log.txt 2> 02_err.txt &

#なお「/Full/path/to/working/directory/」はスクリプトのパス（スクリプトファイルをTerminalにドラッグドロップすると自動で入力される）

#スクリプトとして自動実行せず、以下のコマンド（改行無く続いているものがひとまとまりのコマンド）を逐次コピペで実行していってもよい
#以下のコマンドはプライマーセットの配列が異なる場合を除いて書き換える必要はありません
#（自動実行ではエラーが出る場合等で、原因を突き止めたい場合など）


#配列の導入：今作業しているディレクトリにある「reads」フォルダから自動的に配列を読み込む
qiime tools import \
  --type 'SampleData[PairedEndSequencesWithQuality]' \
  --input-path ./reads \
  --input-format CasavaOneEightSingleLanePerSampleDirFmt \
  --output-path ./demux-paired-end.qza



#Primerの除去
#FW (BacV3_V4_F_Illumina_Dual (Read1 side)) : CCTACGGGNGGCWGCAG (comp.seq.: CTGCWGCCNCCCGTAGG)
#RV (BacV3_V4_R_Illumina_Dual (Read2 side)) : GACTACHVGGGTATCTAATCC (comp.seq.: GGATTAGATACCCVHGTAGTC)
#上と異なるプライマーを使用している場合、下の各パラメーターは以下の通りの配列を入力しておくこと
#--p-adapter-f : Read1の3'末のアダプタ配列（この場合BacV3_V4_R_Illumina_Dualの相補鎖...突き抜け対策）。それ以降の配列も除去される
#--p-front-f : Read1の5'末のアダプタ配列（この場合BacV3_V4_F_Illumina_Dual）。それ以前の配列も除去される
#--p-adapter-r : Read2の3'末のアダプタ配列（この場合BacV3_V4_F_Illumina_Dualの相補鎖...突き抜け対策）。それ以降の配列も除去される
#--p-front-r :  Read2の5'末のアダプタ配列（この場合BacV3_V4_R_Illumina_Dual）。それ以前の配列も除去される

qiime cutadapt trim-paired \
--i-demultiplexed-sequences ./demux-paired-end.qza \
--p-adapter-f GGATTAGATACCCVHGTAGTC \
--p-front-f CCTACGGGNGGCWGCAG \
--p-adapter-r CTGCWGCCNCCCGTAGG \
--p-front-r GACTACHVGGGTATCTAATCC \
--o-trimmed-sequences ./cutadapt-paired-end.qza





#品質管理とマージ
qiime dada2 denoise-paired \
--i-demultiplexed-seqs ./cutadapt-paired-end.qza \
--p-trunc-len-f 0 \
--p-trunc-len-r 0 \
--p-n-threads 4 \
--o-representative-sequences ./rep-seqs.qza \
--o-table ./table.qza \
--o-denoising-stats ./stats.qza



###ここまでの結果の可視化
#品質評価などの結果の可視化
qiime metadata tabulate \
  --m-input-file ./stats.qza \
  --o-visualization ./stats.qzv &

#処理の統計を可読テーブルにする
qiime feature-table summarize \
  --i-table ./table.qza \
  --o-visualization ./table.qzv \
  --m-sample-metadata-file ./sample-metadata.tsv &

#マージされた配列一覧の可視化
qiime feature-table tabulate-seqs \
  --i-data ./rep-seqs.qza \
  --o-visualization ./rep-seqs.qzv &


#Generate a tree for phylogenetic diversity analyses

qiime alignment mafft \
  --i-sequences rep-seqs.qza \
  --o-alignment aligned-rep-seqs.qza

qiime alignment mask \
  --i-alignment aligned-rep-seqs.qza \
  --o-masked-alignment masked-aligned-rep-seqs.qza

qiime phylogeny fasttree \
  --i-alignment masked-aligned-rep-seqs.qza \
  --o-tree unrooted-tree.qza

qiime phylogeny midpoint-root \
  --i-tree unrooted-tree.qza \
  --o-rooted-tree rooted-tree.qza
  
###01_qiime2_clasifier_prep_16S_V3V4.shで作ったClassifierを用いた同定とカウントデータの作成
qiime feature-classifier classify-sklearn \
  --i-classifier ~/software/SILVA_132_QIIME_release/taxonomy/16S_only/99/classifier_V3V4.qza/\
  --i-reads ./rep-seqs.qza \
  --o-classification ./taxonomy_rev.qza

###メタデータに対応したLCAでの種情報の表作成
qiime metadata tabulate \
  --m-input-file ./taxonomy_rev.qza \
  --o-visualization ./taxonomy_rev.qzv

###バープロットの作成・各taxonレベルでのカウントデータの作成
qiime taxa barplot \
  --i-table ./table.qza \
  --i-taxonomy ./taxonomy_rev.qza \
  --m-metadata-file ./sample-metadata.tsv \
  --o-visualization ./taxa-bar-plots.qzv



###加工と加工後のカウントデータの作成（合計カウントが10以下のエントリとミトコン・葉緑体のエントリを除去）
# トータルで１０カウント以下のfeatureをフィルタリング
qiime feature-table filter-features \
--i-table ./table.qza \
--p-min-frequency 10 \
--o-filtered-table ./filtered_table10.qza

qiime feature-table summarize \
--i-table ./filtered_table10.qza \
--o-visualization ./filtered_table10.qzv \
--m-sample-metadata-file ./sample-metadata.tsv

#ミトコンとクロロプラスとのエントリーを除去
qiime taxa filter-table \
--i-table ./filtered_table10.qza \
--i-taxonomy ./taxonomy_rev.qza \
--p-exclude mitochondria,chloroplast \
--o-filtered-table ./filtered_table.qza

qiime feature-table summarize \
--i-table ./filtered_table.qza \
--o-visualization ./filtered-table.qzv \
--m-sample-metadata-file ./sample-metadata.tsv

#加工後データに基づいたバープロットの作成・各taxonレベルでのカウントデータの作成
qiime taxa barplot \
  --i-table ./filtered_table.qza \
  --i-taxonomy ./taxonomy_rev.qza \
  --m-metadata-file ./sample-metadata.tsv \
  --o-visualization ./taxa-bar-plots_rev.qzv



#「https://view.qiime2.org/」でxxx.pzvを可視化出来る














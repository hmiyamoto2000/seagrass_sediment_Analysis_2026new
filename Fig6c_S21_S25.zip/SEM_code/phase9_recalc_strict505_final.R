#!/usr/bin/env Rscript
# =============================================================
# Recalculate downstream path summary for 505 strict models
# Run from: SEM folder
# Usage: Rscript phase9_recalc_strict505.R
# =============================================================

library(readr); library(dplyr); library(lavaan); library(purrr)

ROOT <- ".."
DATA_IN <- "New_seagrass_CLR_region_site_Chem_with_SR.csv"

cat("=== Phase 9 Recalculation (Strict 505) ===\n\n")

# ── 1. Load data ──
dat <- read_csv(DATA_IN, show_col_types=FALSE)
cat(sprintf("Data: %d rows, %d cols\n", nrow(dat), ncol(dat)))

# ── 2. Load 697 and filter to 505 ──
u <- read_csv("phase7_universal_candidates.csv", show_col_types=FALSE)
strict <- u %>% filter(tli >= 0.95, agfi >= 0.95)
cat(sprintf("697 -> %d strict models (TLI>=0.95 & AGFI>=0.95)\n\n", nrow(strict)))

# ── 3. Fit function (same as phase5c) ──
fit_one <- function(i) {
  sr1 <- strict$sr1[i]
  sr2 <- strict$sr2[i]
  down_vars <- unlist(strsplit(strict$downset[i], "\\|"))
  
  d <- dat
  d$.SR1 <- d[[sr1]]
  d$.SR2 <- d[[sr2]]
  d$Seagrass <- as.ordered(d$Seagrass)
  
  rhs <- paste(sprintf("%s ~ Seagrass", down_vars), collapse="\n")
  mod <- sprintf("Seagrass ~ .SR1 + .SR2\n%s", rhs)
  
  fit <- tryCatch(
    sem(mod, data=d, estimator="WLSMV", ordered="Seagrass"),
    error=function(e) NULL
  )
  if (is.null(fit) || !lavInspect(fit, "converged")) return(NULL)
  
  pe <- parameterEstimates(fit, standardized=TRUE)
  
  # Downstream paths
  down_pe <- pe[pe$op == "~" & pe$rhs == "Seagrass" & pe$lhs %in% down_vars, ]
  
  # SR paths
  sr_pe <- pe[pe$op == "~" & pe$lhs == "Seagrass" & pe$rhs %in% c(".SR1",".SR2"), ]
  
  rows <- list()
  for (j in seq_len(nrow(down_pe))) {
    rows[[length(rows)+1]] <- tibble(
      model_i=i, path_type="downstream",
      lhs=down_pe$lhs[j], std_all=down_pe$std.all[j],
      pvalue=down_pe$pvalue[j], sig=down_pe$pvalue[j] < 0.05
    )
  }
  for (j in seq_len(nrow(sr_pe))) {
    rows[[length(rows)+1]] <- tibble(
      model_i=i, path_type="upstream",
      lhs=sr_pe$rhs[j], std_all=sr_pe$std.all[j],
      pvalue=sr_pe$pvalue[j], sig=sr_pe$pvalue[j] < 0.05
    )
  }
  bind_rows(rows)
}

# ── 4. Run all 505 models ──
cat("Fitting 505 models...\n")
t0 <- Sys.time()
all_res <- list()

for (i in seq_len(nrow(strict))) {
  res <- fit_one(i)
  if (!is.null(res)) all_res[[length(all_res)+1]] <- res
  if (i %% 50 == 0) {
    el <- as.numeric(Sys.time()-t0, units="mins")
    cat(sprintf("  %d / %d  (%.1f min)\n", i, nrow(strict), el))
  }
}
all_df <- bind_rows(all_res)
el_total <- as.numeric(Sys.time()-t0, units="mins")
cat(sprintf("Done: %d path estimates in %.1f min\n\n", nrow(all_df), el_total))

# ── 5. Downstream summary ──
down_df <- all_df %>% filter(path_type == "downstream")
summary_df <- down_df %>%
  group_by(lhs) %>%
  summarise(
    n_models = n(),
    std_median = median(std_all, na.rm=TRUE),
    std_mean = mean(std_all, na.rm=TRUE),
    std_sd = sd(std_all, na.rm=TRUE),
    p_sig_pct = round(100 * sum(sig, na.rm=TRUE) / n()),
    .groups="drop"
  ) %>%
  arrange(desc(n_models))

cat("=== Downstream Path Summary (505 strict) ===\n")
print(summary_df, n=20)

# ── 6. SR summary ──
sr_df <- all_df %>% filter(path_type == "upstream")
sr_summary <- sr_df %>%
  group_by(lhs) %>%
  summarise(
    n = n(),
    std_median = median(std_all, na.rm=TRUE),
    p_sig_pct = round(100 * sum(sig, na.rm=TRUE) / n()),
    .groups="drop"
  )
# 内部定義: .SR1 = chemistry, .SR2 = biome
# 論文表示に合わせて再ラベル: SR_score1 = biome (.SR2), SR_score2 = chemistry (.SR1)
# 値(std_median 等)は変えず、ラベルと並び順のみ論文に合わせる
sr_summary <- sr_summary %>%
  mutate(
    data_type   = case_when(
      lhs %in% c(".SR1","SR1","sr1") ~ "chemistry",
      lhs %in% c(".SR2","SR2","sr2") ~ "biome",
      TRUE ~ NA_character_
    ),
    paper_label = case_when(
      data_type == "biome"     ~ "SR_score1",   # 論文 SR_score1 = biome
      data_type == "chemistry" ~ "SR_score2",   # 論文 SR_score2 = chemistry
      TRUE ~ NA_character_
    )
  ) %>%
  arrange(paper_label) %>%                       # SR_score1 (biome) を先頭に
  select(paper_label, data_type, internal_lhs = lhs, n, std_median, p_sig_pct)
cat("\n=== SR Path Summary ===\n")
print(sr_summary)

# ── 7. Save ──
write_csv(summary_df, "phase9_downstream_path_summary_strict505.csv")
cat("\nSaved: phase9_downstream_path_summary_strict505.csv\n")

# upstream (SR_score1 / SR_score2) summary も書き出す
# 図 (SEM_Figure_505_collective_v10.R) の upstream path 値の出典として保存
write_csv(sr_summary, "phase9_sr_path_summary_strict505.csv")
cat("Saved: phase9_sr_path_summary_strict505.csv\n")

# ── 8. Comparison with old 697 ──
old <- tryCatch(read_csv("phase9_downstream_path_summary.csv", show_col_types=FALSE),
                error=function(e) NULL)
if (!is.null(old)) {
  old$pct_old <- round(100 * old$n_models / 697, 1)
  summary_df$pct_new <- round(100 * summary_df$n_models / 505, 1)
  
  comp <- merge(
    old %>% select(lhs, std_median_old=std_median, pct_old, p_sig_old=p_sig_pct),
    summary_df %>% select(lhs, std_median_new=std_median, pct_new, p_sig_new=p_sig_pct),
    by="lhs", all=TRUE
  ) %>% arrange(desc(pct_new))
  
  cat("\n=== 697 vs 505 Comparison ===\n")
  print(as.data.frame(comp))
  write_csv(comp, "comparison_697_vs_505.csv")
  cat("Saved: comparison_697_vs_505.csv\n")
}

# ── 9. Fit indices for 505 ──
cat("\n=== Fit Indices (505 strict) ===\n")
for (col in c("cfi","tli","rmsea","srmr","gfi","agfi","wrmr")) {
  cat(sprintf("%6s: median=%.4f  min=%.4f  max=%.4f\n",
      toupper(col), median(strict[[col]], na.rm=T),
      min(strict[[col]], na.rm=T), max(strict[[col]], na.rm=T)))
}

cat("\nAll done.\n")

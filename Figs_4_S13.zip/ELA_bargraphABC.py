import pandas as pd
import matplotlib.pyplot as plt
import sys
import os

def main():
    if len(sys.argv) != 2:
        print("使用方法: python3.10 コード.py ファイル名.csv")
        sys.exit(1)

    filename = sys.argv[1]

    try:
        # CSVファイル読み込み
        df = pd.read_csv(filename)

        print("読み込んだ列名:", df.columns.tolist())

        # ABC順に並べ替え
        df = df.sort_values(by='name', ascending=True)

        # カラー設定（スコアが0以上なら緑、未満なら青）
        colors = ['green' if x >= 0 else 'blue' for x in df['ELA_seagrass_score']]

        # グラフ描画
        plt.figure(figsize=(7, 4))
        plt.barh(df['name'], df['ELA_seagrass_score'], color=colors)
        plt.xlabel('ELA_seagrass_score')
        plt.grid(axis='x', linestyle='--', alpha=0.7)
        plt.axvline(0, color='gray', linewidth=0.8)
        plt.rcParams['font.family'] = 'Helvetica'
        plt.tight_layout()

        # 保存先フォルダの作成
        output_folder = 'folder'
        os.makedirs(output_folder, exist_ok=True)

        # ファイル名の共通部分（拡張子除去）
        base_filename = os.path.splitext(os.path.basename(filename))[0]

        # 保存ファイルパス
        pdf_path = os.path.join(output_folder, f'{base_filename}_seagrass_score_graph.pdf')
        png_path = os.path.join(output_folder, f'{base_filename}_seagrass_score_graph.png')

        # 保存処理（PDFとPNG）
        plt.savefig(pdf_path, dpi=300)
        plt.savefig(png_path, dpi=300)

        # 表示
        plt.show()

        print(f"PDFとPNGを保存しました: {pdf_path}, {png_path}")

    except Exception as e:
        print(f"ファイルの読み込みまたは描画中にエラーが発生しました: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()

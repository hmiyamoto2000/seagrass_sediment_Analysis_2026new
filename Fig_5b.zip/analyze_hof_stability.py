#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#brew install julia 
#conda activate pysr310
#pip install --upgrade pip
#pip install pysr pandas numpy


#analyze_hof_stability.py

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
hall_of_fame.csv を使った変数出現頻度（安定性）解析

Usage:
    python3.10 analyze_hof_stability.py /path/to/outputs_folder

Outputs:
    variable_stability_from_hof.csv
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Hall of Fame から変数出現頻度を集計するスクリプト

使い方:
    python analyze_hof_stability.py /path/to/outputfolder

各 run の hall_of_fame.csv を検索し、Equation 列から変数名を抽出。
定数や指数表記 (例: 1.23e-4) は除外。
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import pandas as pd
from collections import Counter
import re
import os
from glob import glob

# -------------------------
# 式から変数名を抽出（数字や e を除外）
# -------------------------
def extract_variables(equation):
    if not isinstance(equation, str):
        return []
    # 数字や小文字の e を除外
    tokens = re.findall(r"[A-Za-z_][A-Za-z0-9_]*", equation)
    return [t for t in tokens if not t.islower() or '_' in t]

def main():
    if len(sys.argv) != 2:
        print("Usage: python analyze_hof_minloss.py output_folder")
        sys.exit(1)

    output_folder = sys.argv[1]
    if not os.path.exists(output_folder):
        print(f"Error: Folder {output_folder} does not exist")
        sys.exit(1)

    # -------------------------
    # hall_of_fame.csv を各 run ごとに検索
    # -------------------------
    hof_files = glob(os.path.join(output_folder, "**", "hall_of_fame.csv"), recursive=True)
    if not hof_files:
        print("No hall_of_fame.csv files found")
        sys.exit(1)

    print(f"Found {len(hof_files)} hall_of_fame.csv files")

    variable_counter = Counter()
    used_runs = 0

    for hof_file in hof_files:
        try:
            df = pd.read_csv(hof_file)
        except Exception as e:
            print(f"[SKIP] Could not read {hof_file}: {e}")
            continue

        if "Equation" not in df.columns or "Loss" not in df.columns:
            print(f"[SKIP] Required columns not found in {hof_file}")
            continue

        # -------------------------
        # Loss 最小の行を抽出
        # -------------------------
        min_loss_row = df.loc[df["Loss"].idxmin()]
        equation = min_loss_row["Equation"]
        variable_counter.update(extract_variables(equation))
        used_runs += 1

    if used_runs == 0:
        print("No valid runs found")
        sys.exit(0)

    # -------------------------
    # 出現頻度計算
    # -------------------------
    total = used_runs  # run ごとの最小 Loss のみをカウント
    freq_df = pd.DataFrame(
        [(var, count, count / total) for var, count in variable_counter.items()],
        columns=["Variable", "Count", "Frequency"]
    ).sort_values(by="Count", ascending=False)

    print("\n=== Variable occurrence frequency (min Loss only) ===")
    print(freq_df)

    # CSV 保存
    out_csv = os.path.join(output_folder, "variable_stability_from_hof_minloss.csv")
    freq_df.to_csv(out_csv, index=False)
    print(f"\nSaved: {out_csv}")

if __name__ == "__main__":
    main()

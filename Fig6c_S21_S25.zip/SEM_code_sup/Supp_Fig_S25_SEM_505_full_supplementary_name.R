#!/usr/bin/env Rscript
# =====================================================================
# Supplementary Fig. SX — 505モデル collective SEM（完全版）
# ---------------------------------------------------------------------
# SEM_Figure_505_collective_v10.R の改変版。
# 本文には簡略版（Fig6c_main_simplified.R）を置き、こちらを Supplementary に回す。
#
# 元スクリプトからの変更点（いずれも査読対応で必要）:
#   1. ノード名をコード表記から表示名へ（R1: "omit all the underscores"）
#        B_Dflv -> Defluviitaleaceae, B_Amini -> uncultured Aminicenantes 等
#   2. ノードに2つの量を併記（現行は pct のみ表示で、凡例がそれを
#      「有意だった割合」と誤って定義していた）
#        included in XX% of models   … pct = n_models/505（群レベル）
#        significant in all/none     … p_sig_pct（個別レベル）
#   3. SR 潜在変数の biome/chemistry 対応を data_type 列から取る
#      （元スクリプトは SR1/SR2 の命名が data_type と逆だった。
#        値と biome/chem の対応自体は正しかったので図に誤りはない）
#
# 変更しないもの: 12ノードすべて表示（完全版なので集約しない）、レイアウト、配色
#
# 注意: インセット3つ（Fit criteria / Model selection / Cross Validation）は
#       元スクリプトでも描いていない。画像編集で追加する想定。
#
# 入力:  phase9_downstream_path_summary_strict505.csv
#        phase9_sr_path_summary_strict505.csv（無ければ既知の値で代替）
# 出力:  FigS_SEM_505_full.png / .pdf
# =====================================================================

library(DiagrammeR); library(DiagrammeRsvg); library(rsvg)
library(readr); library(dplyr); library(tibble)

TOTAL      <- 505
OUT_PREFIX <- "FigS_SEM_505_full"
# 2種類を出力:
#   _clean … 丸枠内は名前だけ（数値は凡例に記載 or 後から図に入れる）
#   _check … 丸枠内に included% と個別有意性を併記（確認用・詳細版）
NODE_FONTSIZE  <- 18   # clean 版の丸枠内の文字サイズ（元は 11）
CHECK_FONTSIZE <- 12   # check 版は3行入るので小さめ
EDGE_FONTSIZE  <- 13
ARROWSIZE      <- 1.5  # ★矢じりの大きさ（元は既定。太い線に対して潰れて見えた）
NODE_HEIGHT    <- 0.8  # ★楕円の高さ。既定（0.5）だと平たすぎて矢じりが内側に食い込む
RANKSEP        <- 1.6  # ★上下の線の長さ
NODESEP        <- 0.22 # ★下段の詰め具合
LABELDIST      <- 4.5  # ★ラベルを円から離す距離。4.5 が最適
                       #   これ以上大きくするとラベルが隣の線に乗る
LABELANG       <- 30   # ★左半分 +、右半分 −

# ★書き出しサイズ。片方のみ指定すること。
#   rsvg_png/rsvg_pdf は width と height の両方を指定すると画像が引き伸ばされる。
#   さらに rsvg_pdf の単位は「ポイント」。元スクリプトの width=16 は 16pt（約0.22インチ）だった。
PNG_WIDTH_PX <- 3600   # ピクセル
PDF_WIDTH_PT <- 1500   # ポイント（1500pt ≒ 21 インチ）

## --- 入力 -------------------------------------------------------------
DOWN_CSV <- "phase9_downstream_path_summary_strict505.csv"
SR_CSV   <- "phase9_sr_path_summary_strict505.csv"

if (!file.exists(DOWN_CSV))
  stop(sprintf("必須ファイルがありません: %s\n  カレントディレクトリ: %s", DOWN_CSV, getwd()))
down <- read_csv(DOWN_CSV, show_col_types = FALSE)

if (file.exists(SR_CSV)) {
  sr <- read_csv(SR_CSV, show_col_types = FALSE)
} else {
  warning(sprintf("%s が無いため既知の値で代替します（biome +0.811, chemistry +0.282）。", SR_CSV))
  sr <- tibble(lhs = c(".SR1", ".SR2"), n = c(505, 505),
               std_median = c(0.811496, 0.281868),
               p_sig_pct = c(100, 100), data_type = c("biome", "chemistry"))
}

down$pct <- 100 * down$n_models / TOTAL

## --- ★変更1: 表示名（R1 対応。アンダースコア・コード表記を使わない）----
disp <- c(
  B_Defluviitaleaceae                          = "B_Defluviitaleaceae",
  B_Desulfobulbaceae                           = "B_Desulfobulbaceae",
  B_Hyphomonadaceae                            = "B_Hyphomonadaceae",
  B_uncultured_Aminicenantes_bacterium         = "B_Aminicenantes (uncultured)",
  B_bacterium_enrichment_culture_clone_22_2013 = "B_Sva0485 (clone 22)",
  E_Corallinophycidae                          = "E_Corallinophycidae",
  E_Diatomea                                   = "E_Diatomea",
  E_Intramacronucleata                         = "E_Intramacronucleata",
  chemical_CaO_log                             = "CaO",
  chemical_CEC_log                             = "CEC",
  chemical_NO3_N_log                           = "NO3-N",
  chemical_P2O5_log                            = "P2O5"
)
# ★表示順
#   基本: 16S -> 18S -> 化学、各群内は表示名のアルファベット順（大小文字を無視）
#   （元スクリプトは変数名順で、16S 群の内部がアルファベット順でなかった）
#
# ★GREY_RIGHT = TRUE: 灰色ノード（どのモデルでも有意にならなかったもの）を
#   まとめて右端へ寄せる。色付き（緑・赤）が左、灰色が右に並ぶ。
#   これが無いと B_Aminicenantes が左端、B_Sva0485 が中ほど、と
#   灰色が色付きの間に散らばる。
#   本文図（Fig6c_main_simplified.R）は集約ノードを末尾に置いているので
#   もともと灰色が右端にあり、TRUE にすると両図の並びが揃う。
#   FALSE にすると従来どおりの並びに戻る。
GREY_RIGHT <- TRUE

.mrank  <- ifelse(grepl("^B_", names(disp)), 1L,
           ifelse(grepl("^E_", names(disp)), 2L, 3L))

# down に行が無い／p_sig_pct が NA の変数は「灰色」扱い（＝右側）にする
.is_sig <- vapply(names(disp), function(v) {
  r <- down[down$lhs == v, ]
  if (nrow(r) == 0 || is.na(r$p_sig_pct[1])) return(FALSE)
  r$p_sig_pct[1] > 50
}, logical(1))

.sigrank  <- if (GREY_RIGHT) ifelse(.is_sig, 1L, 2L) else rep(1L, length(disp))
var_order <- names(disp)[order(.sigrank, .mrank, tolower(unname(disp)))]

cat(sprintf("表示順（GREY_RIGHT = %s）:\n", GREY_RIGHT)); print(data.frame(
  marker = ifelse(grepl("^B_", var_order), "16S", ifelse(grepl("^E_", var_order), "18S", "Chemical")),
  name   = unname(disp[var_order]),
  colour = ifelse(.is_sig[var_order], "coloured", "grey")))
node_id   <- function(x) gsub("[^A-Za-z0-9]", "", x)

## --- 描画規則（元スクリプトと同じ）--------------------------------------
edge_color <- function(b, sig_pct) {
  if (is.na(sig_pct) || sig_pct == 0) return("grey50")
  if (b >= 0) return("forestgreen"); return("firebrick")
}
edge_style <- function(sig_pct) {
  if (is.na(sig_pct) || sig_pct == 0) return("dashed"); return("solid")
}
penwidth <- function(pct) { w <- (pct / 100) * 6; min(max(w, 0.6), 6) }

## --- ★変更2: 2つの量を併記する ----------------------------------------
# 実データでは p_sig_pct は 100 か 0 のみ（中間値なし）だが、一般の場合も扱えるようにする
sig_txt <- function(p) {
  if (is.na(p))            "significance not available"
  else if (p >= 99.999)    "significant in all of them"
  else if (p <= 0.001)     "significant in none"
  else            sprintf("significant in %.0f%% of them", p)
}

build_node <- function(varname, mode) {
  row <- down[down$lhs == varname, ]
  if (nrow(row) == 0) return(NULL)
  fill <- if (row$std_median > 0 && row$p_sig_pct > 50) "#A8D5A8" else
          if (row$std_median < 0 && row$p_sig_pct > 50) "#F5A8A8" else "#E5E5E5"
  fs  <- if (mode == "clean") NODE_FONTSIZE else CHECK_FONTSIZE
  lbl <- if (mode == "clean") unname(disp[varname])
         else sprintf("%s\\nincluded in %.0f%% of models\\n%s",
                      unname(disp[varname]), row$pct, sig_txt(row$p_sig_pct))
  sprintf("%s [label='%s' shape=ellipse style=filled fillcolor='%s' fontsize=%d height=%.1f]",
          node_id(varname), lbl, fill, fs, NODE_HEIGHT)
}

## --- ★変更3: SR の biome/chemistry を data_type から取る -----------------
sr_b <- sr %>% filter(data_type == "biome")     %>% slice(1)
sr_c <- sr %>% filter(data_type == "chemistry") %>% slice(1)

sr_num <- function(x) gsub("[^0-9]", "", x)

edges <- c(
  sprintf("SRbio  -> Seagrass [taillabel='%+.2f' labeldistance=3.4 labelangle=-60 fontsize=%d fontcolor='forestgreen' color='forestgreen' penwidth=6.0 arrowsize=%.1f]",
          sr_b$std_median, EDGE_FONTSIZE, ARROWSIZE),
  sprintf("SRchem -> Seagrass [taillabel='%+.2f' labeldistance=3.4 labelangle=60 fontsize=%d fontcolor='forestgreen' color='forestgreen' penwidth=6.0 arrowsize=%.1f]",
          sr_c$std_median, EDGE_FONTSIZE, ARROWSIZE))

# ★ラベルは midpoint ではなく headlabel。左半分 +角度・右半分 −角度で線の外側に出す
half <- length(var_order) / 2
for (i in seq_along(var_order)) {
  v <- var_order[i]
  row <- down[down$lhs == v, ]
  if (nrow(row) == 0) next
  ang <- if (i <= half) LABELANG else -LABELANG
  edges <- c(edges,
    sprintf(paste0("Seagrass -> %s [headlabel='%+.2f' labeldistance=%.1f labelangle=%d ",
                   "fontsize=%d fontcolor='%s' color='%s' penwidth=%.2f arrowsize=%.1f style='%s']"),
            node_id(v), row$std_median, LABELDIST, ang, EDGE_FONTSIZE,
            edge_color(row$std_median, row$p_sig_pct),
            edge_color(row$std_median, row$p_sig_pct),
            penwidth(row$pct), ARROWSIZE, edge_style(row$p_sig_pct)))
}

## --- レイアウト（元スクリプトを踏襲。ラベルが3行になったので ranksep を広げる）---
top_order <- paste(vapply(var_order, node_id, character(1)), collapse = " ")

build_dot <- function(mode) {
  all_nodes <- na.omit(unlist(lapply(var_order, build_node, mode = mode)))
  fs <- if (mode == "clean") NODE_FONTSIZE else CHECK_FONTSIZE
  sprintf("
digraph SEM_505_full {
rankdir=TB
ranksep=%s
nodesep=%.2f
splines=true
node [fontname=Helvetica]
edge [fontname=Helvetica]

%s

Seagrass [label='Seagrass' shape=box style=filled fillcolor='#C6E0B4' fontsize=22 width=2 height=1]
SRbio  [label='SR_score%s\\n(Biome)' shape=ellipse style=filled fillcolor='#FFB347' fontsize=%d]
SRchem [label='SR_score%s\\n(Chemical)'  shape=ellipse style=filled fillcolor='#FFF2CC' fontsize=%d]

{rank=same; %s}
{rank=same; Seagrass}
{rank=same; SRbio SRchem}

SRbio -> SRchem [style=invis]

%s
}",
  if (mode == "clean") RANKSEP else RANKSEP + 0.3, NODESEP,
  paste(all_nodes, collapse = "\n"),
  sr_num(sr_b$lhs), fs, sr_num(sr_c$lhs), fs,
  top_order,
  paste(edges, collapse = "\n"))
}

for (mode in c("clean", "check")) {
  p   <- grViz(build_dot(mode))
  png <- sprintf("%s_%s.png", OUT_PREFIX, mode)
  pdf <- sprintf("%s_%s.pdf", OUT_PREFIX, mode)
  svg <- export_svg(p) |> charToRaw()
  rsvg_png(svg, png, width = PNG_WIDTH_PX)   # ★width のみ（両方だと引き伸ばされる）
  rsvg_pdf(svg, pdf, width = PDF_WIDTH_PT)   # ★単位はポイント
  cat(sprintf("  出力: %s / %s\n", png, pdf))
}

## --- 確認用サマリ（clean 版は図中に数値が出ないので凡例へ）--------------
cat(sprintf("\n=== Supplementary Fig.: %s_{clean,check}.{png,pdf} ===\n", OUT_PREFIX))
cat(sprintf("  ノード数 %d（完全版。集約なし）\n\n", nrow(down)))
print(down %>%
        mutate(name = unname(disp[lhs]),
               included = sprintf("%.1f%%", pct),
               significant = vapply(p_sig_pct, sig_txt, character(1)),
               beta = round(std_median, 3)) %>%
        arrange(desc(pct)) %>%
        select(name, included, significant, beta) %>%
        as.data.frame())
cat("\n★凡例に書くこと:\n")
cat("   ノードの1行目の % = そのパスが含まれたモデルの割合（エッジの太さもこれに比例）\n")
cat("   ノードの2行目      = 含まれたモデルのうち個別に有意だった割合\n")
cat("   色・線種           = 個別有意性（実データでは all か none のみ）\n")
cat("\n※ インセット3つ（Fit criteria / Model selection / Cross Validation）は\n")
cat("   元スクリプトでも描いていない。画像編集で追加すること。\n")

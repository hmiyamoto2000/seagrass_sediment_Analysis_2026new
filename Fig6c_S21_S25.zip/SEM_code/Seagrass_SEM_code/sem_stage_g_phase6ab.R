#!/usr/bin/env Rscript
# Phase 6a: Region-wise sd check
# Phase 6b: full path coefficient extraction
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT     <- "/Fig6"
DATA_IN  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
POOL_IN  <- file.path(ROOT, "phase5c_full_fit.csv")
OUT_6A   <- file.path(ROOT, "phase6a_region_sd_check.csv")
OUT_6B   <- file.path(ROOT, "phase6b_full_path_coefs.csv")
OUT_DIR  <- file.path(ROOT, "phase6b_chunks")
dir.create(OUT_DIR, showWarnings = FALSE)

dat <- read_csv(DATA_IN, show_col_types=FALSE)
pool <- read_csv(POOL_IN, show_col_types=FALSE) %>%
  filter(converged, gfi>=0.95, agfi>=0.90, wrmr<=1.0)
cat(sprintf("[Phase6] Pool: %d models, Data: %d rows (%d regions)\n",
            nrow(pool), nrow(dat), length(unique(dat$Region))))

cat("\n[Phase6a] Region-wise sd check\n")
all_vars <- unique(unlist(strsplit(pool$downset, split="|", fixed=TRUE)))
cat(sprintf("  Unique downstream variables: %d\n", length(all_vars)))

reg_sd <- map_dfr(all_vars, function(v) {
  s <- dat %>% group_by(Region) %>%
    summarise(sd=sd(.data[[v]], na.rm=TRUE), .groups="drop")
  tibble(variable=v, region=s$Region, sd=s$sd)
}) %>% mutate(zero_sd = (sd == 0 | is.na(sd)))

write_csv(reg_sd, OUT_6A)
cat("  Wrote ->", OUT_6A, "\n")

bad_vars <- reg_sd %>% filter(zero_sd) %>% pull(variable) %>% unique()
cat("  Variables with zero-sd in any Region:\n")
if (length(bad_vars) == 0) {
  cat("    (none, all variables have positive sd in all regions)\n")
} else {
  print(bad_vars)
}

pool$any_zero_sd_region <- map_lgl(pool$downset, function(s) {
  vars <- strsplit(s, split="|", fixed=TRUE)[[1]]
  any(vars %in% bad_vars)
})
cat(sprintf("  Models with zero-sd-region downstream: %d / %d\n",
            sum(pool$any_zero_sd_region), nrow(pool)))

cat("\n[Phase6b] Re-fitting all models for full parameter extraction\n")

extract_one <- function(sr1, sr2, downset_str) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  downs <- strsplit(downset_str, split="|", fixed=TRUE)[[1]]
  rhs <- paste(downs, collapse=" + ")
  mod <- sprintf("Seagrass ~ .SR1 + .SR2\n%s ~ Seagrass", rhs)
  tryCatch({
    fit <- suppressWarnings(lavaan::sem(mod, data=d, ordered="Seagrass",
                                        estimator="WLSMV", se="robust"))
    if (!isTRUE(lavaan::lavInspect(fit, "converged"))) return(tibble())
    pe <- lavaan::parameterEstimates(fit, standardized=TRUE, ci=TRUE)
    pe$sr1 <- sr1; pe$sr2 <- sr2; pe$downset <- downset_str
    pe %>% select(sr1, sr2, downset, lhs, op, rhs, est, se, z, pvalue,
                  ci.lower, ci.upper, std.all)
  }, error=function(e) tibble())
}

plan(multisession, workers=24)
CHUNK <- 500
chunks <- split(seq_len(nrow(pool)), ceiling(seq_len(nrow(pool))/CHUNK))
cat(sprintf("[Phase6b] %d chunks of %d models\n", length(chunks), CHUNK))

t0 <- Sys.time()
for (ci in seq_along(chunks)) {
  out_path <- file.path(OUT_DIR, sprintf("phase6b_chunk_%03d.csv", ci))
  if (file.exists(out_path)) {
    cat(sprintf("[chunk %3d/%d] skip\n", ci, length(chunks))); next
  }
  rows_ci <- chunks[[ci]]
  res <- future_map_dfr(rows_ci, function(i)
    extract_one(pool$sr1[i], pool$sr2[i], pool$downset[i]),
    .options=furrr_options(seed=TRUE), .progress=TRUE)
  write_csv(res, out_path)
  el <- as.numeric(Sys.time()-t0, units="mins")
  cat(sprintf("[chunk %3d/%d] elapsed %.1f min, %.1f%% done\n",
              ci, length(chunks), el, ci/length(chunks)*100))
}

cat("[Phase6b] Combining...\n")
files <- list.files(OUT_DIR, pattern="^phase6b_chunk_.*\\.csv$", full.names=TRUE)
combined <- map_dfr(files, ~ read_csv(.x, show_col_types=FALSE))
write_csv(combined, OUT_6B)
cat(sprintf("[Phase6b] Wrote %s (%d parameter rows)\n", OUT_6B, nrow(combined)))

cat(sprintf("\n[Phase6] Total time: %.1f min\n",
            as.numeric(Sys.time()-t0, units="mins")))
cat("\n=== Phase 6a + 6b complete ===\n")

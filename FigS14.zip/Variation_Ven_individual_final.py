#!/usr/bin/env python3
"""
Variation Partitioning visualization (Venn + Bar chart).

Usage:
    python Variation_Ven_finalnew_individual.py vp_variance.csv ## デフォルト (6 x 6 inch)
    python Variation_Ven_finalnew_individual.py vp_variance.csv -w 8 #横幅8インチ
    python Variation_Ven_finalnew_individual.py vp_variance.csv --width 10 --height 7

Options:
    -w, --width   図の横幅 (inch, default: 6)
    -h, --height  図の高さ (inch, default: 6)
"""

import argparse
import os
import sys
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # バッチ実行対応（GUI不要）
import matplotlib.pyplot as plt
from matplotlib_venn import venn3
import seaborn as sns

# -----------------------------
# 引数パーサー
# -----------------------------
parser = argparse.ArgumentParser(
    description="Variation Partitioning visualization (Venn + Bar chart)"
)
parser.add_argument("input_csv", nargs="?", default="vp_variance.csv",
                    help="Input CSV file (default: vp_variance.csv)")
parser.add_argument("-w", "--width", type=float, default=6,
                    help="Figure width in inches (default: 6)")
parser.add_argument("--height", type=float, default=6,
                    help="Figure height in inches (default: 6)")
args = parser.parse_args()

input_csv = args.input_csv
FIG_W = args.width
FIG_H = args.height

# -----------------------------
# 図設定
# -----------------------------
sns.set_style("whitegrid")
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 11,
})

# -----------------------------
# 入力チェック
# -----------------------------
if not os.path.exists(input_csv):
    print(f"Error: File not found: {input_csv}")
    raise SystemExit(1)

output_dir = "ordination_output"
os.makedirs(output_dir, exist_ok=True)
base_name = os.path.splitext(os.path.basename(input_csv))[0]

# -----------------------------
# CSV読み込み
# -----------------------------
df = pd.read_csv(input_csv)

# variance 列の自動検出: "variance.Adj.R.square" or "variance"
if "variance.Adj.R.square" in df.columns:
    val_col = "variance.Adj.R.square"
elif "variance" in df.columns:
    val_col = "variance"
else:
    print(f"Error: CSV must contain 'variance' or 'variance.Adj.R.square' column.")
    print(f"       Found columns: {list(df.columns)}")
    sys.exit(1)

# 元の値を保持し、負のAdjusted R²は0に置換
df["original_value"] = df[val_col]
df["variance"] = df[val_col].apply(lambda x: max(x, 0))
df["note"] = df[val_col].apply(
    lambda x: "Negative adjusted R² rounded to 0 (statistical artifact)" if x < 0 else ""
)

# -----------------------------
# Venn用データ — ラベル自動検出
# -----------------------------
fractions = dict(zip(df["fraction"], df["variance"]))

# 個別フラクション（":"を含まず、"Residual"でないもの）からラベルを取得
individual_labels = [f for f in df["fraction"] if ":" not in f and f != "Residual"]
if len(individual_labels) != 3:
    print(f"Warning: Expected 3 individual fractions, found {len(individual_labels)}: {individual_labels}")

L1, L2, L3 = individual_labels[0], individual_labels[1], individual_labels[2]

A   = fractions.get(L1, 0)
B   = fractions.get(L2, 0)
C   = fractions.get(L3, 0)
AB  = fractions.get(f"{L1}:{L2}", 0)
AC  = fractions.get(f"{L1}:{L3}", 0)
BC  = fractions.get(f"{L2}:{L3}", 0)
ABC = fractions.get(f"{L1}:{L2}:{L3}", 0)

subsets = (A, B, AB, C, AC, BC, ABC)

SET_LABELS = (L1, L2, L3)

# -----------------------------
# 色定義
# -----------------------------
VENN_COLORS = {
    "100": "orange",
    "010": "lightgreen",
    "001": "lightblue",
    "110": "gold",
    "101": "violet",
    "011": "cyan",
    "111": "grey",
}


# -----------------------------
# Venn描画関数
# -----------------------------
def plot_venn(subsets, ax, title="Variation Partitioning (Venn)"):
    v = venn3(subsets=subsets, set_labels=SET_LABELS, ax=ax)

    for sid, c in VENN_COLORS.items():
        patch = v.get_patch_by_id(sid)
        if patch:
            patch.set_color(c)
            patch.set_alpha(0.6)

    subset_ids = ["100", "010", "001", "110", "101", "011", "111"]
    for i, sid in enumerate(subset_ids):
        if v.subset_labels and i < len(v.subset_labels):
            label = v.subset_labels[i]
            if label:
                label.set_text(f"{subsets[i]:.3f}")

    ax.set_title(title, fontsize=13, fontweight="bold")


# -----------------------------
# 棒グラフ描画関数
# -----------------------------
def plot_barh(df, ax, title="Variance explained by factors"):
    colors = []
    for f in df["fraction"]:
        if f == "Residual":
            colors.append("lightgrey")
        elif ":" in f:
            colors.append("khaki")
        else:
            colors.append("lightgreen")

    bars = ax.barh(df["fraction"], df["variance"], color=colors, edgecolor="black",
                   linewidth=0.5)

    for i, (vv, orig) in enumerate(zip(df["variance"], df["original_value"])):
        display = f"{orig:.3f}" if orig < 0 else f"{vv:.3f}"
        ax.text(max(vv, 0) + 0.005, i, display, va="center", fontsize=9)

    ax.set_xlabel("Adjusted R²", fontsize=11)
    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.axvline(x=0, color="black", linewidth=0.5, linestyle="-")


# -----------------------------
# 個別出力: Venn
# -----------------------------
fig1, ax1 = plt.subplots(figsize=(FIG_W, FIG_H))
plot_venn(subsets, ax1)
fig1.tight_layout()
fig1.savefig(os.path.join(output_dir, f"{base_name}_venn.png"), dpi=300)
fig1.savefig(os.path.join(output_dir, f"{base_name}_venn.pdf"))
plt.close(fig1)
print(f"Venn figure saved: {base_name}_venn.png (size: {FIG_W} x {FIG_H} inch)")

# -----------------------------
# 個別出力: Bar
# -----------------------------
fig2, ax2 = plt.subplots(figsize=(FIG_W + 1, FIG_H - 1 if FIG_H > 2 else FIG_H))
plot_barh(df, ax2)
fig2.tight_layout()
fig2.savefig(os.path.join(output_dir, f"{base_name}_bar.png"), dpi=300)
fig2.savefig(os.path.join(output_dir, f"{base_name}_bar.pdf"))
plt.close(fig2)
print(f"Bar figure saved: {base_name}_bar.png")

# -----------------------------
# 組み合わせ出力
# -----------------------------
fig3, axes = plt.subplots(1, 2, figsize=(FIG_W * 2 + 2, FIG_H))
plot_venn(subsets, axes[0])
plot_barh(df, axes[1])
fig3.tight_layout()
fig3.savefig(os.path.join(output_dir, f"{base_name}_combined.png"), dpi=300)
fig3.savefig(os.path.join(output_dir, f"{base_name}_combined.pdf"))
plt.close(fig3)
print(f"Combined figure saved: {base_name}_combined.png")

# -----------------------------
# クリーンCSV保存
# -----------------------------
df_out = df[["fraction", "original_value", "variance", "note"]]
df_out.to_csv(os.path.join(output_dir, f"{base_name}_cleaned.csv"), index=False)
print(f"Cleaned CSV saved: {base_name}_cleaned.csv")

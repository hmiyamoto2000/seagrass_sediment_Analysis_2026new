suppressPackageStartupMessages({
  library(readr); library(dplyr); library(ggplot2); library(patchwork); library(tidyr); library(stringr)
})
u <- read_csv("phase7_universal_candidates.csv", show_col_types=FALSE)
TOTAL <- nrow(u)

# Panel A: SR_biome (= SR_score1) と SR_chem (= SR_score2) 別々の出現率
# 論文表示: SR_score1 = biome (内部 sr2), SR_score2 = chemistry (内部 sr1)
biome_freq <- u %>% count(sr2, name="n") %>%
  mutate(pct=100*n/TOTAL, group="Biome (SR_score1)", variant=str_replace(sr2,"SR_biome_",""))
chem_freq <- u %>% count(sr1, name="n") %>%
  mutate(pct=100*n/TOTAL, group="Chemistry (SR_score2)", variant=str_replace(sr1,"SR_chem_",""))
variant_df <- bind_rows(biome_freq %>% select(group, variant, n, pct),
                        chem_freq %>% select(group, variant, n, pct))

pA <- ggplot(variant_df, aes(x=variant, y=pct, fill=group)) +
  geom_col(alpha=0.85) +
  geom_text(aes(label=sprintf("%.1f%%\n(n=%d)", pct, n)),
            vjust=-0.3, size=3) +
  facet_wrap(~group, scales="free_x") +
  scale_fill_manual(values=c("Biome (SR_score1)"="#FFB347",
                             "Chemistry (SR_score2)"="#FFF2CC")) +
  scale_y_continuous(limits=c(0, NA), expand=expansion(mult=c(0, 0.18))) +
  labs(x="SR variant (depth_complexity)", y="Presence in 697 Universal models (%)",
       title="A. SR variant frequency (697 Universal models)",
       subtitle="Each Universal model uses one SR_score1 (biome) and one SR_score2 (chemistry) variant") +
  theme_classic(base_size=11) +
  theme(legend.position="none",
        panel.grid=element_blank(),
        plot.subtitle=element_text(size=9, color="grey40"))

# Panel B: SR pair heatmap
pair_df <- u %>% count(sr1, sr2, name="n") %>%
  mutate(pct=100*n/TOTAL,
         chem_var=str_replace(sr1,"SR_chem_",""),
         biome_var=str_replace(sr2,"SR_biome_",""))

pB <- ggplot(pair_df, aes(x=chem_var, y=biome_var, fill=pct)) +
  geom_tile(color="white", linewidth=0.5) +
  geom_text(aes(label=sprintf("n=%d\n%.1f%%", n, pct)), size=3.5) +
  scale_fill_gradient(low="#F5F5F5", high="forestgreen", name="% of 697") +
  labs(x="SR_score2 variant (chemistry, depth_complexity)",
       y="SR_score1 variant (biome, depth_complexity)",
       title="B. SR pair composition (5 observed pairs)",
       subtitle="Cells show number and % of Universal models with each SR pair") +
  theme_classic(base_size=11) +
  theme(panel.grid=element_blank(),
        plot.subtitle=element_text(size=9, color="grey40"))

# Combine
combined <- pA / pB +
  plot_annotation(
    title = "Extended Data Fig. SR pair composition across 697 Universal models",
    subtitle = "Of the 4 chemistry SR variants and 3 biome SR variants, only 5 of the possible 12 pair combinations appeared in Universal models.",
    theme = theme(plot.title=element_text(size=12, face="bold"),
                  plot.subtitle=element_text(size=9, color="grey30")))

# ── Source Data export (Fig. S22) ──────────────────────────────────────
# Panel a: per-variant frequency (biome = SR_score1, chemistry = SR_score2).
# Panel b: SR pair composition (biome x chemistry combinations).
write_csv(variant_df, "Supp_Fig_S22_panel_a_variant_frequency.csv")
write_csv(pair_df,    "Supp_Fig_S22_panel_b_pair_composition.csv")
cat("Saved Source Data: Supp_Fig_S22_panel_a_variant_frequency.csv,",
    "Supp_Fig_S22_panel_b_pair_composition.csv\n")

ggsave("Supp_Fig_S22_SR_pair_composition.pdf", combined, width=12, height=10)
ggsave("Supp_Fig_S22_SR_pair_composition.png", combined, width=12, height=10, dpi=300)
cat("Saved Supp_Fig_S22_SR_pair_composition\n")
print(pair_df %>% arrange(desc(n)))

############################################################
# Seagrass sediment microbiome pipeline
# NMDS + dbRDA + PCA + Variation partitioning
# For publication-ready data export
############################################################
#
# Usage:
#   Rscript PCA_dbRDA_Microbe_Chemical_Plus.R Bacteria
#   Rscript PCA_dbRDA_Microbe_Chemical_Plus.R Eukaryota
#
############################################################

library(vegan)
library(dplyr)

############################################################
# 0 コマンドライン引数 — Bacteria / Eukaryota 切替
############################################################
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  target <- "Bacteria"
  cat("No argument given. Defaulting to:", target, "\n")
} else {
  target <- args[1]   # "Bacteria" or "Eukaryota"
}

bac_file <- paste0(target, "_diversity_sample.csv")

if (!file.exists(bac_file)) {
  stop(paste("File not found:", bac_file))
}

# 出力先ディレクトリ（ターゲットごとに分離）
output_dir <- paste0("output_", target)
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

cat("=== Target:", target, "===\n")
cat("Reading:", bac_file, "\n")

############################################################
# 1 データ読み込み
############################################################
bac  <- read.csv(bac_file)
chem <- read.csv("Chemical_seagrass_sample.csv")
meta <- read.csv("List.csv")

bac_mat  <- as.matrix(bac[, 2:ncol(bac)])
chem_mat <- chem[, 2:ncol(chem)]

############################################################
# 2 欠損値補完（中央値補完）
############################################################
for (i in 1:ncol(chem_mat)) {
  chem_mat[is.na(chem_mat[, i]), i] <- median(chem_mat[, i], na.rm = TRUE)
}

############################################################
# 3 rare taxa filtering & relative abundance
############################################################
bac_filt <- bac_mat[, colSums(bac_mat > 0) >= 3]
bac_rel  <- decostand(bac_filt, method = "total")

############################################################
# 4 NMDS（Bray–Curtis）
############################################################
set.seed(123)
nmds <- metaMDS(bac_rel, distance = "bray", trymax = 200)

nmds_scores <- as.data.frame(scores(nmds, display = "sites"))
nmds_scores$name <- bac[, 1]
nmds_scores$cnd  <- meta$cnd
nmds_scores$env  <- meta$env

write.csv(nmds_scores, file.path(output_dir, "NMDS_scores.csv"), row.names = FALSE)

############################################################
# 5 NMDS + envfit（環境ベクトル）
############################################################
fit <- envfit(nmds, decostand(chem_mat, "standardize"), permutations = 999)
env_vectors <- as.data.frame(scores(fit, display = "vectors"))
env_vectors$pval <- fit$vectors$pvals
write.csv(env_vectors, file.path(output_dir, "NMDS_envfit_vectors.csv"))

############################################################
# 6 dbRDA 初期モデル + VIFによる変数削除
############################################################

# 化学変数を標準化
chem_scaled <- scale(chem_mat)
chem_df     <- as.data.frame(chem_scaled)
chem_df     <- chem_df[, sapply(chem_df, is.numeric)]

# dbRDA 初期モデル
mod <- capscale(bac_rel ~ ., data = chem_df, distance = "bray")

# VIF > 10 の変数を逐次削除
vif_step <- function(mod, chem_df) {
  v <- vif.cca(mod)
  while (max(v) > 10) {
    remove_var <- names(which.max(v))
    cat("Removing (VIF):", remove_var, "\n")
    terms_keep <- attr(terms(mod), "term.labels")
    terms_keep <- terms_keep[terms_keep != remove_var]
    new_formula <- as.formula(paste("bac_rel ~", paste(terms_keep, collapse = "+")))
    mod <- capscale(new_formula, data = chem_df, distance = "bray")
    v <- vif.cca(mod)
  }
  return(mod)
}

dbrda_final <- vif_step(mod, chem_df)

# VIF後の化学変数名を取得
vars_final <- attr(terms(dbrda_final), "term.labels")
chem_final <- chem_df[, vars_final, drop = FALSE]

cat("Variables retained after VIF:", paste(vars_final, collapse = ", "), "\n")

############################################################
# 7 dbRDA 統計情報
############################################################
sink(file.path(output_dir, "dbRDA_statistics.txt"))
print(summary(dbrda_final))
print(anova(dbrda_final))
print(anova(dbrda_final, by = "axis"))
print(anova(dbrda_final, by = "terms"))
sink()

############################################################
# 8 dbRDA 座標出力
############################################################
db_sites <- as.data.frame(scores(dbrda_final, display = "sites"))
db_env   <- as.data.frame(scores(dbrda_final, display = "bp"))

db_sites$name <- bac[, 1]
db_sites$cnd  <- meta$cnd
db_sites$env  <- meta$env

write.csv(db_sites, file.path(output_dir, "dbRDA_sites.csv"), row.names = FALSE)
write.csv(db_env,   file.path(output_dir, "dbRDA_vectors.csv"))

eig <- eigenvals(dbrda_final)
var_exp <- eig / sum(eig)
write.csv(var_exp, file.path(output_dir, "dbRDA_variance.csv"))

############################################################
# 9 PCA（dbRDA残存変数使用）
############################################################
pca_input <- chem_scaled[, vars_final]
pca <- rda(pca_input)

pca_sites   <- as.data.frame(scores(pca, display = "sites"))
pca_vectors <- as.data.frame(scores(pca, display = "species"))

pca_sites$name <- chem[, 1]
pca_sites$cnd  <- meta$cnd
pca_sites$env  <- meta$env

write.csv(pca_sites,   file.path(output_dir, "PCA_sites.csv"),   row.names = FALSE)
write.csv(pca_vectors, file.path(output_dir, "PCA_vectors.csv"))

eig_pca     <- eigenvals(pca)
var_exp_pca <- eig_pca / sum(eig_pca)
write.csv(var_exp_pca, file.path(output_dir, "PCA_variance.csv"))

############################################################
# 10 Variation partitioning: region + habitat + chemistry
############################################################
region  <- meta["env"]
habitat <- meta["cnd"]

vp <- varpart(bac_rel, region, habitat, chem_final)
print(vp)

pdf(file.path(output_dir, "variation_partitioning.pdf"))
plot(vp, Xnames = c("Region", "Habitat", "Chemistry"),
     bg = c("orange", "lightgreen", "lightblue"))
dev.off()

# Python用 vp_variance.csv 出力
indfract <- vp$part$indfract
shared   <- vp$part$shared
residual <- vp$part$tot$unexplained

vp_values <- data.frame(
  fraction = c("Region", "Habitat", "Chemistry",
               "Region:Habitat", "Region:Chemistry", "Habitat:Chemistry",
               "Region:Habitat:Chemistry", "Residual"),
  variance = c(indfract[1], indfract[2], indfract[3],
               shared[1], shared[2], shared[3],
               ifelse(length(shared) > 3, shared[4], 0),
               residual)
)

write.csv(vp_values, file.path(output_dir, "vp_variance.csv"), row.names = FALSE)

############################################################
# 11 dbRDA anova — 各要因の検定
############################################################

# --- Region ---
mod_env <- capscale(bac_rel ~ env, data = meta, distance = "bray")
anova_env <- anova(mod_env, permutations = 999)
anova_env_df <- as.data.frame(anova_env)
anova_env_df$Term <- rownames(anova_env_df)
write.csv(anova_env_df, file.path(output_dir, "dbRDA_region.csv"), row.names = FALSE)

# --- Habitat ---
mod_cnd <- capscale(bac_rel ~ cnd, data = meta, distance = "bray")
anova_cnd <- anova(mod_cnd, permutations = 999)
anova_cnd_df <- as.data.frame(anova_cnd)
anova_cnd_df$Term <- rownames(anova_cnd_df)
write.csv(anova_cnd_df, file.path(output_dir, "dbRDA_habitat.csv"), row.names = FALSE)

# --- Chemistry (full model) ---
mod_chem <- capscale(bac_rel ~ ., data = chem_final, distance = "bray")
anova_chem <- anova(mod_chem, permutations = 999)
anova_chem_df <- as.data.frame(anova_chem)
anova_chem_df$Term <- rownames(anova_chem_df)
write.csv(anova_chem_df, file.path(output_dir, "dbRDA_chemistry.csv"), row.names = FALSE)

# --- Chemistry conditioned on region + habitat ---
mod_cond <- capscale(
  as.formula(paste("bac_rel ~", paste(vars_final, collapse = "+"),
                   "+ Condition(env + cnd)")),
  data = cbind(meta, chem_final),
  distance = "bray"
)
anova_cond <- anova(mod_cond, permutations = 999)
anova_cond_df <- as.data.frame(anova_cond)
anova_cond_df$Term <- rownames(anova_cond_df)
write.csv(anova_cond_df, file.path(output_dir, "dbRDA_chemistry_conditioned.csv"),
          row.names = FALSE)

############################################################
# 12 adonis2 (PERMANOVA)
############################################################

# Region + Habitat
adonis_rh <- adonis2(bac_rel ~ env + cnd, data = meta,
                     permutations = 999, method = "bray")
adonis_rh_df <- as.data.frame(adonis_rh)
adonis_rh_df$Term <- rownames(adonis_rh_df)
write.csv(adonis_rh_df, file.path(output_dir, "adonis_region_habitat.csv"),
          row.names = FALSE)

# Chemistry
adonis_chem <- adonis2(bac_rel ~ ., data = chem_final,
                       permutations = 999, method = "bray")
adonis_chem_df <- as.data.frame(adonis_chem)
adonis_chem_df$Term <- rownames(adonis_chem_df)
write.csv(adonis_chem_df, file.path(output_dir, "adonis_chemistry.csv"),
          row.names = FALSE)

############################################################
# 13 dbRDA ペアワイズ地域比較
############################################################
regions <- unique(meta$env)
pairwise_results <- list()

for (i in 1:(length(regions) - 1)) {
  for (j in (i + 1):length(regions)) {
    r1 <- regions[i]
    r2 <- regions[j]

    idx <- meta$env %in% c(r1, r2)
    sub_meta <- meta[idx, ]
    sub_bac  <- bac_rel[idx, ]

    mod_pair   <- capscale(sub_bac ~ env, data = sub_meta, distance = "bray")
    anova_pair <- anova(mod_pair, permutations = 999)

    df_pair <- as.data.frame(anova_pair)
    df_pair$Term    <- rownames(df_pair)
    df_pair$Region1 <- r1
    df_pair$Region2 <- r2

    pairwise_results[[paste(r1, r2, sep = "_vs_")]] <- df_pair
  }
}

pairwise_df <- dplyr::bind_rows(pairwise_results)
write.csv(pairwise_df, file.path(output_dir, "dbRDA_pairwise_regions.csv"),
          row.names = FALSE)

cat("\n=== Pipeline complete for:", target, "===\n")
cat("Output directory:", output_dir, "\n")

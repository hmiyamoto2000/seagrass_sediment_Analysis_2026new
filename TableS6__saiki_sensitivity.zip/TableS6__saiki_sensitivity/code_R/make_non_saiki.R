#!/usr/bin/env Rscript
# Generate the "non_saiki" condition for the Table S6 site-balance sensitivity:
#   the full dataset with the Saiki site (Site code "X8") excluded entirely.
# Input : New_seagrass_CLR_region_site_Chem_with_SR.csv   (132 rows, all 8 sites)
# Output: New_seagrass_CLR_region_site_Chem_with_SR_non_saiki.csv (96 rows)
# Note  : Saiki (X8) = 24 seagrass + 12 non-seagrass = 36 rows removed.
#         (This is the complete-exclusion condition; the balanced-resampling
#          conditions are produced by make_balanced.R.)
suppressPackageStartupMessages({ library(readr); library(dplyr) })

IN  <- "New_seagrass_CLR_region_site_Chem_with_SR.csv"
OUT <- "New_seagrass_CLR_region_site_Chem_with_SR_non_saiki.csv"

d <- read_csv(IN, show_col_types = FALSE)
cat(sprintf("[non_saiki] input rows = %d\n", nrow(d)))

d_ns <- d %>% filter(Site != "X8")   # X8 = Saiki

write_csv(d_ns, OUT)
cat(sprintf("[non_saiki] output rows = %d -> %s\n", nrow(d_ns), OUT))
cat("[non_saiki] Site x Seagrass check:\n"); print(table(d_ns$Site, d_ns$Seagrass))
cat("[non_saiki] Region check:\n");          print(table(d_ns$Region))

"""
build_table_s5_pdf.py
=====================
Generate the A4 print version of Supplementary Table S5 for the seagrass
holobiont paper, styled to match Tables S1-S3 (Nature minimalist:
Helvetica, white background, horizontal rules only).

Table S5 summarises the symbolic regression candidate formulas listed in
Table S4 from two complementary angles:

  (a) Per-variable prevalence in the 12 biome candidate formulas
  (b) Per-variable prevalence in the 11 chem candidate formulas
  (c) The 6 SR pairs that satisfied Phase 2 screening criteria and were
      forwarded to the 378,018-model exhaustive SEM enumeration

Variable naming convention (Mid abbreviation system):
  - Most taxonomic names are written in full
    (e.g., B_Desulfobulbaceae, E_Corallinophycidae)
  - Two long names are abbreviated to roughly match the length of the
    other taxon names:
      B_unc_Aminicenantes  = B_uncultured_Aminicenantes_bacterium
      B_bact_enrichment    = B_bacterium_enrichment_culture_clone_22(2013)
  - Chemical variables are shown without the leading "chemical_" prefix
    or the trailing "_log" suffix (TC, NH4-N, etc.)

This Mid system matches the conventions used in Supplementary Fig. S16
(SR-based occurrence frequency heatmap) and Supplementary Table S3
(precision-matrix elements).  The compact codes used in Fig. 5c, Table S4,
and Supplementary Figs. S18-S19 are deliberately not used here, because
the rows of Table S5 list one variable per line and have ample horizontal
space for full names.

Inputs (place in INPUT_DIR):
  - hall_of_fame_<depth>depth.csv    (biome, depth = 5..10)
  - hall_of_fame_depth<depth>.csv    (chem,  depth = 5..10)
  - phase2_qualified6_pairs.csv

Output:
  - Table_S5.pdf                     (single A4 landscape page, vector)
  - Table_S5.png                     (300 dpi raster preview)
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

# Reuse parsing helpers
sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_table_s4 import (  # noqa: E402
    BIOME_VARS, CHEM_VARS, CHEM_SHORT,
    PHASE2_GLOB,
    load_hall_of_fame, build_records, find_file,
)
from table_style import (  # noqa: E402
    apply_style, draw_table, A4_W, A4_H, TEXT,
)

INPUT_DIR = Path(".")
OUT_PDF   = Path("Table_S5.pdf")
OUT_PNG   = Path("Table_S5.png")

# ---------------------------------------------------------------------
# Mid abbreviation system (full names where possible; only the two long
# names are abbreviated to match the length of the others).
# This matches the convention in Supp Fig S16 and Supp Table S3.
# ---------------------------------------------------------------------
BIOME_MID = {
    "B_Desulfobulbaceae":                            "B_Desulfobulbaceae",
    "B_Hyphomonadaceae":                             "B_Hyphomonadaceae",
    "B_Defluviitaleaceae":                           "B_Defluviitaleaceae",
    "B_BD7_8":                                       "B_BD7-8",
    "B_uncultured_Aminicenantes_bacterium":          "B_unc_Aminicenantes",
    "B_bacterium_enrichment_culture_clone_22_2013":  "B_bact_enrichment",
    "E_Corallinophycidae":                           "E_Corallinophycidae",
    "E_Intramacronucleata":                          "E_Intramacronucleata",
    "E_Diatomea":                                    "E_Diatomea",
}
# For chem we reuse the existing CHEM_SHORT (TC, NH4-N, etc.) which is
# already in the standard form expected by Methods and other figures.


# ---------------------------------------------------------------------
# Data preparation
# ---------------------------------------------------------------------
def prevalence_rows(df: pd.DataFrame, vars_list: list[str],
                    n_formulas: int, name_map: dict[str, str]):
    """Compute a sortable list of (display_name, n_present, n_total,
    total_occ, mean_occ, class_label) tuples.  'class' follows the
    universal/high/moderate/low scheme defined in the caption."""
    out = []
    for v in vars_list:
        n_pres = int((df[v] > 0).sum())
        total  = int(df[v].sum())
        mean_  = total / n_pres if n_pres else 0
        cls = ("universal" if n_pres == n_formulas else
               "high"      if n_pres >= 0.8  * n_formulas else
               "moderate"  if n_pres >= 0.45 * n_formulas else
               "low")
        out.append((name_map[v], n_pres, n_formulas, total, mean_, cls))
    out.sort(key=lambda r: (-r[1], -r[3]))
    return out


def to_rows(prev):
    return [
        [name,
         f"{n_p}/{n_total}",
         f"{n_p / n_total:.0%}",
         str(total),
         f"{mean_:.2f}",
         cls]
        for name, n_p, n_total, total, mean_, cls in prev
    ]


# ---------------------------------------------------------------------
# Page renderer
# ---------------------------------------------------------------------
def render(pdf, biome_df: pd.DataFrame, chem_df: pd.DataFrame,
           phase2: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(A4_W, A4_H))
    ax  = fig.add_axes([0.04, 0.04, 0.92, 0.92])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    # ---- Title ----
    ax.text(0.0, 0.985, "Table S5",
            ha="left", va="top", fontsize=12, fontweight="bold",
            transform=ax.transAxes)
    ax.text(0.0, 0.96,
            "Variable prevalence and qualified SR pairs from the SEM "
            "screening pipeline",
            ha="left", va="top", fontsize=10.5, fontweight="bold",
            transform=ax.transAxes)

    # ---- Caption ----
    caption = (
        "Summary of the symbolic regression candidate formulas (Table S4). "
        "Per-variable prevalence for (a) biome data and (b) chemical "
        "data: how consistently each input variable is retained across "
        "PySR formulas of varying tree depth (5–10) and complexity "
        "(c27, c29). Class labels: universal, present in all candidate "
        "formulas; high, ≥ 80%; moderate, ≥ 45%; low, < 45%. "
        "(c) The six SR pairs that satisfied Phase 2 screening criteria "
        "(χ² p > 0.1, CFI = 1, SRMR ≤ 0.08, WRMR ≤ 1.0, both regressors "
        "p < 0.05) and were forwarded to the 378,018-model exhaustive "
        "SEM enumeration. Note that variable prevalence in (a, b) "
        "summarises the SR Pareto-front candidates and is independent of "
        "whether a variable was retained as a main hub in the SEM path "
        "diagram (Fig. 5c)."
    )
    ax.text(0.0, 0.94, caption, ha="left", va="top", fontsize=8,
            wrap=True, transform=ax.transAxes)

    # ----------------------------------------------------------------
    # (a)/(b) Biome and chemical variable prevalence (side by side)
    # ----------------------------------------------------------------
    bio_prev  = prevalence_rows(biome_df, BIOME_VARS, 12, BIOME_MID)
    chem_prev = prevalence_rows(chem_df,  CHEM_VARS,  11, CHEM_SHORT)

    # Wider 'variable' column on the left to fit full taxon names.
    cw_prev_bio  = [0.180, 0.057, 0.057, 0.057, 0.057, 0.072]  # biome side
    cw_prev_chem = [0.155, 0.062, 0.060, 0.060, 0.060, 0.080]  # chem side

    hdr_prev = ["variable", "present in", "% of f.",
                "total occ.", "mean occ.", "class"]
    body_align_prev = ["left", "center", "center",
                       "center", "center", "center"]

    # Panel (a) biome -- left half of the page
    ax.text(0.0, 0.85,
            "(a)  Biome variable prevalence (n = 12 candidate formulas)",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)
    bottom_bio = draw_table(
        ax, x0=0.0, y_top=0.835,
        col_widths=cw_prev_bio, headers=hdr_prev,
        rows=to_rows(bio_prev),
        body_align=body_align_prev,
        row_height=0.024, header_height=0.028,
    )

    # Panel (b) chem -- right half of the page
    ax.text(0.515, 0.85,
            "(b)  Chemical variable prevalence (n = 11 candidate formulas)",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)
    bottom_chem = draw_table(
        ax, x0=0.515, y_top=0.835,
        col_widths=cw_prev_chem, headers=hdr_prev,
        rows=to_rows(chem_prev),
        body_align=body_align_prev,
        row_height=0.024, header_height=0.028,
    )
    bottom_ab = min(bottom_bio, bottom_chem)

    # Interpretation prose under (a) and (b)
    interp = (
        "Six of nine biome variables appear in every one of the 12 "
        "candidate formulas (universal class), consistent with the "
        "reproducibility of the holobiont signal. Among chemical "
        "variables, only TC and NH4-N are universal across all 11 "
        "formulas, while CEC was the least prevalent (4 of 11 "
        "formulas; low class), echoing the non-significant chemical "
        "downstream paths in the SEM ensemble (Fig. 5c)."
    )
    ax.text(0.0, bottom_ab - 0.020, interp,
            ha="left", va="top", fontsize=7.4, fontstyle="italic",
            color=TEXT, wrap=True, transform=ax.transAxes)

    # ----------------------------------------------------------------
    # (c) Six SR pairs forwarded to exhaustive SEM enumeration
    # ----------------------------------------------------------------
    y_c = bottom_ab - 0.13
    ax.text(0.0, y_c,
            "(c)  Six SR pairs forwarded to exhaustive SEM enumeration",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)

    cw_pair = [0.18, 0.18, 0.10, 0.07, 0.10, 0.10]
    # 論文表示: SR_score1 = biome (内部 sr2), SR_score2 = chemistry (内部 sr1)
    hdr_pair = ["sr_biome (SR_score1)", "sr_chem (SR_score2)",
                "p-value (χ²)", "CFI", "SRMR", "WRMR"]
    body_align_pair = ["left", "left",
                       "center", "center", "center", "center"]

    p2 = phase2.sort_values("ph2_pvalue", ascending=False).reset_index(drop=True)
    rows_pair = []
    for _, row in p2.iterrows():
        rows_pair.append([
            row["sr2"], row["sr1"],
            f"{row['ph2_pvalue']:.3f}",
            f"{row['ph2_cfi']:.2f}",
            f"{row['ph2_srmr']:.3f}",
            f"{row['ph2_wrmr']:.3f}",
        ])

    draw_table(
        ax, x0=0.0, y_top=y_c - 0.022,
        col_widths=cw_pair, headers=hdr_pair, rows=rows_pair,
        body_align=body_align_pair,
        row_height=0.026, header_height=0.030,
    )

    pdf.savefig(fig, bbox_inches=None)
    fig.savefig(OUT_PNG, dpi=300, bbox_inches=None)
    plt.close(fig)


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------
def main() -> None:
    apply_style()
    folder = INPUT_DIR.resolve()
    print(f"Input folder: {folder}")

    biome_hof = load_hall_of_fame(folder, "biome")
    chem_hof  = load_hall_of_fame(folder, "chem")
    biome_df = pd.DataFrame(build_records(biome_hof, BIOME_VARS, "biome"))
    chem_df  = pd.DataFrame(build_records(chem_hof,  CHEM_VARS,  "chem"))

    phase2 = pd.read_csv(find_file(folder, PHASE2_GLOB))

    with PdfPages(OUT_PDF) as pdf:
        render(pdf, biome_df, chem_df, phase2)

    print(f"Saved: {OUT_PDF.resolve()}")
    print(f"Saved: {OUT_PNG.resolve()}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#brew install julia 
#conda activate pysr310
#pip install --upgrade pip
#pip install pysr pandas numpy


import sys
import pandas as pd
from pysr import PySRRegressor
from collections import Counter
import re

# -------------------------
# 式から変数名を抽出
# -------------------------
def extract_variables(equation):
    # equation は必ず str であることを確認
    if not isinstance(equation, str):
        return []
    return re.findall(r"[A-Za-z_][A-Za-z0-9_]*", equation)

def main():
    if len(sys.argv) != 2:
        print("Usage: python SR_target_only_maxdepth6_loop.py data.csv")
        sys.exit(1)

    csv_file = sys.argv[1]
    df = pd.read_csv(csv_file)

    if "target" not in df.columns:
        print("Error: CSV must contain a 'target' column")
        sys.exit(1)

    # =========================
    # Prepare data
    # =========================
    X = df.drop(columns=["target"])
    y = df["target"]

    n_runs = 30
    all_equations = []
    variable_counter = Counter()

    for i in range(n_runs):
        print(f"\n=== Run {i+1}/{n_runs} ===")

        model = PySRRegressor(
            niterations=200,
            population_size=100,
            binary_operators=["+", "-", "*"],
            unary_operators=[],
            maxdepth=5,# depth5, 6, 7, 8, 9, or 10
            loss="loss(x, y) = (x - y)^2",  # simple
            multithreading=True,
            julia_kwargs={"threads": 20},
            model_selection="best",
            verbosity=0,
            random_state=i,
        )

        model.fit(X, y)

        # ★ ここが重要：Series → 式文字列だけ取得
        best_equation = model.get_best()["equation"]

        all_equations.append(best_equation)
        variable_counter.update(extract_variables(best_equation))

    # ===============================
    # 結果表示
    # ===============================
    print("\n=== Best equations from all runs ===")
    for i, eq in enumerate(all_equations, 1):
        print(f"[Run {i}] {eq}")

    print("\n=== Variable occurrence frequency ===")
    total = sum(variable_counter.values())

    freq_df = pd.DataFrame(
        [(var, count, count / total) for var, count in variable_counter.items()],
        columns=["Variable", "Count", "Frequency"]
    ).sort_values(by="Count", ascending=False)

    print(freq_df)

    # CSV 出力
    freq_df.to_csv("variable_frequency.csv", index=False)

if __name__ == "__main__":
    main()

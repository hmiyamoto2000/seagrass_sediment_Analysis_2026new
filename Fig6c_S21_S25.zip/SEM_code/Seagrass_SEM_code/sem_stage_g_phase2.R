#!/usr/bin/env Rscript
# Stage gamma Phase 2: 132 pairs x Model C3 skeleton (df=8)
# model:
#   Seagrass ~ SR1 + SR2
#   B_Desulfobulbaceae + chemical_NO3_N_log + chemical_CEC_log + chemical_K2O_log ~ Seagrass
# Benchmark: Model C3 (previous chat) -> pvalue=0.786, cfi=1.000, tli=1.111,
#            rmsea=0.000, srmr=0.036, wrmr=0.346
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT    <- "/Fig6"
DATA_IN <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
OUT_CSV <- file.path(ROOT, "phase2_sr_pair_C3skeleton_results.csv")

dat <- read_csv(DATA_IN, show_col_types = FALSE)
cat(sprintf("[Phase2] Loaded: %d rows x %d cols\n", nrow(dat), ncol(dat)))

sr_cols  <- grep("^SR_", names(dat), value = TRUE)
chem_srs <- sort(sr_cols[str_detect(sr_cols, "^SR_chem_")])
biome_srs<- sort(sr_cols[str_detect(sr_cols, "^SR_biome_")])
pairs <- expand.grid(sr1 = chem_srs, sr2 = biome_srs, stringsAsFactors = FALSE)
cat(sprintf("[Phase2] Pairs: %d\n", nrow(pairs)))

fit_one <- function(sr1, sr2, dat) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  mod <- '
    Seagrass ~ .SR1 + .SR2
    B_Desulfobulbaceae + chemical_NO3_N_log + chemical_CEC_log + chemical_K2O_log ~ Seagrass
  '
  tryCatch({
    fit <- lavaan::sem(mod, data = d, ordered = "Seagrass",
                       estimator = "WLSMV", se = "robust")
    conv <- lavaan::lavInspect(fit, "converged")
    fm <- lavaan::fitMeasures(fit, c("chisq.scaled","df","pvalue.scaled",
                                     "cfi.scaled","tli.scaled",
                                     "rmsea.scaled","rmsea.ci.lower.scaled",
                                     "rmsea.ci.upper.scaled","srmr","wrmr",
                                     "gfi","agfi"))
    pe <- lavaan::parameterEstimates(fit, standardized = TRUE)
    getp <- function(lhs, rhs) {
      r <- pe[pe$lhs==lhs & pe$op=="~" & pe$rhs==rhs, ]
      if (nrow(r)==0) list(std=NA, p=NA) else list(std=r$std.all[1], p=r$pvalue[1])
    }
    b1  <- getp("Seagrass", ".SR1");                 b2  <- getp("Seagrass", ".SR2")
    d1  <- getp("B_Desulfobulbaceae", "Seagrass")
    d2  <- getp("chemical_NO3_N_log", "Seagrass")
    d3  <- getp("chemical_CEC_log",   "Seagrass")
    d4  <- getp("chemical_K2O_log",   "Seagrass")
    tibble(sr1=sr1, sr2=sr2, converged=conv,
           chisq=unname(fm["chisq.scaled"]), df=unname(fm["df"]),
           pvalue=unname(fm["pvalue.scaled"]),
           cfi=unname(fm["cfi.scaled"]), tli=unname(fm["tli.scaled"]),
           rmsea=unname(fm["rmsea.scaled"]),
           rmsea_lo=unname(fm["rmsea.ci.lower.scaled"]),
           rmsea_hi=unname(fm["rmsea.ci.upper.scaled"]),
           srmr=unname(fm["srmr"]), wrmr=unname(fm["wrmr"]),
           gfi=unname(fm["gfi"]), agfi=unname(fm["agfi"]),
           sr1_std=b1$std, sr1_p=b1$p, sr2_std=b2$std, sr2_p=b2$p,
           desulfo_std=d1$std, desulfo_p=d1$p,
           no3_std=d2$std, no3_p=d2$p,
           cec_std=d3$std, cec_p=d3$p,
           k2o_std=d4$std, k2o_p=d4$p,
           error=NA_character_)
  }, error = function(e) {
    tibble(sr1=sr1, sr2=sr2, converged=FALSE,
           chisq=NA,df=NA,pvalue=NA,cfi=NA,tli=NA,rmsea=NA,
           rmsea_lo=NA,rmsea_hi=NA,srmr=NA,wrmr=NA,gfi=NA,agfi=NA,
           sr1_std=NA,sr1_p=NA,sr2_std=NA,sr2_p=NA,
           desulfo_std=NA,desulfo_p=NA,no3_std=NA,no3_p=NA,
           cec_std=NA,cec_p=NA,k2o_std=NA,k2o_p=NA,
           error=conditionMessage(e))
  })
}

plan(multisession, workers = 24)
cat("[Phase2] Fitting 132 SEMs with furrr 24 workers...\n")
t0 <- Sys.time()
results <- future_map2_dfr(pairs$sr1, pairs$sr2,
             ~ fit_one(.x, .y, dat),
             .options = furrr_options(seed = TRUE),
             .progress = TRUE)
cat(sprintf("[Phase2] Done in %.1f sec\n", as.numeric(Sys.time()-t0, units="secs")))

write_csv(results %>% arrange(desc(pvalue), srmr), OUT_CSV)
cat("[Phase2] Wrote -> ", OUT_CSV, "\n", sep="")

ok <- results %>% filter(converged, !is.na(pvalue))
cat(sprintf("[Phase2] Converged: %d/%d   Errors: %d\n",
            sum(results$converged, na.rm=TRUE), nrow(results),
            sum(!is.na(results$error))))

cat("\n[Phase2] Top 15 by pvalue (Model C3 benchmark: p=0.786, cfi=1.000, srmr=0.036):\n")
print(ok %>% arrange(desc(pvalue), srmr) %>% slice_head(n=15) %>%
      select(sr1, sr2, pvalue, cfi, tli, rmsea, srmr, wrmr,
             sr1_std, sr1_p, sr2_std, sr2_p, desulfo_std, desulfo_p),
      width = Inf)

cat("\n[Phase2] Fit index distributions:\n")
cat("pvalue: "); print(summary(ok$pvalue))
cat("cfi:    "); print(summary(ok$cfi))
cat("srmr:   "); print(summary(ok$srmr))
cat("rmsea:  "); print(summary(ok$rmsea))

cat("\n=== Phase 2 complete ===\n")

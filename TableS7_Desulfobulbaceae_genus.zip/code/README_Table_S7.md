# Supplementary Table S7 — Desulfobulbaceae genus-level composition

`build_table_s7_desulfobulbaceae_genus.py` decomposes the family
**Desulfobulbaceae** (the bacterial hub of the collective SEM, Fig. 6c) into its
genus-level (D_5, SILVA 132) members and contrasts seagrass vs non-seagrass
sediment, to test whether any sulfide-oxidising cable-bacteria genus supports a
cable-bacteria interpretation.

## Requirements
Python 3.10+, with: numpy, pandas, scipy
    pip install numpy pandas scipy

## Inputs (place in the same folder as the script)
| File | Description |
|---|---|
| `Bacteria_seagrass_D5_genus.csv` | 132 samples × ~1982 taxa columns; QIIME2 D_0..D_5 taxonomy strings as headers; per-sample relative abundances (%) |
| `Seagrass_list_cnd_dex250917.csv` | sample metadata: `name`, `dex` (seagrass/non), `env` (site) |

## Usage
    python3.10 build_table_s7_desulfobulbaceae_genus.py
    # or with explicit paths:
    python3.10 build_table_s7_desulfobulbaceae_genus.py <data_csv> <meta_csv>
    # writes Table_S7_Desulfobulbaceae_genus.csv next to the script

## Method
The family node is `D_3__Desulfobacterales; D_4__Desulfobulbaceae`. For each
genus-level (D_5) member, per-sample relative abundance is compared between
seagrass (n = 72) and non-seagrass (n = 60) sediment by Mann–Whitney U, with
Benjamini–Hochberg q-values across the genus-level tests.

Note: a small set of sequences labelled "uncultured Desulfobulbaceae bacterium"
sits OUTSIDE this node (under `D_3__Sva0485`) in SILVA 132 and is excluded;
its abundance is negligible (~0.02%).

## Result (Table_S7_Desulfobulbaceae_genus.csv)
- Family Desulfobulbaceae is modestly enriched in seagrass sediment
  (6.232% vs 5.334%; log2 +0.225; MWU p = 0.0345).
- **88.8%** of the family signal comes from unresolved members
  (uncultured + unassigned).
- Every named genus with a significant difference is **lower** in seagrass,
  including the sulfur-disproportionating *Desulfurivibrio* (log2 −0.82, q = 0.019).
- The cable-bacteria genus *Candidatus* Electrothrix is detected in only 5 of 132
  samples (p = 0.243) and, with no negative controls, cannot be used as evidence.

**Conclusion:** the predominant metabolic guild within Desulfobulbaceae cannot be
determined from these amplicon data; the family-level enrichment is not
attributable to cable bacteria.

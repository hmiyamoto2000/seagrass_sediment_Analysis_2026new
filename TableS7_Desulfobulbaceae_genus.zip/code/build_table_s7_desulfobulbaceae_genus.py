#!/usr/bin/env python3
"""
Supplementary Table S7
Genus-level (D_5) composition of the family Desulfobulbaceae
============================================================
Decomposes the family Desulfobulbaceae (the bacterial hub of the collective
SEM, Fig. 6c) into its genus-level (D_5, SILVA 132) members and contrasts
seagrass vs non-seagrass sediment samples. This quantifies how much of the
family-level enrichment is carried by named genera versus unresolved
(uncultured / unassigned) members, and tests whether any sulfide-oxidising
cable-bacteria genus (Candidatus Electrothrix) supports a cable-bacteria
interpretation.

Inputs (place in the same directory, or pass as arguments):
  Bacteria_seagrass_D5_genus.csv   132 samples x ~1982 taxa columns;
                                   QIIME2 D_0..D_5 taxonomy strings as headers;
                                   per-sample relative abundances summing to 100.
  Seagrass_list_cnd_dex250917.csv  sample metadata: name, dex (seagrass/non),
                                   env (site), ...

Output:
  Table_S7_Desulfobulbaceae_genus.csv

Usage:
  python3.10 build_table_s7_desulfobulbaceae_genus.py [data_csv] [meta_csv]
  (defaults to the two filenames above, resolved next to this script)
"""
import os, sys, csv
import numpy as np
import pandas as pd
from scipy import stats

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def resolve(arg, default):
    if arg:
        return arg
    p = os.path.join(SCRIPT_DIR, default)
    return p if os.path.exists(p) else default

def d5_label(col: str) -> str:
    """Genus (D_5) label from a QIIME2 taxonomy string; '(unassigned)' if empty."""
    tail = col.split(";")[-1].strip()
    if tail in ("__", ""):
        return "(unassigned)"
    if tail.startswith("D_5__"):
        v = tail.replace("D_5__", "").strip()
        return v if v else "(unassigned)"
    return tail

def bh_qvalues(pvals):
    """Benjamini-Hochberg q-values for a list of p-values."""
    m = len(pvals)
    q = [None] * m
    prev = 1.0
    for rank, i in enumerate(sorted(range(m), key=lambda i: pvals[i])[::-1]):
        k = m - rank
        prev = min(prev, pvals[i] * m / k)
        q[i] = prev
    return q

def main():
    data_csv = resolve(sys.argv[1] if len(sys.argv) > 1 else None,
                       "Bacteria_seagrass_D5_genus.csv")
    meta_csv = resolve(sys.argv[2] if len(sys.argv) > 2 else None,
                       "Seagrass_list_cnd_dex250917.csv")
    print(f"[S7] data = {data_csv}")
    print(f"[S7] meta = {meta_csv}")

    df = pd.read_csv(data_csv)
    meta = pd.read_csv(meta_csv)
    df = df.merge(meta[["name", "dex", "env"]], on="name")
    sg = df[df.dex == "seagrass"]
    non = df[df.dex == "non"]
    print(f"[S7] seagrass n = {len(sg)}, non-seagrass n = {len(non)}")

    # Family node: D_3 Desulfobacterales ; D_4 Desulfobulbaceae (the manuscript's hub).
    # (Sva0485-affiliated 'uncultured Desulfobulbaceae bacterium' sits OUTSIDE this
    #  node in SILVA 132 and is excluded here; its abundance is negligible, ~0.02%.)
    fam_cols = [c for c in df.columns
                if "D_4__Desulfobulbaceae" in c and "D_3__Desulfobacterales" in c]
    print(f"[S7] genus-level columns under Desulfobulbaceae: {len(fam_cols)}")

    rows = []
    for c in fam_cols:
        s, n = sg[c], non[c]
        sm, nm = s.mean(), n.mean()
        u, p = stats.mannwhitneyu(s, n, alternative="two-sided")
        lg = np.log2((sm + 1e-9) / (nm + 1e-9))
        rows.append([d5_label(c), sm, nm, lg, p])
    qs = bh_qvalues([r[4] for r in rows])
    for r, q in zip(rows, qs):
        r.append(q)
    rows.sort(key=lambda r: -r[1])  # by seagrass abundance desc

    fs = sg[fam_cols].sum(axis=1)
    fn = non[fam_cols].sum(axis=1)
    u, fp = stats.mannwhitneyu(fs, fn, alternative="two-sided")
    flg = np.log2(fs.mean() / fn.mean())

    unclassified = sum(sm for d5, sm, nm, lg, p, q in rows
                       if d5 in ("uncultured", "(unassigned)"))
    share = 100 * unclassified / fs.mean()

    out = os.path.join(SCRIPT_DIR, "Table_S7_Desulfobulbaceae_genus.csv")
    with open(out, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["D_5_genus", "seagrass_mean_pct", "non_mean_pct",
                    "log2_SG_over_non", "MWU_p", "BH_q"])
        w.writerow(["Desulfobulbaceae (family total)",
                    f"{fs.mean():.3f}", f"{fn.mean():.3f}", f"{flg:+.3f}",
                    f"{fp:.4f}", "-"])
        for d5, sm, nm, lg, p, q in rows:
            w.writerow([d5, f"{sm:.3f}", f"{nm:.3f}", f"{lg:+.2f}",
                        f"{p:.3f}", f"{q:.3f}"])
    print(f"[S7] wrote -> {out}")

    # Console summary
    print(f"\n[S7] Family Desulfobulbaceae: seagrass {fs.mean():.3f}% vs non {fn.mean():.3f}% "
          f"(log2 {flg:+.3f}, MWU p = {fp:.4f})")
    print(f"[S7] Unresolved members (uncultured + unassigned) = {share:.1f}% of the family signal")
    print(f"[S7] Named genera with q < 0.05:")
    for d5, sm, nm, lg, p, q in rows:
        if d5 not in ("uncultured", "(unassigned)") and q < 0.05:
            print(f"       {d5}: log2 {lg:+.2f}, q = {q:.3f} "
                  f"({'higher' if lg > 0 else 'lower'} in seagrass)")

if __name__ == "__main__":
    main()

# ================================================
# XGBoost 完全版：SHAPプラスアルファ
# ================================================

# 保存先ディレクトリ
outdir <- "./Result_AA_RF_XG"
dir.create(outdir, showWarnings = FALSE, recursive = TRUE)

# ライブラリ 
library(xgboost)
library(iml)
library(data.table)
library(ggplot2)
library(reshape2)
library(dplyr)

options(na.action = 'na.pass')

# 2. データ読み込み
data <- read.csv("MBA_selected_MLraws.csv")
X <- data[, -1]
y0 <- data$target
y1 <- as.factor(y0)
y <- as.integer(y1) - 1
num_class <- length(unique(y))

# 3. Multi-class / Binary 自動切り替え 
if (num_class == 2) {
  param <- list(
    objective = "binary:logistic",
    eval_metric = "logloss"
  )
} else {
  param <- list(
    objective = "multi:softprob",
    eval_metric = "mlogloss",
    num_class = num_class
  )
}

# 4. XGBoost CV → best_nrounds 自動選択 
dtrain <- xgb.DMatrix(as.matrix(X), label = y)
k <- round(1 + log2(nrow(X)))
cv.nround <- 100

set.seed(131)
bst.cv <- xgb.cv(
  params = param,
  data = dtrain,
  nrounds = cv.nround,
  nfold = k,
  verbose = 0,
  early_stopping_rounds = 20
)
best_nround <- bst.cv$best_iteration
cat("✔ Best nround =", best_nround, "\n")

#  5. 最終モデル学習
model <- xgb.train(
  params = param,
  data = dtrain,
  nrounds = best_nround,
  verbose = 0
)

#  6. SHAP 用 iml Predictor ---
predict_function <- function(model, newdata, class_index=NULL) {
  pred <- predict(model, as.matrix(newdata))
  if (num_class == 2) {
    return(pred)
  } else {
    pred_matrix <- matrix(pred, ncol = num_class, byrow = TRUE)
    if (is.null(class_index)) return(pred_matrix)
    return(pred_matrix[, class_index])
  }
}

# --- 7. SHAP 計算 ---
shap_list <- list()

if (num_class == 2) {
  predictor <- Predictor$new(model = model, data = X, y = y,
                             predict.fun = function(newdata) predict_function(model, newdata))
  n_samples <- nrow(X)
  shap_list[[1]] <- lapply(1:n_samples, function(i) {
    shap <- Shapley$new(predictor, x.interest = X[i, ])
    shap$results$phi
  })
  shap_matrix <- do.call(rbind, shap_list[[1]])
  mean_abs_shap <- colMeans(abs(shap_matrix))
  shap_dt <- data.table(Feature = colnames(X), SHAP = mean_abs_shap, Class="Class_1")
} else {
  # 多クラス：各クラスごとに計算
  for (cls in 0:(num_class-1)) {
    cat("Computing SHAP for class", cls, "\n")
    predictor_cls <- Predictor$new(
      model = model,
      data = X,
      y = y,
      predict.fun = function(newdata) predict_function(model, newdata, class_index=cls+1)
    )
    n_samples <- nrow(X)
    shap_cls_list <- lapply(1:n_samples, function(i) {
      shap <- Shapley$new(predictor_cls, x.interest = X[i, ])
      shap$results$phi
    })
    shap_matrix_cls <- do.call(rbind, shap_cls_list)
    mean_abs_shap_cls <- colMeans(abs(shap_matrix_cls))
    shap_dt_cls <- data.table(
      Feature = colnames(X),
      SHAP = mean_abs_shap_cls,
      Class = paste0("Class_", cls)
    )
    shap_list[[cls+1]] <- shap_dt_cls
  }
  shap_dt <- rbindlist(shap_list)
}

# --- 8. XGBoost Gain 重要度 ---
imp_raw <- xgb.importance(feature_names = colnames(X), model = model)
gain_dt <- data.table(Feature = imp_raw$Feature, Gain = imp_raw$Gain)

# --- 9. SHAP + Gain 結合 ---
merged <- merge(gain_dt, shap_dt, by = "Feature", all = TRUE)
df_long <- melt(merged, id.vars = c("Feature", "Class"),
                variable.name = "Method", value.name = "Importance")

# --- 10. 並列棒グラフ（Gain vs SHAP） ---
for (cls in unique(df_long$Class)) {
  df_plot <- df_long[df_long$Class == cls, ]
  p <- ggplot(df_plot, aes(x = reorder(Feature, Importance), y = Importance, fill = Method)) +
    geom_bar(stat = "identity", position = position_dodge()) +
    coord_flip() +
    scale_fill_manual(values = c("Gain" = "skyblue", "SHAP" = "darkorange")) +
    labs(title = paste0("XGBoost Feature Importance: Gain vs SHAP (", cls, ")"),
         x = "Feature", y = "Importance") +
    theme_minimal()
  ggsave(sprintf("%s/XGBoost_Gain_vs_SHAP_%s.png", outdir, cls),
         p, width = 10, height = 8, dpi = 300)
}

# --- 11. Gain / SHAP 個別グラフ ---
# Gain only
p_gain <- ggplot(gain_dt, aes(x = reorder(Feature, Gain), y = Gain)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_flip() +
  theme_minimal() +
  labs(title = "XGBoost Feature Importance (Gain)")
ggsave(sprintf("%s/XGBoost_Gain_only.png", outdir), p_gain, width = 9, height = 7, dpi = 300)

# SHAP only
for (cls in unique(shap_dt$Class)) {
  shap_cls_dt <- shap_dt[Class == cls]
  p_shap <- ggplot(shap_cls_dt, aes(x = reorder(Feature, SHAP), y = SHAP)) +
    geom_bar(stat = "identity", fill = "darkorange") +
    coord_flip() +
    theme_minimal() +
    labs(title = paste0("XGBoost Feature Importance (SHAP) - ", cls))
  ggsave(sprintf("%s/XGBoost_SHAP_only_%s.png", outdir, cls),
         p_shap, width = 9, height = 7, dpi = 300)
}

# --- 12. PDF にまとめて保存 ---
pdf(sprintf("%s/XGBoost_FeatureImportance.pdf", outdir), width = 10, height = 8)
for (cls in unique(df_long$Class)) {
  df_plot <- df_long[df_long$Class == cls, ]
  p <- ggplot(df_plot, aes(x = reorder(Feature, Importance), y = Importance, fill = Method)) +
    geom_bar(stat = "identity", position = position_dodge()) +
    coord_flip() +
    scale_fill_manual(values = c("Gain" = "skyblue", "SHAP" = "darkorange")) +
    labs(title = paste0("XGBoost Feature Importance: Gain vs SHAP (", cls, ")"),
         x = "Feature", y = "Importance") +
    theme_minimal()
  print(p)
}
print(p_gain)
dev.off()

# --- 13. CSV 出力 ---
fwrite(gain_dt, sprintf("%s/XGBoost_importance_gain.csv", outdir))
fwrite(shap_dt, sprintf("%s/XGBoost_importance_SHAP.csv", outdir))
fwrite(merged, sprintf("%s/XGBoost_Gain_vs_SHAP.csv", outdir))
fwrite(df_long, sprintf("%s/XGBoost_LongFormat.csv", outdir))

cat("✔ XGBoost SHAP + Gain 完全版（多クラス対応）が正常終了しました\n")

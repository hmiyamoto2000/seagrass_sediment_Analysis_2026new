# =============================================================================
# Supplementary Fig. S23 — SR pair composition across the 505 universal models
# -----------------------------------------------------------------------------
# このスクリプトは出力をそのまま図版として使えることを目的とする。
# Adobe などでラベルを後から入れ替える必要はない（入れ替えると
# データとラベルが食い違うため、過去に実際にその事故が起きている）。
#
# 旧 GitHub 版からの変更点:
#   1. strict 505 への絞り込みを追加（旧版は 697 行をそのまま使用）
#   2. 図中の "697" 表記をすべて TOTAL 参照に変更
#   3. 副題の「12通り中5通り」→「列挙した6ペア中5ペア」
#        Sum_k C(18,k) = 63,003;  63,003 x 6   = 378,018   (実行)
#                                 63,003 x 132 = 8,316,396 (理論最大)
#        4 chem x 3 biome = 12 は観測5ペアに現れた variant の事後的な直積
#   4. SR の対応と表示順を冒頭の1ブロックに集約（下記）
#   5. パネル b を X = SR_score1 (biome) / Y = SR_score2 (chemistry) に
#   6. 列の取り違えを実行時に検出するガードを追加
#
# 入力: phase7_universal_candidates.csv
# =============================================================================

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(ggplot2); library(patchwork); library(tidyr); library(stringr)
})

# =============================================================================
# SR の対応定義 — 変更が必要ならここだけを直す
# -----------------------------------------------------------------------------
#   内部列        論文表示        内容        Fig. 6c の係数
#     sr2    ->   SR_score1   ->  biome          +0.81
#     sr1    ->   SR_score2   ->  chemistry      +0.28
#
#   本文 Fig. 6c:
#     "Two latent regressors — SR_score1 (biome) and SR_score2 (chemistry) —
#      loaded positively on the binary Seagrass node (+0.81 and +0.28)"
#
#   表示順は biome -> chemistry。GROUP_LEVELS がこれを固定するので、
#   ラベル文字列を変えても並びは崩れない（アルファベット順に依存しない）。
# =============================================================================
LAB_BIOME <- "Biome (SR_score1)"
LAB_CHEM  <- "Chemical (SR_score2)"
GROUP_LEVELS <- c(LAB_BIOME, LAB_CHEM)   # 左 -> 右 / X -> Y の順

# どちらの列が biome / chemical かは下で「中身」から自動判定する。
# sr1 / sr2 の対応は版によって入れ替わっていることがあるため、位置では決めない。

FIG <- "S23"   # 現行の補足図番号（旧ファイル名に合わせるなら "S22"）

# パネル a の棒ラベルに接頭辞 SR_biome_ / SR_chem_ を残すか
#   TRUE  … ラベルは長くなるが、ファセット見出しとの取り違えが目視で分かる
#   FALSE … d9_c27 のような短縮表示（公開 PDF と同じ）
KEEP_PREFIX <- FALSE

# パネル b の向き
#   FALSE … X = Chemical (SR_score2, 4 variant) / Y = Biome (SR_score1, 3 variant)
#           variant 数の多いほうを横に置くので横長になり、紙面に収まりが良い。
#           公開済み PDF と同じ向き。
#   TRUE  … X = Biome (SR_score1) / Y = Chemical (SR_score2)
#           パネル a の左->右（Biome -> Chemical）と同じ順序だが 3列x4行で縦長。
PANEL_B_X_IS_BIOME <- FALSE

# ---- 読み込みと strict 505 への絞り込み -------------------------------------
u <- read_csv("phase7_universal_candidates.csv", show_col_types=FALSE)
n_all <- nrow(u)
u <- u %>% filter(tli >= 0.95, agfi >= 0.95)
TOTAL <- nrow(u)
cat(sprintf("Universal candidates: %d -> %d after TLI>=0.95 & AGFI>=0.95\n", n_all, TOTAL))
stopifnot(TOTAL == 505)

# ---- どちらの列が biome / chemical かを「中身」から判定 ----------------------
# sr1 / sr2 の対応は版によって入れ替わっていることがあるため、
# 列の位置では決めず、値の接頭辞で判定する。
SR_COLS <- c("sr1", "sr2")
if (!all(SR_COLS %in% names(u)))
  stop("sr1 / sr2 列が見つかりません。実際の列名: ", paste(names(u), collapse=", "))

.show <- function() paste(vapply(SR_COLS, function(cl)
  sprintf("  %s: %s", cl, paste(sort(unique(u[[cl]])), collapse=" | ")),
  character(1)), collapse="\n")

hit_biome <- SR_COLS[vapply(SR_COLS, function(cl) all(grepl("^SR_biome", u[[cl]])), logical(1))]
hit_chem  <- SR_COLS[vapply(SR_COLS, function(cl) all(grepl("^SR_chem",  u[[cl]])), logical(1))]

if (length(hit_biome) != 1 || length(hit_chem) != 1 || hit_biome == hit_chem)
  stop("biome / chemical の列を特定できません。CSV の実際の中身:\n", .show())

u$sr_biome <- u[[hit_biome]]   # 以降はこの固定名だけを使う
u$sr_chem  <- u[[hit_chem]]
cat(sprintf("Detected: %s -> %s ; %s -> %s\n",
            hit_biome, LAB_BIOME, hit_chem, LAB_CHEM))

strip <- function(x, pre) if (KEEP_PREFIX) x else str_replace(x, pre, "")

# ---- Panel A: variant ごとの出現率 ------------------------------------------
biome_freq <- u %>% count(sr_biome, name="n") %>%
  mutate(pct=100*n/TOTAL, group=LAB_BIOME, variant=strip(sr_biome, "SR_biome_"))
chem_freq <- u %>% count(sr_chem, name="n") %>%
  mutate(pct=100*n/TOTAL, group=LAB_CHEM,  variant=strip(sr_chem, "SR_chem_"))

variant_df <- bind_rows(biome_freq %>% select(group, variant, n, pct),
                        chem_freq  %>% select(group, variant, n, pct)) %>%
  mutate(group = factor(group, levels=GROUP_LEVELS))   # 表示順を固定

pA <- ggplot(variant_df, aes(x=variant, y=pct, fill=group)) +
  geom_col(alpha=0.85) +
  geom_text(aes(label=sprintf("%.1f%%\n(n=%d)", pct, n)),
            vjust=-0.3, size=3) +
  facet_wrap(~group, scales="free_x") +
  scale_fill_manual(values=setNames(c("#FFB347", "#FFF2CC"), GROUP_LEVELS)) +
  scale_y_continuous(limits=c(0, NA), expand=expansion(mult=c(0, 0.18))) +
  labs(x="SR variant (depth_complexity)",
       y=sprintf("Presence in %d Universal models (%%)", TOTAL),
       title=sprintf("A. SR variant frequency (%d Universal models)", TOTAL),
       subtitle=sprintf("Each Universal model uses one %s and one %s variant",
                        LAB_BIOME, LAB_CHEM)) +
  theme_classic(base_size=11) +
  theme(legend.position="none",
        panel.grid=element_blank(),
        plot.subtitle=element_text(size=9, color="grey40"))

# ---- Panel B: ペアのヒートマップ --------------------------------------------
# X = SR_score1 (biome), Y = SR_score2 (chemistry) — パネル a と同じ順序
pair_df <- u %>% count(sr_biome, sr_chem, name="n") %>%
  mutate(pct=100*n/TOTAL,
         biome_var=strip(sr_biome, "SR_biome_"),
         chem_var =strip(sr_chem,  "SR_chem_"))

pB_x    <- if (PANEL_B_X_IS_BIOME) "biome_var" else "chem_var"
pB_y    <- if (PANEL_B_X_IS_BIOME) "chem_var"  else "biome_var"
pB_xlab <- if (PANEL_B_X_IS_BIOME) LAB_BIOME   else LAB_CHEM
pB_ylab <- if (PANEL_B_X_IS_BIOME) LAB_CHEM    else LAB_BIOME

pB <- ggplot(pair_df, aes(x=.data[[pB_x]], y=.data[[pB_y]], fill=pct)) +
  geom_tile(color="white", linewidth=0.5) +
  geom_text(aes(label=sprintf("n=%d\n%.1f%%", n, pct)), size=3.5) +
  scale_fill_gradient(low="#F5F5F5", high="forestgreen",
                      name=sprintf("%% of %d", TOTAL)) +
  labs(x=sprintf("%s variant (depth_complexity)", pB_xlab),
       y=sprintf("%s variant (depth_complexity)", pB_ylab),
       title=sprintf("B. SR pair composition (%d observed pairs)", nrow(pair_df)),
       subtitle="Cells show number and % of Universal models with each SR pair") +
  theme_classic(base_size=11) +
  theme(panel.grid=element_blank(),
        plot.subtitle=element_text(size=9, color="grey40"))

# ---- 結合 -------------------------------------------------------------------
combined <- pA / pB +
  plot_annotation(
    title = sprintf("Supplementary Fig. %s  SR pair composition across %d Universal models",
                    FIG, TOTAL),
    subtitle = sprintf(paste0("Five of the six enumerated SR pairs appeared in Universal models; ",
                              "the surviving variants comprise %d biome and %d chemical SR formulas."),
                       nrow(biome_freq), nrow(chem_freq)),
    theme = theme(plot.title=element_text(size=12, face="bold"),
                  plot.subtitle=element_text(size=9, color="grey30")))

# ---- Source Data ------------------------------------------------------------
write_csv(variant_df, sprintf("Supp_Fig_%s_panel_a_variant_frequency.csv", FIG))
write_csv(pair_df,    sprintf("Supp_Fig_%s_panel_b_pair_composition.csv",  FIG))
cat(sprintf("Saved Source Data: Supp_Fig_%s_panel_a_variant_frequency.csv, Supp_Fig_%s_panel_b_pair_composition.csv\n",
            FIG, FIG))

ggsave(sprintf("Supp_Fig_%s_SR_pair_composition.pdf", FIG), combined, width=12, height=10)
ggsave(sprintf("Supp_Fig_%s_SR_pair_composition.png", FIG), combined, width=12, height=10, dpi=300)
cat(sprintf("Saved Supp_Fig_%s_SR_pair_composition\n", FIG))

print(pair_df %>% arrange(desc(n)))

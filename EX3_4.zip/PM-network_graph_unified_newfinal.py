#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Precision matrix の上位25%をネットワーク＋ヒートマップ等で可視化（統合版）
#
# 変更点:
#   - 先頭の FONT_* 定数で全プロットのフォントサイズを一括変更可能
#   - clustermap を三角形（下三角のみ）表示に変更
#
# 使い方:
#   python3 PM-network_graph_unified.py input.csv

import sys
import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import seaborn as sns
import matplotlib as mpl
from matplotlib.lines import Line2D
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import pdist

# =========================================================
# ★★ フォント設定（ここだけ書き換えれば全図に反映されます） ★★
# =========================================================
FONT_FAMILY        = "Helvetica"
FONT_SIZE_BASE     = 16   # 基本サイズ（指定が無い箇所すべて）
FONT_SIZE_TITLE    = 18   # 図タイトル
FONT_SIZE_LABEL    = 16   # 軸ラベル / カラーバーラベル
FONT_SIZE_TICK     = 14    # 目盛りラベル / ヒートマップの行・列名
FONT_SIZE_LEGEND   = 16   # 凡例
FONT_SIZE_NODE     = 10   # ネットワーク図のノードラベル
FONT_SIZE_SUPTITLE = 16   # clustermap の suptitle

# matplotlib rcParams に反映（個別指定の無い箇所すべてに効きます）
mpl.rcParams["font.family"]      = FONT_FAMILY
mpl.rcParams["font.size"]        = FONT_SIZE_BASE
mpl.rcParams["axes.titlesize"]   = FONT_SIZE_TITLE
mpl.rcParams["axes.labelsize"]   = FONT_SIZE_LABEL
mpl.rcParams["xtick.labelsize"]  = FONT_SIZE_TICK
mpl.rcParams["ytick.labelsize"]  = FONT_SIZE_TICK
mpl.rcParams["legend.fontsize"]  = FONT_SIZE_LEGEND
mpl.rcParams["figure.titlesize"] = FONT_SIZE_SUPTITLE
mpl.rcParams["pdf.fonttype"]     = 42
mpl.rcParams["ps.fonttype"]      = 42

# =========================
# CSV読み込み
# =========================
filename = sys.argv[1]
df = pd.read_csv(filename, index_col=0)
print("Data shape:", df.shape)

# =========================
# 共分散・Precision matrix
# =========================
cov_matrix = np.cov(df.values, rowvar=False)
inv_cov   = np.linalg.pinv(cov_matrix)
cols      = df.columns.tolist()
n         = len(cols)

# =========================
# 出力フォルダ
# =========================
output_dir = "Network_Output"
os.makedirs(output_dir, exist_ok=True)

# =========================
# 閾値
# =========================
abs_vals_all    = np.abs(inv_cov[np.triu_indices_from(inv_cov, k=1)])
threshold_25pct = np.percentile(abs_vals_all, 75)
fixed_threshold = 0.05
print(f"Top 25% threshold (75 percentile): {threshold_25pct:.5f}")

# =========================
# Histogram（通常）
# =========================
plt.figure(figsize=(6, 4))
sns.histplot(abs_vals_all, bins=50, color="gray")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red",   linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element|")
plt.ylabel("Frequency")
plt.title("Distribution of |Precision matrix elements|")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_histogram.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# Histogram（log）
# =========================
plt.figure(figsize=(6, 4))
sns.histplot(abs_vals_all, bins=50, color="gray")
plt.xscale("log")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red",   linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element| (log scale)")
plt.ylabel("Frequency")
plt.title("Distribution of |Precision matrix elements| (log scale)")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_histogram_logscale.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# CDF
# =========================
sorted_vals = np.sort(abs_vals_all)
cdf = np.arange(1, len(sorted_vals) + 1) / len(sorted_vals)
plt.figure(figsize=(5, 4))
plt.plot(sorted_vals, cdf, color="black")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red",   linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element|")
plt.ylabel("Cumulative proportion")
plt.title("CDF of |Precision matrix elements|")
plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_matrix_cdf.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# CSV出力
# =========================
records = []
for i in range(n):
    for j in range(i + 1, n):
        val = inv_cov[i, j]
        records.append({
            "node_1": cols[i],
            "node_2": cols[j],
            "precision_ij": val,
            "abs_precision_ij": abs(val),
            "above_fixed_0.05": abs(val) > fixed_threshold,
            "above_top25pct":   abs(val) >= threshold_25pct,
            "sign": "positive" if val > 0 else "negative"
        })
edges_df = pd.DataFrame(records)
edges_df.to_csv(os.path.join(output_dir, "precision_matrix_all_pairs.csv"), index=False)
print("Precision table saved to CSV.")

# =========================
# Precision matrix → DataFrame（heatmap用）
# =========================
prec_df = pd.DataFrame(inv_cov, index=cols, columns=cols)

# 対角成分を除いたときの対称スケール
off_diag = inv_cov.copy()
np.fill_diagonal(off_diag, 0)
vmax = np.max(np.abs(off_diag))
vmin = -vmax

# -------- Heatmap 1: 全要素 --------
plt.figure(figsize=(max(8, 0.45 * n), max(7, 0.4 * n)))
sns.heatmap(
    prec_df, cmap="RdBu_r", center=0, vmin=vmin, vmax=vmax,
    square=True, linewidths=0.3, linecolor="white",
    cbar_kws={"label": "Precision (off-diagonal scale)"}
)
plt.title("Precision matrix heatmap (full)")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "Precision_heatmap_full.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(output_dir, "Precision_heatmap_full.pdf"),            bbox_inches="tight")
plt.close()

# -------- Heatmap 2: 上位25%のみ表示 --------
mask_top = np.abs(inv_cov) < threshold_25pct   # 閾値未満を隠す
prec_masked = prec_df.mask(mask_top)
plt.figure(figsize=(max(8, 0.45 * n), max(7, 0.4 * n)))
sns.heatmap(
    prec_masked, cmap="RdBu_r", center=0, vmin=vmin, vmax=vmax,
    square=True, linewidths=0.3, linecolor="lightgray",
    cbar_kws={"label": "Precision (top 25% only)"}
)
plt.title("Precision matrix heatmap (Top 25% only)")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "Precision_heatmap_top25.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(output_dir, "Precision_heatmap_top25.pdf"),            bbox_inches="tight")
plt.close()

# -------- Clustered heatmap（階層クラスタリング・三角形表示） --------
# clustermap は内部で行・列を並べ替えるので、
# 1) 先に linkage を計算して並び順 (order) を取得
# 2) その並べ替え後に上三角になるようなマスクを「元の座標で」作成
# 3) 行・列に同じ linkage を渡してクラスタリング順を一致させ、上 dendrogram は非表示にする
try:
    # 行ベクトル間の Euclidean 距離 + average linkage（symmetric な並びになる）
    link  = linkage(pdist(prec_df.values), method="average")
    order = leaves_list(link)
    inv_order = np.argsort(order)

    # 並べ替え後に「上三角」となるよう、元座標でマスクを構築
    # mask_displayed[i, j] = (i < j) になるようにする
    mask_orig = inv_order[:, None] < inv_order[None, :]
    mask_df   = pd.DataFrame(mask_orig, index=prec_df.index, columns=prec_df.columns)

    g = sns.clustermap(
        prec_df, cmap="RdBu_r", center=0, vmin=vmin, vmax=vmax,
        figsize=(max(9, 0.5 * n), max(9, 0.5 * n)),
        linewidths=0.2, linecolor="white",
        row_linkage=link, col_linkage=link,
        mask=mask_df,
        cbar_kws={"label": "Precision"},
        xticklabels=True, yticklabels=True,
    )
    # 三角形をきれいに見せるため、上側 dendrogram は非表示（左側だけ残す）
    g.ax_col_dendrogram.set_visible(False)

    # 目盛りフォントサイズを明示的に再設定
    g.ax_heatmap.tick_params(axis="x", labelsize=FONT_SIZE_TICK)
    g.ax_heatmap.tick_params(axis="y", labelsize=FONT_SIZE_TICK)
    # カラーバーのラベルサイズ
    cbar = g.ax_heatmap.collections[0].colorbar
    if cbar is not None:
        cbar.ax.tick_params(labelsize=FONT_SIZE_TICK)
        cbar.set_label("Precision", fontsize=FONT_SIZE_LABEL)

    g.fig.suptitle("Precision matrix clustermap (lower triangle)",
                   y=1.02, fontsize=FONT_SIZE_SUPTITLE)
    g.savefig(os.path.join(output_dir, "Precision_clustermap.png"), dpi=300, bbox_inches="tight")
    g.savefig(os.path.join(output_dir, "Precision_clustermap.pdf"),            bbox_inches="tight")
    plt.close()
except Exception as e:
    print(f"[WARN] clustermap failed: {e}")

# =========================
# ノード色
# =========================
def node_color(nm):
    s = str(nm)
    if s.startswith("B_"):     return "lightblue"
    if s.startswith("E_"):     return "lightgreen"
    if s.startswith("Chem_"):  return "gold"
    return "gray"

# =========================
# ラベルをノード外側に配置するヘルパー
# =========================
def offset_label_positions(pos, offset=0.08):
    """レイアウトの重心から見て外向きにラベルを少し押し出す"""
    xs = np.array([p[0] for p in pos.values()])
    ys = np.array([p[1] for p in pos.values()])
    cx, cy = xs.mean(), ys.mean()
    new_pos = {}
    for k, (x, y) in pos.items():
        dx, dy = x - cx, y - cy
        norm = np.sqrt(dx * dx + dy * dy)
        if norm < 1e-9:
            new_pos[k] = (x, y)
        else:
            new_pos[k] = (x + offset * dx / norm, y + offset * dy / norm)
    return new_pos

# =========================
# 共通のネットワーク描画関数
# =========================
def draw_network(G, pos, out_basename, title):
    edges = list(G.edges(data=True))
    weights = np.array([abs(d["weight"]) for (_, _, d) in edges])
    if len(weights) > 0:
        scaled = np.sqrt(weights)
        edge_widths = 0.5 + 4 * (scaled / scaled.max())
    else:
        edge_widths = []
    edge_colors = ["green" if d["weight"] > 0 else "violet" for (_, _, d) in edges]

    imp_vals = np.array([np.sum(np.abs(inv_cov[cols.index(nd)])) for nd in G.nodes()])
    if imp_vals.max() > 0:
        node_sizes = 300 + 1700 * (imp_vals / imp_vals.max())
    else:
        node_sizes = np.full_like(imp_vals, 500)

    node_colors = [node_color(nd) for nd in G.nodes()]

    plt.figure(figsize=(16, 16))
    nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors,
                           edgecolors="black", linewidths=0.5)
    nx.draw_networkx_edges(G, pos, width=edge_widths, edge_color=edge_colors, alpha=0.45)

    # ラベルは外側にずらす
    label_pos = offset_label_positions(pos, offset=0.07)
    nx.draw_networkx_labels(
        G, label_pos,
        font_size=FONT_SIZE_NODE, font_family=FONT_FAMILY,
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.75, pad=1.0)
    )

    # 凡例（B_ / E_ / Chem_ のうち存在するものだけ）
    node_names = list(G.nodes())
    has_B    = any(str(nd).startswith("B_")    for nd in node_names)
    has_E    = any(str(nd).startswith("E_")    for nd in node_names)
    has_Chem = any(str(nd).startswith("Chem_") for nd in node_names)

    legend_elements = [
        Line2D([0], [0], color='green',  lw=2, label='Positive edge'),
        Line2D([0], [0], color='violet', lw=2, label='Negative edge'),
    ]
    if has_B:
        legend_elements.append(Line2D([0], [0], marker='o', color='w', label='B_',
                                      markerfacecolor='lightblue',  markersize=12, markeredgecolor='black'))
    if has_E:
        legend_elements.append(Line2D([0], [0], marker='o', color='w', label='E_',
                                      markerfacecolor='lightgreen', markersize=12, markeredgecolor='black'))
    if has_Chem:
        legend_elements.append(Line2D([0], [0], marker='o', color='w', label='Chem_',
                                      markerfacecolor='gold',       markersize=12, markeredgecolor='black'))

    # プロット範囲を少し広げてラベル見切れを防ぐ
    xs = [p[0] for p in label_pos.values()]
    ys = [p[1] for p in label_pos.values()]
    pad_x = (max(xs) - min(xs)) * 0.15 + 0.05
    pad_y = (max(ys) - min(ys)) * 0.15 + 0.05
    plt.xlim(min(xs) - pad_x, max(xs) + pad_x)
    plt.ylim(min(ys) - pad_y, max(ys) + pad_y)

    plt.legend(
        handles=legend_elements,
        loc='upper left',
        bbox_to_anchor=(1.02, 1.0),
        fontsize=FONT_SIZE_LEGEND,
        frameon=True,
        borderaxespad=0.
    )

    plt.title(title, fontsize=FONT_SIZE_TITLE)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, out_basename + ".png"), dpi=300, bbox_inches="tight")
    plt.savefig(os.path.join(output_dir, out_basename + ".pdf"),            bbox_inches="tight")
    plt.close()

# =========================
# ネットワーク構築（上位25%）
# =========================
mask = np.abs(inv_cov) >= threshold_25pct
np.fill_diagonal(mask, 0)
G = nx.from_numpy_array(inv_cov * mask)
G = nx.relabel_nodes(G, dict(enumerate(cols)))

# --- Spring layout（広めに展開） ---
k_value = 4.0 / np.sqrt(max(1, G.number_of_nodes()))
pos_spring = nx.spring_layout(G, seed=42, k=k_value, iterations=500)
draw_network(G, pos_spring, "Network_top25pct",
             "Precision matrix Network (Top 25%, spring layout)")
print("Spring-layout network saved.")

# --- Circular layout（重なりを避けるのに有効） ---
pos_circ = nx.circular_layout(G)
draw_network(G, pos_circ, "Network_top25pct_circular",
             "Precision matrix Network (Top 25%, circular layout)")
print("Circular-layout network saved.")

# =========================
# Bipartite graph
# =========================
top_edges = edges_df[edges_df["above_top25pct"]].copy()
if not top_edges.empty:
    left_nodes  = sorted(set(top_edges["node_1"]))
    right_nodes = sorted(set(top_edges["node_2"]))

    B = nx.Graph()
    B.add_nodes_from(left_nodes,  bipartite=0)
    B.add_nodes_from(right_nodes, bipartite=1)
    for _, row in top_edges.iterrows():
        B.add_edge(row["node_1"], row["node_2"], weight=row["precision_ij"])

    pos = {}
    pos.update({nd: (0, i) for i, nd in enumerate(left_nodes)})
    pos.update({nd: (1, i) for i, nd in enumerate(right_nodes)})

    weights = np.array([abs(d["weight"]) for (_, _, d) in B.edges(data=True)])
    if len(weights) > 0:
        scaled = np.sqrt(weights)
        edge_widths = 0.5 + 4 * (scaled / scaled.max())
    else:
        edge_widths = []
    edge_colors = ["green" if d["weight"] > 0 else "violet" for (_, _, d) in B.edges(data=True)]

    plt.figure(figsize=(14, max(8, 0.4 * max(len(left_nodes), len(right_nodes)))))
    nx.draw_networkx_nodes(B, pos, nodelist=left_nodes,  node_color="skyblue",
                           node_size=700, edgecolors="black", linewidths=0.5)
    nx.draw_networkx_nodes(B, pos, nodelist=right_nodes, node_color="lightgreen",
                           node_size=700, edgecolors="black", linewidths=0.5)
    nx.draw_networkx_edges(B, pos, width=edge_widths, edge_color=edge_colors, alpha=0.5)
    nx.draw_networkx_labels(B, pos, font_size=FONT_SIZE_NODE, font_family=FONT_FAMILY)

    legend_elements_bipartite = [
        Line2D([0], [0], color='green',  lw=2, label='Positive edge'),
        Line2D([0], [0], color='violet', lw=2, label='Negative edge'),
        Line2D([0], [0], marker='o', color='w', label='Left nodes',
               markerfacecolor='skyblue',    markersize=12, markeredgecolor='black'),
        Line2D([0], [0], marker='o', color='w', label='Right nodes',
               markerfacecolor='lightgreen', markersize=12, markeredgecolor='black'),
    ]
    plt.legend(handles=legend_elements_bipartite, loc='upper right', fontsize=FONT_SIZE_LEGEND)

    plt.title("Bipartite Network (Top 25% Precision)", fontsize=FONT_SIZE_TITLE)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "Bipartite_top25pct.png"), dpi=300, bbox_inches="tight")
    plt.savefig(os.path.join(output_dir, "Bipartite_top25pct.pdf"),            bbox_inches="tight")
    plt.close()
    print("Bipartite network saved.")
else:
    print("No top 25% edges for Bipartite graph.")

print("\nAll outputs in:", output_dir)

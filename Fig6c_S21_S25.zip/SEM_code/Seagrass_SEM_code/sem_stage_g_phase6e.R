#!/usr/bin/env Rscript
# Phase 6e: Additional analyses on 697 Universal models
# - 4-fold CV: AUC + Brier
# - 8-fold CV: AUC + Brier
# - LORO-CV: AUC + Brier (4 regions)
# - LRT: SR1, SR2 vs reduced model
# - logistf x Region: SR1, SR2 Region universality
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
  library(pROC); library(logistf)
})

ROOT     <- "/Fig6"
DATA_IN  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
POOL_IN  <- file.path(ROOT, "phase7_universal_candidates.csv")
OUT_DIR  <- file.path(ROOT, "phase6e_chunks")
dir.create(OUT_DIR, showWarnings = FALSE)
SUMMARY  <- file.path(ROOT, "phase6e_full_validation.csv")

dat <- read_csv(DATA_IN, show_col_types=FALSE)
dat$Region <- factor(dat$Region)
pool <- read_csv(POOL_IN, show_col_types=FALSE) %>% select(sr1, sr2, k, downset)
cat(sprintf("[Phase6e] Pool: %d Universal models, Data: %d rows\n", nrow(pool), nrow(dat)))

set.seed(42)

fit_predict <- function(d_train, d_test, sr1, sr2) {
  d_train$.SR1 <- d_train[[sr1]]; d_train$.SR2 <- d_train[[sr2]]
  d_test$.SR1  <- d_test[[sr1]];  d_test$.SR2  <- d_test[[sr2]]
  m <- glm(Seagrass ~ .SR1 + .SR2, data=d_train, family=binomial)
  predict(m, newdata=d_test, type="response")
}

cv_auc_brier <- function(d, sr1, sr2, folds) {
  idx <- sample(rep(seq_len(folds), length.out=nrow(d)))
  preds <- rep(NA_real_, nrow(d)); actuals <- d$Seagrass
  for (f in 1:folds) {
    tr <- d[idx != f, ]; te <- d[idx == f, ]
    if (length(unique(tr$Seagrass)) < 2 || length(unique(te$Seagrass)) < 2) next
    preds[idx == f] <- tryCatch(fit_predict(tr, te, sr1, sr2), error=function(e) NA)
  }
  ok <- !is.na(preds)
  if (sum(ok) < 5 || length(unique(actuals[ok])) < 2)
    return(list(auc=NA, brier=NA))
  list(
    auc   = as.numeric(suppressMessages(pROC::auc(actuals[ok], preds[ok]))),
    brier = mean((preds[ok] - actuals[ok])^2)
  )
}

loro_cv <- function(d, sr1, sr2) {
  regs <- levels(d$Region); preds <- rep(NA_real_, nrow(d))
  for (r in regs) {
    tr <- d[d$Region != r, ]; te <- d[d$Region == r, ]
    if (length(unique(tr$Seagrass)) < 2) next
    preds[d$Region == r] <- tryCatch(fit_predict(tr, te, sr1, sr2), error=function(e) NA)
  }
  ok <- !is.na(preds); a <- d$Seagrass
  if (sum(ok) < 5 || length(unique(a[ok])) < 2) return(list(auc=NA, brier=NA))
  list(auc=as.numeric(suppressMessages(pROC::auc(a[ok], preds[ok]))),
       brier=mean((preds[ok] - a[ok])^2))
}

lrt_one <- function(d, sr1, sr2) {
  d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  full <- glm(Seagrass ~ .SR1 + .SR2, data=d, family=binomial)
  no1  <- glm(Seagrass ~ .SR2,        data=d, family=binomial)
  no2  <- glm(Seagrass ~ .SR1,        data=d, family=binomial)
  list(
    sr1_lrt_p = anova(no1, full, test="Chisq")$"Pr(>Chi)"[2],
    sr2_lrt_p = anova(no2, full, test="Chisq")$"Pr(>Chi)"[2]
  )
}

logistf_region <- function(d, sr1, sr2) {
  d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  res <- list()
  for (sr_var in c(".SR1",".SR2")) {
    f <- as.formula(sprintf("Seagrass ~ %s * Region", sr_var))
    fit <- tryCatch(logistf::logistf(f, data=d), error=function(e) NULL)
    if (is.null(fit)) {
      res[[sr_var]] <- c(B=NA, C=NA, D=NA); next
    }
    p <- fit$prob; nm <- names(p)
    res[[sr_var]] <- c(
      B = p[grep(sprintf("%s:RegionB", sr_var), nm, fixed=TRUE)][1],
      C = p[grep(sprintf("%s:RegionC", sr_var), nm, fixed=TRUE)][1],
      D = p[grep(sprintf("%s:RegionD", sr_var), nm, fixed=TRUE)][1]
    )
  }
  list(sr1_B=res$.SR1["B"], sr1_C=res$.SR1["C"], sr1_D=res$.SR1["D"],
       sr2_B=res$.SR2["B"], sr2_C=res$.SR2["C"], sr2_D=res$.SR2["D"])
}

process_one <- function(sr1, sr2, downset_str) {
  cv4   <- cv_auc_brier(dat, sr1, sr2, 4)
  cv8   <- cv_auc_brier(dat, sr1, sr2, 8)
  loro  <- loro_cv(dat, sr1, sr2)
  lrt   <- tryCatch(lrt_one(dat, sr1, sr2), error=function(e) list(sr1_lrt_p=NA, sr2_lrt_p=NA))
  reg   <- tryCatch(logistf_region(dat, sr1, sr2),
                    error=function(e) list(sr1_B=NA, sr1_C=NA, sr1_D=NA,
                                           sr2_B=NA, sr2_C=NA, sr2_D=NA))
  tibble(sr1=sr1, sr2=sr2, downset=downset_str,
         cv4_auc=cv4$auc, cv4_brier=cv4$brier,
         cv8_auc=cv8$auc, cv8_brier=cv8$brier,
         loro_auc=loro$auc, loro_brier=loro$brier,
         sr1_lrt_p=lrt$sr1_lrt_p, sr2_lrt_p=lrt$sr2_lrt_p,
         sr1_regB_p=reg$sr1_B, sr1_regC_p=reg$sr1_C, sr1_regD_p=reg$sr1_D,
         sr2_regB_p=reg$sr2_B, sr2_regC_p=reg$sr2_C, sr2_regD_p=reg$sr2_D)
}

plan(multisession, workers=24)
CHUNK <- 100
chunks <- split(seq_len(nrow(pool)), ceiling(seq_len(nrow(pool))/CHUNK))
cat(sprintf("[Phase6e] %d chunks of %d models\n", length(chunks), CHUNK))

t0 <- Sys.time()
for (ci in seq_along(chunks)) {
  out_path <- file.path(OUT_DIR, sprintf("phase6e_chunk_%03d.csv", ci))
  if (file.exists(out_path)) { cat(sprintf("[chunk %3d/%d] skip\n", ci, length(chunks))); next }
  rows_ci <- chunks[[ci]]
  res <- future_map_dfr(rows_ci,
           function(i) process_one(pool$sr1[i], pool$sr2[i], pool$downset[i]),
           .options=furrr_options(seed=TRUE), .progress=TRUE)
  write_csv(res, out_path)
  el <- as.numeric(Sys.time()-t0, units="mins")
  cat(sprintf("[chunk %3d/%d] %d models, elapsed %.1f min, %.1f%% done\n",
              ci, length(chunks), nrow(res), el, ci/length(chunks)*100))
}

cat("[Phase6e] Combining...\n")
files <- list.files(OUT_DIR, pattern="^phase6e_chunk_.*\\.csv$", full.names=TRUE)
combined <- map_dfr(files, ~ read_csv(.x, show_col_types=FALSE))
write_csv(combined, SUMMARY)
cat(sprintf("[Phase6e] Wrote %s (%d rows, total %.1f min)\n",
            SUMMARY, nrow(combined), as.numeric(Sys.time()-t0, units="mins")))

cat("\n[Phase6e] Collective summary across 697 universal models:\n")
cat(sprintf("  CV4  AUC: median=%.3f IQR=[%.3f, %.3f]\n",
    median(combined$cv4_auc, na.rm=T), quantile(combined$cv4_auc,0.25,na.rm=T), quantile(combined$cv4_auc,0.75,na.rm=T)))
cat(sprintf("  CV8  AUC: median=%.3f IQR=[%.3f, %.3f]\n",
    median(combined$cv8_auc, na.rm=T), quantile(combined$cv8_auc,0.25,na.rm=T), quantile(combined$cv8_auc,0.75,na.rm=T)))
cat(sprintf("  LORO AUC: median=%.3f IQR=[%.3f, %.3f]\n",
    median(combined$loro_auc, na.rm=T), quantile(combined$loro_auc,0.25,na.rm=T), quantile(combined$loro_auc,0.75,na.rm=T)))
cat(sprintf("  SR1 LRT p median: %.2e (max: %.2e)\n",
    median(combined$sr1_lrt_p, na.rm=T), max(combined$sr1_lrt_p, na.rm=T)))
cat(sprintf("  SR2 LRT p median: %.2e (max: %.2e)\n",
    median(combined$sr2_lrt_p, na.rm=T), max(combined$sr2_lrt_p, na.rm=T)))
cat("\n  SR1 x Region p (universal if >= 0.05):\n")
for (r in c("B","C","D"))
  cat(sprintf("    Region%s: median=%.3f, %% NS (>=0.05)=%.1f\n",
      r, median(combined[[paste0("sr1_reg",r,"_p")]], na.rm=T),
      100*mean(combined[[paste0("sr1_reg",r,"_p")]] >= 0.05, na.rm=T)))
cat("  SR2 x Region p:\n")
for (r in c("B","C","D"))
  cat(sprintf("    Region%s: median=%.3f, %% NS (>=0.05)=%.1f\n",
      r, median(combined[[paste0("sr2_reg",r,"_p")]], na.rm=T),
      100*mean(combined[[paste0("sr2_reg",r,"_p")]] >= 0.05, na.rm=T)))

cat("\n=== Phase 6e complete ===\n")

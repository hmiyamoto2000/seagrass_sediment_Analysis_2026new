#地域なし_selected
# =========================================
# ライブラリ
# =========================================
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 7.693835,
  B_bacterium2013 = 1.6778404,
  B_Defluviitaleaceae = 1.6778404,
  E_Corallinophycidae = 1.6778404,
  B_uncultured_Aminicenantes_bacterium = -0.04036115,
  E_Diatomea = -0.04036115,
  E_Intramacronucleata = -0.04036115
)

# =========================================
# 色・線幅・線種
# =========================================
edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

# =========================================
# DiagrammeR graph
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica'];
  edge [fontname='Helvetica'];

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3'];

  /* SR入力 */
  B_Desulfobulbaceae [shape=ellipse, label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium2013 [shape=ellipse, label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse, label='B_Defluviitaleaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse, label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse, label='B_uncultured_Aminicenantes\\n(SR_input)'];
  E_Diatomea [shape=ellipse, label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse, label='E_Intramacronucleata\\n(SR_input)'];

  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* 横方向を左から右に揃える */
  {rank=same;
    B_Desulfobulbaceae; B_bacterium2013; B_Defluviitaleaceae; E_Corallinophycidae;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea; E_Intramacronucleata;
  }

  /* SRへのパス: 緑と赤で色分け */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium2013 -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# SRへのパス（順番・色）
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium2013"]), penwidth(beta["B_bacterium2013"]), edge_style(beta["B_bacterium2013"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 表示・出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_correct_order_260125.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_correct_order_260125.pdf", width=10, height=6)





#パターン1
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 7.693835,
  B_bacterium2013 = 1.6778404,
  B_Defluviitaleaceae = 0.0023096674,
  B_Hyphomonadaceae = 0.0023096674,
  E_Corallinophycidae = 0.04036115,
  B_uncultured_Aminicenantes_bacterium = -0.0023096674,
  E_Diatomea = -0.0023096674,
  E_Intramacronucleata = -0.04036115
)

region_beta <- c(
  RegionA = 0,
  RegionB = 0.08,
  RegionC = 0.05,
  RegionD = 0.22
)

edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth  <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

region_color <- "gray40"
region_style <- "dashed"
region_width <- function(b) pmax(abs(b) * scale_factor, 0.9)

# =========================================
# DiagrammeR graph
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica'];
  edge [fontname='Helvetica'];

  /* ================================
     Region を cluster にして最上段固定
     ================================ */
  subgraph clusterRegion {
    rank=min;
    style=filled;
    color=white;
    RegionA [shape=box, style='filled', fillcolor='#EFEFEF', label='Region A'];
    RegionB [shape=box, style='filled', fillcolor='#EFEFEF', label='Region B'];
    RegionC [shape=box, style='filled', fillcolor='#EFEFEF', label='Region C'];
    RegionD [shape=box, style='filled', fillcolor='#EFEFEF', label='Region D'];
  }

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3'];
  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* SR入力ノード（最下段に固定） */
  B_Desulfobulbaceae [shape=ellipse,label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium2013 [shape=ellipse, label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse,label='B_Defluviitaleaceae\\n(SR_input)'];
  B_Hyphomonadaceae [shape=ellipse,label='B_Hyphomonadaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse,label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse,label='B_uncultured_Aminicenantes\\n(SR_input)'];
  E_Diatomea [shape=ellipse,label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse,label='E_Intramacronucleata\\n(SR_input)'];

  {rank=max;
    B_Desulfobulbaceae; B_bacterium2013; B_Defluviitaleaceae; B_Hyphomonadaceae; E_Corallinophycidae;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea; E_Intramacronucleata;
  }

  /* 横順固定（不可視） */
  B_Desulfobulbaceae -> B_bacterium2013 [style=invis];
  B_bacterium2013 -> B_Defluviitaleaceae [style=invis];
  B_Defluviitaleaceae -> B_Hyphomonadaceae [style=invis];
  B_Hyphomonadaceae -> E_Corallinophycidae [style=invis];
  E_Corallinophycidae -> B_uncultured_Aminicenantes_bacterium [style=invis];
  B_uncultured_Aminicenantes_bacterium -> E_Diatomea [style=invis];
  E_Diatomea -> E_Intramacronucleata [style=invis];

  /* Region → Seagrass */
  RegionA -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionB -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionC -> Seagrass [label='β = 0.05', color='%s', penwidth=%f, style=%s];
  RegionD -> Seagrass [label='β = 0.22', color='%s', penwidth=%f, style=%s];

  /* SR入力ノード → SR */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium2013 -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_Hyphomonadaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# Region → Seagrass
region_color, region_width(region_beta["RegionA"]), region_style,
region_color, region_width(region_beta["RegionB"]), region_style,
region_color, region_width(region_beta["RegionC"]), region_style,
region_color, region_width(region_beta["RegionD"]), region_style,
# SR入力 → SR
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium2013"]), penwidth(beta["B_bacterium2013"]), edge_style(beta["B_bacterium2013"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["B_Hyphomonadaceae"]), penwidth(beta["B_Hyphomonadaceae"]), edge_style(beta["B_Hyphomonadaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_final_bottom_inputs260113.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_final_bottom_inputs260113.pdf", width=10, height=6)




#バターン2
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 0.27,     # 式に基づく概算
  B_bacterium_enrichment = 0.00005,
  B_Defluviitaleaceae = 0.00005,
  B_Hyphomonadaceae = 0.00005,
  E_Corallinophycidae = 0.01, 
  B_uncultured_Aminicenantes_bacterium = -0.034, 
  E_Diatomea = -0.00035,
  E_Intramacronucleata = -0.00005 
)


region_beta <- c(
  RegionA = 0,
  RegionB = 0.08,
  RegionC = 0.05,
  RegionD = 0.22
)

edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth  <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

region_color <- "gray40"
region_style <- "dashed"
region_width <- function(b) pmax(abs(b) * scale_factor, 0.9)

# =========================================
# DiagrammeR graph
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica'];
  edge [fontname='Helvetica'];

  /* ================================
     Region を cluster にして最上段固定
     ================================ */
  subgraph clusterRegion {
    rank=min;
    style=filled;
    color=white;
    RegionA [shape=box, style='filled', fillcolor='#EFEFEF', label='Region A'];
    RegionB [shape=box, style='filled', fillcolor='#EFEFEF', label='Region B'];
    RegionC [shape=box, style='filled', fillcolor='#EFEFEF', label='Region C'];
    RegionD [shape=box, style='filled', fillcolor='#EFEFEF', label='Region D'];
  }

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3'];
  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* SR入力ノード（最下段に固定） */
  B_Desulfobulbaceae [shape=ellipse,label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium_enrichment [shape=ellipse,label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse,label='B_Defluviitaleaceae\\n(SR_input)'];
  B_Hyphomonadaceae [shape=ellipse,label='B_Hyphomonadaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse,label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse, label='B_uncultured_Aminicenantes_bacterium\\n(SR_input)'];
  E_Diatomea [shape=ellipse,label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse,label='E_Intramacronucleata\\n(SR_input)'];

  {rank=max;
    B_Desulfobulbaceae; B_bacterium_enrichment; B_Defluviitaleaceae; B_Hyphomonadaceae; E_Corallinophycidae;E_Intramacronucleata;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea;
  }

  /* 横順固定（不可視） */
  B_Desulfobulbaceae -> B_bacterium_enrichment [style=invis];
  B_bacterium_enrichment -> B_Defluviitaleaceae [style=invis];
  B_Defluviitaleaceae -> B_Hyphomonadaceae [style=invis];
  B_Hyphomonadaceae -> E_Corallinophycidae [style=invis];
  E_Corallinophycidae -> B_uncultured_Aminicenantes_bacterium [style=invis];
  B_uncultured_Aminicenantes_bacterium -> E_Diatomea [style=invis];
  E_Diatomea -> E_Intramacronucleata [style=invis];

  /* Region → Seagrass */
  RegionA -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionB -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionC -> Seagrass [label='β = 0.05', color='%s', penwidth=%f, style=%s];
  RegionD -> Seagrass [label='β = 0.22', color='%s', penwidth=%f, style=%s];

  /* SR入力ノード → SR */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium_enrichment -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_Hyphomonadaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# Region → Seagrass
region_color, region_width(region_beta["RegionA"]), region_style,
region_color, region_width(region_beta["RegionB"]), region_style,
region_color, region_width(region_beta["RegionC"]), region_style,
region_color, region_width(region_beta["RegionD"]), region_style,
# SR入力 → SR
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium_enrichment"]), penwidth(beta["B_bacterium_enrichment"]), edge_style(beta["B_bacterium_enrichment"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["B_Hyphomonadaceae"]), penwidth(beta["B_Hyphomonadaceae"]), edge_style(beta["B_Hyphomonadaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_final_bottom_inputs260119new.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_final_bottom_inputs260119new.pdf", width=10, height=6)




#バターン3_ストレートバージョン
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 0.27,     # 式に基づく概算
  B_bacterium_enrichment = 0.00005,
  B_Defluviitaleaceae = 0.00005,
  E_Corallinophycidae = 0.00005, 
  B_uncultured_Aminicenantes_bacterium = -0.00035, 
  E_Diatomea = -0.00035,
  E_Intramacronucleata = -0.00035 
)


region_beta <- c(
  RegionA = 0,
  RegionB = 0.08,
  RegionC = 0.05,
  RegionD = 0.22
)

edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth  <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

region_color <- "gray40"
region_style <- "dashed"
region_width <- function(b) pmax(abs(b) * scale_factor, 0.9)

# =========================================
# DiagrammeR graph　splines=false;によってSRからのラインがストレートになる
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  splines=false;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica'] #,fontsize=12,width=2.3,height=0.8,fixedsize=true];#node [fontname='Helvetica']だとフリー
  edge [fontname='Helvetica'];

  /* ================================
     Region を cluster にして最上段固定
     ================================ */
  subgraph clusterRegion {
    rank=same;
    style=filled;
    color=white;
    RegionA [shape=box, style='filled', fillcolor='#EFEFEF', label='Region A'];
    RegionB [shape=box, style='filled', fillcolor='#EFEFEF', label='Region B'];
    RegionC [shape=box, style='filled', fillcolor='#EFEFEF', label='Region C'];
    RegionD [shape=box, style='filled', fillcolor='#EFEFEF', label='Region D'];
  }

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3'];
  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* SR入力ノード（最下段に固定） */
  B_Desulfobulbaceae [shape=ellipse,label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium_enrichment [shape=ellipse,label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse,label='B_Defluviitaleaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse,label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse, label='B_uncultured_Aminicenantes_bacterium\\n(SR_input)'];
  E_Diatomea [shape=ellipse,label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse,label='E_Intramacronucleata\\n(SR_input)'];

  {rank=max;
    B_Desulfobulbaceae; B_bacterium_enrichment; B_Defluviitaleaceae; E_Corallinophycidae;E_Intramacronucleata;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea;
  }

  /* 横順固定（不可視） */
  B_Desulfobulbaceae -> B_bacterium_enrichment [style=invis];
  B_bacterium_enrichment -> B_Defluviitaleaceae [style=invis];
  B_Defluviitaleaceae -> E_Corallinophycidae [style=invis];
  E_Corallinophycidae -> B_uncultured_Aminicenantes_bacterium [style=invis];
  B_uncultured_Aminicenantes_bacterium -> E_Diatomea [style=invis];
  E_Diatomea -> E_Intramacronucleata [style=invis];

  /* Region → Seagrass */
  RegionA -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionB -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionC -> Seagrass [label='β = 0.05', color='%s', penwidth=%f, style=%s];
  RegionD -> Seagrass [label='β = 0.22', color='%s', penwidth=%f, style=%s];

  /* SR入力ノード → SR */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium_enrichment -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# Region → Seagrass
region_color, region_width(region_beta["RegionA"]), region_style,
region_color, region_width(region_beta["RegionB"]), region_style,
region_color, region_width(region_beta["RegionC"]), region_style,
region_color, region_width(region_beta["RegionD"]), region_style,
# SR入力 → SR
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium_enrichment"]), penwidth(beta["B_bacterium_enrichment"]), edge_style(beta["B_bacterium_enrichment"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_final_bottom_inputs260125_regionnew.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_final_bottom_inputs260125_regionnew.pdf", width=10, height=6)



#バターン3_ストレートバージョン サイズ変更
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 0.27,     # 式に基づく概算
  B_bacterium_enrichment = 0.00005,
  B_Defluviitaleaceae = 0.00005,
  E_Corallinophycidae = 0.00005, 
  B_uncultured_Aminicenantes_bacterium = -0.00035, 
  E_Diatomea = -0.00035,
  E_Intramacronucleata = -0.00035 
)


region_beta <- c(
  RegionA = 0,
  RegionB = 0.08,
  RegionC = 0.05,
  RegionD = 0.22
)

edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth  <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

region_color <- "gray40"
region_style <- "dashed"
region_width <- function(b) pmax(abs(b) * scale_factor, 0.9)

# =========================================
# DiagrammeR graph　splines=false;によってSRからのラインがストレートになる
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  splines=false;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica',fontsize=14,width=6.5,height=2.0,fixedsize=true];#node [fontname='Helvetica']だとフリー
  edge [fontname='Helvetica'];

  /* ================================
     Region を cluster にして最上段固定
     ================================ */
  subgraph clusterRegion {
    rank=same;
    style=filled;
    color=white;
    RegionA [shape=box, style='filled', fillcolor='#EFEFEF', label='Region A', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionB [shape=box, style='filled', fillcolor='#EFEFEF', label='Region B', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionC [shape=box, style='filled', fillcolor='#EFEFEF', label='Region C', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionD [shape=box, style='filled', fillcolor='#EFEFEF', label='Region D', width=2.5,height=0.8,fixedsize=true,fontsize=11];
  }

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3',width=4.0,height=1.2,fixsize=true,fontsize=13];
  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* SR入力ノード（最下段に固定） */
  B_Desulfobulbaceae [shape=ellipse,label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium_enrichment [shape=ellipse,label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse,label='B_Defluviitaleaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse,label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse, label='B_uncultured_Aminicenantes_bacterium\\n(SR_input)'];
  E_Diatomea [shape=ellipse,label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse,label='E_Intramacronucleata\\n(SR_input)'];

  {rank=max;
    B_Desulfobulbaceae; B_bacterium_enrichment; B_Defluviitaleaceae; E_Corallinophycidae;E_Intramacronucleata;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea;
  }

  /* 横順固定（不可視） */
  B_Desulfobulbaceae -> B_bacterium_enrichment [style=invis];
  B_bacterium_enrichment -> B_Defluviitaleaceae [style=invis];
  B_Defluviitaleaceae -> E_Corallinophycidae [style=invis];
  E_Corallinophycidae -> B_uncultured_Aminicenantes_bacterium [style=invis];
  B_uncultured_Aminicenantes_bacterium -> E_Diatomea [style=invis];
  E_Diatomea -> E_Intramacronucleata [style=invis];

  /* Region → Seagrass */
  RegionA -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionB -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionC -> Seagrass [label='β = 0.05', color='%s', penwidth=%f, style=%s];
  RegionD -> Seagrass [label='β = 0.22', color='%s', penwidth=%f, style=%s];

  /* SR入力ノード → SR */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium_enrichment -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# Region → Seagrass
region_color, region_width(region_beta["RegionA"]), region_style,
region_color, region_width(region_beta["RegionB"]), region_style,
region_color, region_width(region_beta["RegionC"]), region_style,
region_color, region_width(region_beta["RegionD"]), region_style,
# SR入力 → SR
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium_enrichment"]), penwidth(beta["B_bacterium_enrichment"]), edge_style(beta["B_bacterium_enrichment"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_final_bottom_inputs260125_regionnewlarge.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_final_bottom_inputs260125_regionnewlarge.pdf", width=10, height=6)



#バターン3_ストレートバージョン サイズ変更260126
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# =========================================
# β係数・スケール
# =========================================
scale_factor <- 1.5
min_width <- 0.8
max_width <- 3.0

beta <- c(
  B_Desulfobulbaceae = 0.27,     # 式に基づく概算
  B_bacterium_enrichment = 0.00005,
  B_Defluviitaleaceae = 0.00005,
  B_Hyphomonadaceae = 0.00005,
  E_Corallinophycidae = 0.00005, 
  B_uncultured_Aminicenantes_bacterium = -0.00035, 
  E_Diatomea = -0.00035,
  E_Intramacronucleata = -0.00035 
)


region_beta <- c(
  RegionA = 0,
  RegionB = 0.08,
  RegionC = 0.05,
  RegionD = 0.22
)

edge_color <- function(b) ifelse(b >= 0, "green", "red")
edge_style <- function(b) ifelse(b >= 0, "solid", "dashed")
penwidth  <- function(b) {
  w <- pmax(abs(b) * scale_factor, min_width)
  w <- pmin(w, max_width)
  return(w)
}

region_color <- "gray40"
region_style <- "dashed"
region_width <- function(b) pmax(abs(b) * scale_factor, 0.9)

# =========================================
# DiagrammeR graph　splines=false;によってSRからのラインがストレートになる
# =========================================
p <- grViz(sprintf("
digraph SR_SEM {
  rankdir=TB;
  splines=false;
  fontsize=12;
  fontname='Helvetica';
  node [fontname='Helvetica',fontsize=14,width=6.5,height=2.0,fixedsize=true];#node [fontname='Helvetica']だとフリー
  edge [fontname='Helvetica'];

  /* ================================
     Region を cluster にして最上段固定
     ================================ */
  subgraph clusterRegion {
    rank=same;
    style=filled;
    color=white;
    RegionA [shape=box, style='filled', fillcolor='#EFEFEF', label='Region A', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionB [shape=box, style='filled', fillcolor='#EFEFEF', label='Region B', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionC [shape=box, style='filled', fillcolor='#EFEFEF', label='Region C', width=2.5,height=0.8,fixedsize=true,fontsize=11];
    RegionD [shape=box, style='filled', fillcolor='#EFEFEF', label='Region D', width=2.5,height=0.8,fixedsize=true,fontsize=11];
  }

  /* 中心 */
  SR [shape=box, style='filled', fillcolor='#F2F2F2', label='SR\\n(fixed symbolic function)'];
  Seagrass [shape=box, style='filled', fillcolor='#D9EAD3',width=4.0,height=1.2,fixsize=true,fontsize=13];
  B_Desulfobulbaceae_out [shape=ellipse, label='B_Desulfobulbaceae\\n(response to Seagrass)'];

  /* SR入力ノード（最下段に固定） */
  B_Desulfobulbaceae [shape=ellipse,label='B_Desulfobulbaceae\\n(SR_input)'];
  B_bacterium_enrichment [shape=ellipse,label='B_bacterium_enrichment\\n(SR_input)'];
  B_Defluviitaleaceae [shape=ellipse,label='B_Defluviitaleaceae\\n(SR_input)'];
  B_Hyphomonadaceae [shape=ellipse,label='B_Hyphomonadaceae\\n(SR_input)'];
  E_Corallinophycidae [shape=ellipse,label='E_Corallinophycidae\\n(SR_input)'];
  B_uncultured_Aminicenantes_bacterium [shape=ellipse, label='B_uncultured_Aminicenantes_bacterium\\n(SR_input)'];
  E_Diatomea [shape=ellipse,label='E_Diatomea\\n(SR_input)'];
  E_Intramacronucleata [shape=ellipse,label='E_Intramacronucleata\\n(SR_input)'];

  {rank=max;
    B_Desulfobulbaceae; B_bacterium_enrichment; B_Defluviitaleaceae; B_Hyphomonadaceae; E_Corallinophycidae;
    B_uncultured_Aminicenantes_bacterium; E_Diatomea;E_Intramacronucleata;
  }

  /* 横順固定（不可視） */
  B_Desulfobulbaceae -> B_bacterium_enrichment [style=invis];
  B_bacterium_enrichment -> B_Defluviitaleaceae [style=invis];
  B_Defluviitaleaceae -> B_Hyphomonadaceae [style=invis];
  B_Hyphomonadaceae -> E_Corallinophycidae [style=invis];
  E_Corallinophycidae -> B_uncultured_Aminicenantes_bacterium [style=invis];
  B_uncultured_Aminicenantes_bacterium -> E_Diatomea [style=invis];
  E_Diatomea -> E_Intramacronucleata [style=invis];

  /* Region → Seagrass */
  RegionA -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionB -> Seagrass [label='β = 0.08', color='%s', penwidth=%f, style=%s];
  RegionC -> Seagrass [label='β = 0.05', color='%s', penwidth=%f, style=%s];
  RegionD -> Seagrass [label='β = 0.22', color='%s', penwidth=%f, style=%s];

  /* SR入力ノード → SR */
  B_Desulfobulbaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_bacterium_enrichment -> SR [color='%s', penwidth=%f, style=%s];
  B_Defluviitaleaceae -> SR [color='%s', penwidth=%f, style=%s];
  B_Hyphomonadaceae -> SR [color='%s', penwidth=%f, style=%s];
  E_Corallinophycidae -> SR [color='%s', penwidth=%f, style=%s];
  B_uncultured_Aminicenantes_bacterium -> SR [color='%s', penwidth=%f, style=%s];
  E_Diatomea -> SR [color='%s', penwidth=%f, style=%s];
  E_Intramacronucleata -> SR [color='%s', penwidth=%f, style=%s];

  /* 主経路 */
  SR -> Seagrass [label='β = 0.80', color='green', penwidth=4.4, style='bold'];
  Seagrass -> B_Desulfobulbaceae_out [label='β = 0.18', color='green', penwidth=1.0];

  /* フィードバック */
  B_Desulfobulbaceae_out -> B_Desulfobulbaceae
    [style=dashed, color='gray40', label='conceptual feedback', fontcolor='gray40'];
}
",
# Region → Seagrass
region_color, region_width(region_beta["RegionA"]), region_style,
region_color, region_width(region_beta["RegionB"]), region_style,
region_color, region_width(region_beta["RegionC"]), region_style,
region_color, region_width(region_beta["RegionD"]), region_style,
# SR入力 → SR
edge_color(beta["B_Desulfobulbaceae"]), penwidth(beta["B_Desulfobulbaceae"]), edge_style(beta["B_Desulfobulbaceae"]),
edge_color(beta["B_bacterium_enrichment"]), penwidth(beta["B_bacterium_enrichment"]), edge_style(beta["B_bacterium_enrichment"]),
edge_color(beta["B_Defluviitaleaceae"]), penwidth(beta["B_Defluviitaleaceae"]), edge_style(beta["B_Defluviitaleaceae"]),
edge_color(beta["B_Hyphomonadaceae"]), penwidth(beta["B_Hyphomonadaceae"]), edge_style(beta["B_Hyphomonadaceae"]),
edge_color(beta["E_Corallinophycidae"]), penwidth(beta["E_Corallinophycidae"]), edge_style(beta["E_Corallinophycidae"]),
edge_color(beta["B_uncultured_Aminicenantes_bacterium"]), penwidth(beta["B_uncultured_Aminicenantes_bacterium"]), edge_style(beta["B_uncultured_Aminicenantes_bacterium"]),
edge_color(beta["E_Diatomea"]), penwidth(beta["E_Diatomea"]), edge_style(beta["E_Diatomea"]),
edge_color(beta["E_Intramacronucleata"]), penwidth(beta["E_Intramacronucleata"]), edge_style(beta["E_Intramacronucleata"])
))

# =========================================
# 出力
# =========================================
p
export_svg(p) |> charToRaw() |> rsvg_png("SR_SEM_final_bottom_inputs260125_regionnewlarge2.png", width=2000, height=1200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SR_SEM_final_bottom_inputs260125_regionnewlarge2.pdf", width=10, height=6)



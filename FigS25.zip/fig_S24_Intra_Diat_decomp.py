#!/usr/bin/env python3
"""
Supplementary Fig. S24
Taxonomic decomposition of Intramacronucleata and Diatomea
==========================================================
Decomposes the two negatively-associated lineages identified in Fig. 5c
at the D6 (subclass/order) level and contrasts seagrass vs. non-seagrass
sediment samples in two complementary views:

  (a, b) Pooled comparison across all 132 samples (8 sites combined)
         showing the magnitude of seagrass-driven suppression for each
         D6 group within Intramacronucleata (a) and Diatomea (b).

  (c, d) Site-resolved heatmap of log2(seagrass/non-seagrass) for the
         same D6 groups, demonstrating regional consistency of the
         suppression pattern across the eight study sites.

Inputs (place in same directory):
  Eukaryota_seagrass_D15.csv       (132 samples x ~1744 taxa columns,
                                    QIIME2 taxonomy strings as headers,
                                    relative abundances summing to 100)
  Seagrass_list_cnd_dex250917.csv  (sample metadata: name, dex, env, ...)

Outputs:
  Supp_Fig_S24_Intra_Diat_decomp.pdf
  Supp_Fig_S24_Intra_Diat_decomp.png
  Supp_Fig_S24a_Intramacronucleata_D6.csv     (pooled statistics)
  Supp_Fig_S24b_Diatomea_D6.csv               (pooled statistics)
  Supp_Fig_S24c_Intramacronucleata_by_site.csv (site-resolved log2(SG/Non))
  Supp_Fig_S24d_Diatomea_by_site.csv           (site-resolved log2(SG/Non))
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import matplotlib.font_manager as fm
from scipy import stats as scipy_stats

# ============================================================
# USER SETTINGS
# ============================================================
FONT_SIZE  = 12
TITLE_SIZE = FONT_SIZE + 1
LABEL_SIZE = FONT_SIZE - 1
TICK_SIZE  = FONT_SIZE - 2
STAT_SIZE  = FONT_SIZE - 2
DPI        = 300

# Minimum total fraction (across 132 samples) for a D6 group to be plotted.
# Filters out trace-level lineages with no statistical power.
MIN_TOTAL_ABUNDANCE = 1.0   # in % * sample units (i.e. >= 1 means about
                            # 0.0076% mean abundance per sample)

# ============================================================
# Font setup (Helvetica, matches Figs. 1, S1, S3, ED 1)
# ============================================================
helvetica = [f for f in fm.findSystemFonts() if "Helvetica" in f]
if helvetica:
    plt.rcParams["font.family"] = "Helvetica"
else:
    plt.rcParams["font.family"]     = "sans-serif"
    plt.rcParams["font.sans-serif"] = ["Helvetica", "Arial",
                                        "Liberation Sans", "DejaVu Sans"]
plt.rcParams["font.size"]      = FONT_SIZE
plt.rcParams["pdf.fonttype"]   = 42
plt.rcParams["ps.fonttype"]    = 42
plt.rcParams["axes.linewidth"] = 1.0

# ============================================================
# Colours
# ============================================================
COLOR_SG  = "#2E7D32"   # seagrass:     green
COLOR_NON = "#D4724E"   # non-seagrass: orange

# ============================================================
# Site ordering and label normalisation
# ============================================================
# The metadata file uses "Okayama_Y" for the K-bay site; the rest of
# the manuscript (and Sup Fig. S6) uses "Okayama_K".  We harmonise here.
SITE_RENAME = {"Okayama_Y": "Okayama_K"}

# Display order on the heatmap x-axis.  Grouped by ocean region to mirror
# Fig. 2 (Region A: Sea of Japan; Region B: Pacific; Region C: Seto Inland;
# Region D: Bungo Channel).
SITE_ORDER = [
    "Hakata", "Noto",                # Region A (Sea of Japan)
    "Tokyo_HK", "Tokyo_KC",          # Region B (Pacific)
    "Okayama_G", "Okayama_K",        # Region C (Seto Inland)
    "Kitsuki", "Saiki",              # Region D (Bungo Channel)
]


# ============================================================
# Helper: extract D6 (subclass/order) from QIIME2 taxonomy string
# ============================================================
def get_d6(col: str) -> str:
    """
    Parse the D6 token from a QIIME2 hierarchy string.
    Returns '(unclassified)' for empty fields and '(no D6)' if the
    taxonomy string is shorter than D6.
    """
    for part in col.split(";"):
        part = part.strip()
        if part.startswith("D_6__"):
            label = part.replace("D_6__", "").strip()
            return label if label else "(unclassified)"
    return "(no D6)"


# ============================================================
# Helper: aggregate columns of a target lineage to D6 groups
# ============================================================
def aggregate_d6(df: pd.DataFrame, target_cols: list[str]) -> dict:
    """Return {d6_label: list_of_columns}."""
    groups = {}
    for c in target_cols:
        d6 = get_d6(c)
        groups.setdefault(d6, []).append(c)
    return groups


# ============================================================
# Helper: per-group SG vs Non statistics
# ============================================================
def compute_group_stats(df: pd.DataFrame, groups: dict,
                        meta: pd.DataFrame,
                        min_total: float = MIN_TOTAL_ABUNDANCE,
                        skip_unclassified: bool = False):
    """
    For each D6 group, compute per-sample summed abundance and
    test seagrass vs non-seagrass with Mann-Whitney U.

    Returns a list of dicts ordered by descending total abundance,
    filtered to groups with total >= min_total.

    If skip_unclassified is True, "(no D6)" and "(unclassified)"
    groups are dropped.  These are aggregations of OTUs that QIIME2
    could not assign at the D6 level and therefore have no
    biological interpretation worth highlighting in the figure.
    """
    df_meta = df.merge(meta[["name", "dex"]], on="name")
    skip_set = {"(no D6)", "(unclassified)"} if skip_unclassified else set()

    rows = []
    for label, cols in groups.items():
        if label in skip_set:
            continue
        total = df[cols].sum().sum()
        if total < min_total:
            continue
        sg_vals  = df_meta.loc[df_meta["dex"] == "seagrass", cols].sum(axis=1)
        non_vals = df_meta.loc[df_meta["dex"] == "non",      cols].sum(axis=1)
        if len(sg_vals) < 3 or len(non_vals) < 3:
            continue
        u, p = scipy_stats.mannwhitneyu(sg_vals, non_vals,
                                         alternative="two-sided")
        rows.append({
            "group":         label,
            "n_otus":        len(cols),
            "total_abund":   total,
            "sg_median":     sg_vals.median(),
            "non_median":    non_vals.median(),
            "sg_mean":       sg_vals.mean(),
            "non_mean":      non_vals.mean(),
            "log2_sg_non":   np.log2((sg_vals.mean()  + 1e-6) /
                                       (non_vals.mean() + 1e-6)),
            "u_stat":        u,
            "p_value":       p,
            "sg_values":     sg_vals.values,
            "non_values":    non_vals.values,
        })
    rows.sort(key=lambda r: -r["total_abund"])
    return rows


# ============================================================
# Helper: draw a single panel with side-by-side boxplots
# ============================================================
# Cosmetic relabelling of unclassified groups so the figure is readable.
PRETTY_LABEL = {
    "(no D6)":         "Unclassified",
    "(unclassified)":  "Unclassified",
}

def draw_panel(ax, group_rows: list, title: str, ylabel: str,
               max_groups: int = 8, use_sqrt: bool = True) -> None:
    rows = group_rows[:max_groups]
    n    = len(rows)

    np.random.seed(42)
    positions_sg  = np.arange(n) * 1.0 - 0.18
    positions_non = np.arange(n) * 1.0 + 0.18

    # Use square-root scale on the y-axis — the eukaryote abundance
    # distribution is heavily skewed (a few high-bacillariophyceae
    # samples dominate the linear scale), and a sqrt transform keeps
    # the median differences visible while preserving zero.
    if use_sqrt:
        ax.set_yscale("function",
                       functions=(lambda y: np.sqrt(np.maximum(y, 0)),
                                  lambda y: y * y))
        # Place ticks at biologically meaningful round values so the
        # non-linear spacing is interpretable (otherwise the default
        # locator places visually-equispaced but semantically-uneven
        # ticks like 0, 0.5, 2, 4 …).
        all_max = max(
            (max(np.nanmax(r["sg_values"]), np.nanmax(r["non_values"]))
             for r in rows
             if len(r["sg_values"]) > 0 and len(r["non_values"]) > 0),
            default=10.0,
        )
        # Round the upper bound up to the next "nice" tick value rather
        # than showing the raw max (e.g. 27.5 -> 32) so that all
        # tick labels are clean integers / simple fractions.
        candidate_ticks = [0, 0.1, 0.25, 0.5, 1, 2, 4, 8, 16, 32, 64]
        ticks = [t for t in candidate_ticks if t <= all_max]
        if not ticks or ticks[-1] < all_max:
            for t in candidate_ticks:
                if t > all_max:
                    ticks.append(t)
                    break
        ax.set_yticks(ticks)
        ax.set_yticklabels([(f"{t:g}") for t in ticks])

    for i, row in enumerate(rows):
        for vals, pos, col, sz, al in [
            (row["sg_values"],  positions_sg[i],  COLOR_SG,  18, 0.55),
            (row["non_values"], positions_non[i], COLOR_NON, 14, 0.40),
        ]:
            bp = ax.boxplot(
                [vals],
                positions=[pos],
                widths=0.28,
                patch_artist=True,
                medianprops=dict(color="black", linewidth=1.4),
                flierprops=dict(marker="", markersize=0),
                whiskerprops=dict(color=col, linewidth=0.8),
                capprops=dict(color=col, linewidth=0.8),
            )
            bp["boxes"][0].set_facecolor(col)
            bp["boxes"][0].set_alpha(0.30)
            j = np.random.uniform(-0.07, 0.07, len(vals))
            ax.scatter(pos + j, vals, c=col, s=sz, alpha=al,
                       zorder=3, edgecolors="none")

        # Significance label above the pair, anchored at the
        # 90th percentile (not max) so labels do not float far above
        # the box where they become disconnected from the data.
        p = row["p_value"]
        sig = ("***" if p < 0.001
               else "**"  if p < 0.01
               else "*"   if p < 0.05
               else "ns")
        colour = "#C62828" if p < 0.05 else "#999"
        all_v  = np.concatenate([row["sg_values"], row["non_values"]])
        if len(all_v) > 0 and np.nanmax(all_v) > 0:
            ypos = np.nanpercentile(all_v, 90) * 1.10 + 0.02
            ax.text(i, ypos, sig, ha="center",
                    fontsize=STAT_SIZE, fontweight="bold", color=colour)

    # X-tick labels: pretty-print "(no D6)" -> "Unclassified"
    pretty = [PRETTY_LABEL.get(r["group"], r["group"]) for r in rows]
    ax.set_xticks(np.arange(n))
    ax.set_xticklabels(pretty, rotation=30, ha="right", fontsize=TICK_SIZE)
    ax.set_ylabel(ylabel, fontsize=LABEL_SIZE)
    ax.set_title(title, fontsize=TITLE_SIZE, fontweight="bold", loc="left")
    ax.grid(True, alpha=0.3, axis="y")
    ax.set_xlim(-0.6, n - 0.4)


# ============================================================
# Save per-group statistics as CSV
# ============================================================
def save_csv(rows: list, out_path: str) -> None:
    df = pd.DataFrame([{
        "group":      r["group"],
        "n_otus":     r["n_otus"],
        "total_abund_pct_sample": round(r["total_abund"], 3),
        "seagrass_n":   len(r["sg_values"]),
        "seagrass_median": round(r["sg_median"], 5),
        "seagrass_mean":   round(r["sg_mean"], 5),
        "non_n":         len(r["non_values"]),
        "non_median":    round(r["non_median"], 5),
        "non_mean":      round(r["non_mean"], 5),
        "log2_sg_over_non": round(r["log2_sg_non"], 3),
        "u_stat":     int(r["u_stat"]),
        "p_value":    round(r["p_value"], 5),
        "significance": ("***" if r["p_value"] < 0.001
                          else "**"  if r["p_value"] < 0.01
                          else "*"   if r["p_value"] < 0.05
                          else "ns"),
    } for r in rows])
    df.to_csv(out_path, index=False)
    print(f"Saved: {out_path}")


# ============================================================
# Helper: per-site (D6 group x site) log2(SG/Non) and significance
# ============================================================
def compute_site_matrix(df: pd.DataFrame, groups: dict, meta: pd.DataFrame,
                        group_order: list[str]):
    """
    For each (D6 group, site) combination, compute mean abundance
    in seagrass vs non-seagrass plots, log2 ratio, and Mann-Whitney
    U test p-value.  Returns a list of records.

    "groups" is the {label: [columns]} dictionary; "group_order" is
    the desired y-axis order on the heatmap (top groups first).
    """
    df_meta = df.merge(meta[["name", "dex", "env"]], on="name")

    records = []
    for label in group_order:
        cols = groups[label]
        for site in SITE_ORDER:
            sub = df_meta[df_meta["env"] == site]
            sg  = sub.loc[sub["dex"] == "seagrass", cols].sum(axis=1)
            non = sub.loc[sub["dex"] == "non",      cols].sum(axis=1)

            sg_mean  = float(sg.mean())  if len(sg)  else np.nan
            non_mean = float(non.mean()) if len(non) else np.nan

            # Mann-Whitney U with safety guards (n>=3 each)
            if len(sg) >= 3 and len(non) >= 3:
                u, p = scipy_stats.mannwhitneyu(
                    sg, non, alternative="two-sided"
                )
            else:
                u, p = np.nan, np.nan

            log2 = np.log2((sg_mean + 1e-6) / (non_mean + 1e-6))
            records.append({
                "group": label,
                "site":  site,
                "n_sg":  int(len(sg)),
                "n_non": int(len(non)),
                "sg_mean":  sg_mean,
                "non_mean": non_mean,
                "log2_sg_non": log2,
                "u_stat": u,
                "p_value": p,
            })
    return records


def site_matrix_to_csv(records: list, out_path: str) -> None:
    """Save the site x group matrix in long format."""
    df = pd.DataFrame([{
        "group":   r["group"],
        "site":    r["site"],
        "n_sg":    r["n_sg"],
        "n_non":   r["n_non"],
        "sg_mean":  round(r["sg_mean"],  5) if not np.isnan(r["sg_mean"])  else "",
        "non_mean": round(r["non_mean"], 5) if not np.isnan(r["non_mean"]) else "",
        "log2_sg_non": round(r["log2_sg_non"], 3),
        "p_value": round(r["p_value"], 5) if not np.isnan(r["p_value"]) else "",
        "significance": (
            "***" if (not np.isnan(r["p_value"])) and r["p_value"] < 0.001
            else "**"  if (not np.isnan(r["p_value"])) and r["p_value"] < 0.01
            else "*"   if (not np.isnan(r["p_value"])) and r["p_value"] < 0.05
            else "ns"
        ),
    } for r in records])
    df.to_csv(out_path, index=False)
    print(f"Saved: {out_path}")


# ============================================================
# Helper: draw a single heatmap panel
# ============================================================
def draw_heatmap(ax, records: list, group_order: list[str],
                 title: str, vmax: float = 3.0,
                 cbar_ax=None, show_cbar: bool = True) -> None:
    """
    Render a heatmap of log2(SG/Non) with significance asterisks.
    Rows = D6 groups (in supplied order), columns = sites (SITE_ORDER).

    The colormap is centred on zero (RdBu_r) so that:
      blue  cells = seagrass-enriched (positive log2)
      red   cells = non-seagrass-enriched (negative log2)
    The signal we expect for these "bad-actor" lineages is therefore
    predominantly red.
    """
    # Build the matrix: rows = groups, cols = sites
    mat = np.zeros((len(group_order), len(SITE_ORDER)))
    pmat = np.zeros((len(group_order), len(SITE_ORDER)))
    for r in records:
        i = group_order.index(r["group"])
        j = SITE_ORDER.index(r["site"])
        mat[i, j]  = r["log2_sg_non"]
        pmat[i, j] = r["p_value"] if not np.isnan(r["p_value"]) else 1.0

    # Clip extreme log2 values for the colormap to keep visual range
    # readable; raw values are still preserved in the CSV output.
    mat_clip = np.clip(mat, -vmax, vmax)

    im = ax.imshow(mat_clip, cmap="RdBu", vmin=-vmax, vmax=vmax,
                    aspect="auto")

    # Significance asterisks
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            p = pmat[i, j]
            if p < 0.001:   marker = "***"
            elif p < 0.01:  marker = "**"
            elif p < 0.05:  marker = "*"
            else:           marker = ""
            if marker:
                # Pick a contrasting colour for readability against the
                # cell background.
                cell_val = mat_clip[i, j]
                col = "white" if abs(cell_val) > vmax * 0.55 else "black"
                ax.text(j, i, marker, ha="center", va="center",
                        fontsize=STAT_SIZE, fontweight="bold", color=col)

    # Axis labels
    ax.set_xticks(np.arange(len(SITE_ORDER)))
    ax.set_xticklabels(SITE_ORDER, rotation=30, ha="right",
                       fontsize=TICK_SIZE)
    ax.set_yticks(np.arange(len(group_order)))
    ax.set_yticklabels(
        [PRETTY_LABEL.get(g, g) for g in group_order],
        fontsize=TICK_SIZE,
    )
    ax.set_title(title, fontsize=TITLE_SIZE, fontweight="bold", loc="left")

    # Make grid lines between cells for readability
    ax.set_xticks(np.arange(len(SITE_ORDER)+1) - 0.5, minor=True)
    ax.set_yticks(np.arange(len(group_order)+1) - 0.5, minor=True)
    ax.grid(which="minor", color="white", linewidth=1.0)
    ax.tick_params(which="minor", length=0)

    if show_cbar:
        cb = plt.colorbar(im, cax=cbar_ax, orientation="vertical")
        cb.set_label("log2(SG / Non)", fontsize=LABEL_SIZE)
        cb.ax.tick_params(labelsize=TICK_SIZE)


# ============================================================
# Main
# ============================================================
def main():
    df   = pd.read_csv("Eukaryota_seagrass_D15.csv")
    meta = pd.read_csv("Seagrass_list_cnd_dex250917.csv")

    # Harmonise site labels with the rest of the manuscript
    meta["env"] = meta["env"].replace(SITE_RENAME)

    print(f"Eukaryota:  {df.shape[0]} samples, {df.shape[1]-1} taxa columns")
    print(f"Metadata:   {meta.shape[0]} samples")
    print(f"Sites:      {sorted(meta['env'].unique())}")

    # Identify columns belonging to each lineage
    cols       = df.columns.tolist()[1:]
    intra_cols = [c for c in cols if "Intramacronucleata" in c]
    diat_cols  = [c for c in cols if "Diatomea"            in c]

    print(f"\nIntramacronucleata columns: {len(intra_cols)}")
    print(f"Diatomea columns:           {len(diat_cols)}")

    # Aggregate to D6 and compute pooled statistics
    intra_groups = aggregate_d6(df, intra_cols)
    diat_groups  = aggregate_d6(df, diat_cols)

    intra_stats = compute_group_stats(df, intra_groups, meta,
                                       skip_unclassified=True)
    diat_stats  = compute_group_stats(df, diat_groups,  meta,
                                       skip_unclassified=True)

    # ------------------------------------------------------------
    # Print summary to console
    # ------------------------------------------------------------
    def print_summary(rows, title):
        print(f"\n{title}")
        print(f"  {'Group':25s} {'SG mean':>9s} {'Non mean':>9s} "
              f"{'log2(SG/N)':>11s} {'p-value':>10s}  Sig")
        for r in rows:
            sig = ("***" if r["p_value"] < 0.001
                   else "**"  if r["p_value"] < 0.01
                   else "*"   if r["p_value"] < 0.05
                   else "ns")
            print(f"  {r['group']:25s} {r['sg_mean']:>9.4f} "
                  f"{r['non_mean']:>9.4f} {r['log2_sg_non']:>+11.2f} "
                  f"{r['p_value']:>10.4f}  {sig}")

    print_summary(intra_stats, "(a) Intramacronucleata D6 groups (pooled)")
    print_summary(diat_stats,  "(b) Diatomea D6 groups (pooled)")

    # ------------------------------------------------------------
    # Save pooled stats CSV
    # ------------------------------------------------------------
    save_csv(intra_stats, "Supp_Fig_S24a_Intramacronucleata_D6.csv")
    save_csv(diat_stats,  "Supp_Fig_S24b_Diatomea_D6.csv")

    # ------------------------------------------------------------
    # Per-site decomposition for heatmaps (c, d)
    # Use the top groups from the pooled analysis to keep the
    # heatmap readable; tail groups (very low abundance, all-ns)
    # would only add noise.
    # ------------------------------------------------------------
    intra_top = [r["group"] for r in intra_stats[:8]]   # top 8 by abundance
    diat_top  = [r["group"] for r in diat_stats[:5]]    # top 5 by abundance

    intra_site_records = compute_site_matrix(df, intra_groups, meta,
                                              intra_top)
    diat_site_records  = compute_site_matrix(df, diat_groups,  meta,
                                              diat_top)

    site_matrix_to_csv(intra_site_records,
                       "Supp_Fig_S24c_Intramacronucleata_by_site.csv")
    site_matrix_to_csv(diat_site_records,
                       "Supp_Fig_S24d_Diatomea_by_site.csv")

    # ------------------------------------------------------------
    # Figure: 2 x 2 panels (a, b on top: pooled; c, d on bottom: by site)
    # ------------------------------------------------------------
    fig = plt.figure(figsize=(15.5, 13))
    gs = fig.add_gridspec(
        nrows=2, ncols=3,
        width_ratios=[3, 2, 0.10],   # third column reserved for shared cbar
        height_ratios=[1, 1.0],
        wspace=0.30, hspace=0.42,
        left=0.07, right=0.93, top=0.96, bottom=0.06,
    )

    # ---- (a) and (b): pooled box plots --------------------------
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    draw_panel(
        ax_a,
        intra_stats,
        title="(a) Intramacronucleata — pooled comparison",
        ylabel="Relative abundance (% of eukaryotic reads, √-scaled)",
        max_groups=8,
    )
    draw_panel(
        ax_b,
        diat_stats,
        title="(b) Diatomea — pooled comparison",
        ylabel="Relative abundance (% of eukaryotic reads, √-scaled)",
        max_groups=5,
    )

    # Legend for (a)+(b) only — placed at the figure top to avoid
    # overlapping the data points.
    ax_a.legend(
        handles=[
            Patch(facecolor=COLOR_SG,  alpha=0.5, label="Seagrass"),
            Patch(facecolor=COLOR_NON, alpha=0.5, label="Non-seagrass"),
        ],
        fontsize=LABEL_SIZE - 1, loc="upper left",
        bbox_to_anchor=(0.0, 1.02), frameon=False, ncol=2,
    )

    # ---- (c) and (d): site-resolved heatmaps -------------------
    ax_c    = fig.add_subplot(gs[1, 0])
    ax_d    = fig.add_subplot(gs[1, 1])
    ax_cbar = fig.add_subplot(gs[1, 2])

    draw_heatmap(
        ax_c, intra_site_records, intra_top,
        title="(c) Intramacronucleata — by site",
        vmax=2.0,
        cbar_ax=None, show_cbar=False,
    )
    draw_heatmap(
        ax_d, diat_site_records,  diat_top,
        title="(d) Diatomea — by site",
        vmax=2.0,
        cbar_ax=ax_cbar, show_cbar=True,
    )

    fig.savefig("Supp_Fig_S24_Intra_Diat_decomp.pdf",
                dpi=DPI, bbox_inches="tight")
    fig.savefig("Supp_Fig_S24_Intra_Diat_decomp.png",
                dpi=DPI, bbox_inches="tight")
    plt.close(fig)
    print("\nSaved: Supp_Fig_S24_Intra_Diat_decomp.pdf / .png")


if __name__ == "__main__":
    main()

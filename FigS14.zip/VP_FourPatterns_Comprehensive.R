############################################################
# R: Variation Partitioning — 4パターン網羅
#
# VP-A = 微生物群集が応答変数（海草は説明変数）
# VP-B = 海草(0/1)が応答変数
# × Chemical / Cross-kingdom (18S)
#
# 出力先: fourtypes_VP/ フォルダに4つのCSVを出力
#   fourtypes_VP/vp_A_Chemical.csv        — Fig.4 相当（既存の再現）
#   fourtypes_VP/vp_B_Chemical.csv        — 海草応答 × 化学
#   fourtypes_VP/vp_A_CrossKingdom.csv    — 微生物応答 × 18S
#   fourtypes_VP/vp_B_CrossKingdom.csv    — 海草応答 × 16S/18S
############################################################
library(vegan)

# =============================================================
# 0 出力フォルダ作成
# =============================================================
out_dir <- "fourtypes_VP"
if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE)
cat(sprintf("出力先: %s/\n\n", out_dir))

# =============================================================
# 1 データ読み込み
# =============================================================
bac  <- read.csv("Bacteria_diversity_sample.csv")
euk  <- read.csv("Eukaryota_diversity_sample.csv")
chem <- read.csv("Chemical_seagrass_sample.csv")
meta <- read.csv("List.csv")

bac_mat  <- as.matrix(bac[, 2:ncol(bac)])
euk_mat  <- as.matrix(euk[, 2:ncol(euk)])
chem_mat <- chem[, 2:ncol(chem)]

# =============================================================
# 2 前処理
# =============================================================
# 化学: 欠損値補完（中央値）
for (i in 1:ncol(chem_mat)) {
  chem_mat[is.na(chem_mat[, i]), i] <- median(chem_mat[, i], na.rm = TRUE)
}

# Relative abundance
bac_rel <- decostand(bac_mat, method = "total")
euk_rel <- decostand(euk_mat, method = "total")

# 共通変数
region_df  <- data.frame(Region = as.factor(meta$env))
habitat_df <- data.frame(Habitat = as.factor(meta$cnd))

# Seagrass 数値 (0/1) — VP-B用
habitat_num <- ifelse(meta$cnd == "Seagrass", 1,
               ifelse(meta$cnd == "Unvegetated", 0,
                      as.numeric(as.factor(meta$cnd)) - 1))

# =============================================================
# 3 化学変数の準備（VIF選抜 — Fig.4 と同じ手順）
# =============================================================
chem_scaled <- scale(chem_mat)
chem_df     <- as.data.frame(chem_scaled)

# NA/NaN除去（零分散列がscaleでNaNになる場合）
chem_df <- chem_df[, colSums(is.na(chem_df)) == 0]

mod_chem <- capscale(bac_rel ~ ., data = chem_df, distance = "bray")

vif_step <- function(mod, expl_df, resp) {
  v <- vif.cca(mod)
  while (max(v) > 10) {
    remove_var <- names(which.max(v))
    terms_now  <- attr(terms(mod), "term.labels")
    terms_now  <- terms_now[terms_now != remove_var]
    new_formula <- as.formula(paste("resp ~", paste(terms_now, collapse = "+")))
    mod <- capscale(new_formula, data = expl_df, distance = "bray")
    v <- vif.cca(mod)
  }
  return(mod)
}
dbrda_chem   <- vif_step(mod_chem, chem_df, bac_rel)
vars_final   <- attr(terms(dbrda_chem), "term.labels")
chem_final   <- chem_df[, vars_final]

cat(sprintf("Chemical VIF後の変数数: %d\n", length(vars_final)))
cat("変数:", paste(vars_final, collapse = ", "), "\n\n")

# =============================================================
# 4 PCoA 次元削減（Cross-kingdom用）
# =============================================================
choose_k <- function(dist_mat, max_k = 20, cum_threshold = 0.70) {
  pc <- cmdscale(dist_mat, k = max_k, eig = TRUE)
  eig_pos <- pc$eig[pc$eig > 0]
  cum_var <- cumsum(eig_pos) / sum(eig_pos)
  k <- min(which(cum_var >= cum_threshold), max_k)
  cat(sprintf("  k = %d (累積寄与率 %.1f%%)\n", k, cum_var[k] * 100))
  return(list(scores = pc$points[, 1:k], k = k))
}

cat("--- 18S PCoA ---\n")
euk_pc    <- choose_k(vegdist(euk_rel, "bray"))
euk_pc_df <- as.data.frame(euk_pc$scores)
colnames(euk_pc_df) <- paste0("EukPC", 1:euk_pc$k)

cat("--- 16S PCoA ---\n")
bac_pc    <- choose_k(vegdist(bac_rel, "bray"))
bac_pc_df <- as.data.frame(bac_pc$scores)
colnames(bac_pc_df) <- paste0("BacPC", 1:bac_pc$k)

# =============================================================
# 共通: varpart 結果を data.frame 化する関数
# =============================================================
vp_to_df <- function(vp_obj) {
  fract <- vp_obj$part$indfract
  data.frame(
    fraction     = fract$Df,           # varpart が自動付与するラベル
    Adj.R.square = fract$Adj.R.square
  )
}

# ラベルを手動で付ける版（3説明変数: X1, X2, X3）
vp_to_df_labeled <- function(vp_obj, x1_name, x2_name, x3_name) {
  fract <- vp_obj$part$indfract
  data.frame(
    fraction = c(
      paste0("[a] ", x1_name, " only"),
      paste0("[b] ", x2_name, " only"),
      paste0("[c] ", x3_name, " only"),
      paste0("[d] ", x1_name, " ∩ ", x2_name),
      paste0("[e] ", x1_name, " ∩ ", x3_name),
      paste0("[f] ", x2_name, " ∩ ", x3_name),
      paste0("[g] ", x1_name, " ∩ ", x2_name, " ∩ ", x3_name),
      "[h] Residual"
    ),
    Adj.R.square = fract$Adj.R.square
  )
}

# =============================================================
# 5  VP-A Chemical: varpart(bac_rel, Region, Habitat, Chemistry)
#    → Fig. 4 相当
# =============================================================
cat("\n========== VP-A Chemical ==========\n")
cat("varpart( bac_rel ~ Region + Habitat + Chemistry )\n\n")
vp_A_chem <- varpart(bac_rel, region_df, habitat_df, chem_final)
print(vp_A_chem)

df_A_chem <- vp_to_df_labeled(vp_A_chem, "Region", "Habitat", "Chemistry")
write.csv(df_A_chem, file.path(out_dir, "vp_A_Chemical.csv"), row.names = FALSE)
cat(sprintf("Saved: %s/vp_A_Chemical.csv\n", out_dir))

# =============================================================
# 6  VP-B Chemical: varpart(habitat, Region, 16S PCoA, Chemistry)
#    → 海草応答 × 化学
# =============================================================
cat("\n========== VP-B Chemical ==========\n")
cat("varpart( Seagrass ~ Region + 16S + Chemistry )\n\n")
vp_B_chem <- varpart(habitat_num, region_df, bac_pc_df, chem_final)
print(vp_B_chem)

df_B_chem <- vp_to_df_labeled(vp_B_chem, "Region", "16S", "Chemistry")
write.csv(df_B_chem, file.path(out_dir, "vp_B_Chemical.csv"), row.names = FALSE)
cat(sprintf("Saved: %s/vp_B_Chemical.csv\n", out_dir))

# =============================================================
# 7  VP-A Cross-kingdom: varpart(bac_rel, Region, Habitat, 18S PCoA)
#    → Fig.4 の Chemistry を 18S に置き換え
# =============================================================
cat("\n========== VP-A Cross-Kingdom ==========\n")
cat("varpart( bac_rel ~ Region + Habitat + 18S )\n\n")
vp_A_cross <- varpart(bac_rel, region_df, habitat_df, euk_pc_df)
print(vp_A_cross)

df_A_cross <- vp_to_df_labeled(vp_A_cross, "Region", "Habitat", "18S")
write.csv(df_A_cross, file.path(out_dir, "vp_A_CrossKingdom.csv"), row.names = FALSE)
cat(sprintf("Saved: %s/vp_A_CrossKingdom.csv\n", out_dir))

# =============================================================
# 8  VP-B Cross-kingdom: varpart(habitat, Region, 16S PCoA, 18S PCoA)
#    → 海草応答 × 16S/18S
# =============================================================
cat("\n========== VP-B Cross-Kingdom ==========\n")
cat("varpart( Seagrass ~ Region + 16S + 18S )\n\n")
vp_B_cross <- varpart(habitat_num, region_df, bac_pc_df, euk_pc_df)
print(vp_B_cross)

df_B_cross <- vp_to_df_labeled(vp_B_cross, "Region", "16S", "18S")
write.csv(df_B_cross, file.path(out_dir, "vp_B_CrossKingdom.csv"), row.names = FALSE)
cat(sprintf("Saved: %s/vp_B_CrossKingdom.csv\n", out_dir))

# =============================================================
# 9  サマリー: 注目すべき共有効果の一覧
# =============================================================
cat("\n")
cat("============================================================\n")
cat("SUMMARY — 主要な共有効果 (Adj.R²)\n")
cat("============================================================\n")
cat(sprintf("VP-A Chemical   [f] Habitat ∩ Chemistry : %.3f  (← Fig.4 = 0.245)\n",
    df_A_chem$Adj.R.square[6]))
cat(sprintf("VP-B Chemical   [f] 16S ∩ Chemistry     : %.3f\n",
    df_B_chem$Adj.R.square[6]))
cat(sprintf("VP-A CrossKgdm  [f] Habitat ∩ 18S       : %.3f  (← 0.245と対比)\n",
    df_A_cross$Adj.R.square[6]))
cat(sprintf("VP-B CrossKgdm  [f] 16S ∩ 18S           : %.3f\n",
    df_B_cross$Adj.R.square[6]))
cat("============================================================\n")
cat("\n出力ファイル:\n")
cat(sprintf("  %s/vp_A_Chemical.csv       — bac_rel ~ Region + Habitat + Chemistry\n", out_dir))
cat(sprintf("  %s/vp_B_Chemical.csv       — Seagrass ~ Region + 16S + Chemistry\n", out_dir))
cat(sprintf("  %s/vp_A_CrossKingdom.csv   — bac_rel ~ Region + Habitat + 18S\n", out_dir))
cat(sprintf("  %s/vp_B_CrossKingdom.csv   — Seagrass ~ Region + 16S + 18S\n", out_dir))
cat("============================================================\n")


#! /bin/sh



#####16S BacV3/BacV4ペアのデータベースチェック#####
### ターミナルを新たに起動
### cd
### cd ~/software
### ls
### 上記のコマンド実行後に出てくるリストの中にSILVA_132_QIIME_releaseがあることを確認すること
### ない場合はデータベースのインストールを行うこと



#QIIME2環境に入る：これは手動で実行する・以下の先頭の#を除いたコマンドを実行
conda activate qiime2-2021.4



#ここ以下はスクリプトとして自動実行可能（このスクリプトはどこで実行しても良い）

#実行権限を付与する
#chmod u+x /Full/path/to/working/directory/01_qiime2_clasifier_prep_16S_V3V4.sh

#実行する（逐次結果が表示される形式）
#/Full/path/to/working/directory/01_qiime2_clasifier_prep_16S_V3V4.sh

#または以下を実行する（バックグラウンドで実行・エラーなどは作業ディレクトリに保存される 01_log.txt か 01_err.txt ファイルに書き込まれる）
#nohup /Full/path/to/working/directory/01_qiime2_clasifier_prep_16S_V3V4.sh > 01_log.txt 2> 01_err.txt &

#なお「/Full/path/to/working/directory/」はスクリプトのパス（スクリプトファイルをTerminalにドラッグドロップすると自動で入力される）

#スクリプトとして自動実行せず、以下のコマンド（改行無く続いているものがひとまとまりのコマンド）を逐次コピペで実行していってもよい
#以下のコマンドはプライマーセットの配列が異なる場合を除いて書き換える必要はありません
#（自動実行ではエラーが出る場合等で、原因を突き止めたい場合など）



### Identifierの作成 ###
### Silva 132の16S配列データから、解析に必要な検索用データを作る ###
### このスクリプトはデータベースのセッティングプロセスなので、各プライマーセット毎に最初に一回行うのみでよい###

#データベース配列のインプット
qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path ~/software/SILVA_132_QIIME_release/rep_set/rep_set_16S_only/99/silva_132_99_16S.fna \
  --output-path ~/software/SILVA_132_QIIME_release/rep_set/rep_set_16S_only/99/silva_132_99_16S.qza
  
#データベースタクソン情報のインプット
qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path ~/software/SILVA_132_QIIME_release/taxonomy/16S_only/99/taxonomy_7_levels.txt \
  --output-path ~/software/SILVA_132_QIIME_release/taxonomy/16S_only/99/taxonomy_7_levels.qza

#データベース配列から解析に使用するPCR増幅領域の切り出し
#以下のプライマーセットを使用している：これと異なる配列を用いている場合は書き換えること
#--p-f-primer = FW (BacV3_V4_F_Illumina_Dual (Read1 side)) : CCTACGGGNGGCWGCAG
#--p-r-primer = RV (BacV3_V4_R_Illumina_Dual (Read2 side)) : GACTACHVGGGTATCTAATCC

qiime feature-classifier extract-reads \
  --i-sequences ~/software/SILVA_132_QIIME_release/rep_set/rep_set_16S_only/99/silva_132_99_16S.qza \
  --p-f-primer CCTACGGGNGGCWGCAG\
  --p-r-primer GACTACHVGGGTATCTAATCC \
  --o-reads ~/software/SILVA_132_QIIME_release/rep_set/rep_set_16S_only/99/99_otus_16S_amplicon_V3V4.qza

#実際のターゲット配列検出に対する最適化による検出器「Classifier」の作成
qiime feature-classifier fit-classifier-naive-bayes \
  --i-reference-reads ~/software/SILVA_132_QIIME_release/rep_set/rep_set_16S_only/99/99_otus_16S_amplicon_V3V4.qza \
  --i-reference-taxonomy ~/software/SILVA_132_QIIME_release/taxonomy/16S_only/99/taxonomy_7_levels.qza \
  --o-classifier ~/software/SILVA_132_QIIME_release/taxonomy/16S_only/99/classifier_V3V4.qza

#ここで出来たV3V4ペア専用の「classifier_V3V4.qza」を使用してタクソンの同定を行う



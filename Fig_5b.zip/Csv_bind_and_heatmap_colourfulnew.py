#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import pandas as pd
import re
from pathlib import Path
import seaborn as sns
import matplotlib.pyplot as plt

# =========================
# フォント設定（Helvetica）
# =========================
plt.rcParams["font.family"] = "Helvetica"

# =========================
# depth をファイル名から抽出
# =========================
def extract_depth(path):
    patterns = [
        r"(\d+)[_\-]?depth",   # 5depth, 5_depth, 5-depth
        r"depth[_\-]?(\d+)",   # depth5, depth_5, depth-5
    ]
    for pat in patterns:
        m = re.search(pat, str(path))
        if m:
            return int(m.group(1))
    raise ValueError(f"Cannot extract depth from path: {path}")

# =========================
# CSV 読み込み + depth 列追加
# =========================
def read_csv_with_depth(csv_file):
    df = pd.read_csv(csv_file, sep=None, engine="python")  # 区切り自動判定
    df.columns = [c.strip() for c in df.columns]            # 列名整理
    depth = extract_depth(csv_file)
    df["depth"] = depth
    return df

# =========================
# メイン処理
# =========================
def main():
    if len(sys.argv) < 2:
        print("Usage: python combine_depths_heatmap.py <csv1> <csv2> ...")
        sys.exit(1)

    dfs = []
    for f in sys.argv[1:]:
        path = Path(f)
        if not path.exists():
            print(f"Warning: file not found: {f}")
            continue
        dfs.append(read_csv_with_depth(f))

    if not dfs:
        print("No valid CSV files to process.")
        sys.exit(1)

    # 全 CSV を結合
    df_all = pd.concat(dfs, ignore_index=True)

    # 必要列確認
    required_cols = ["Variable", "Count", "Frequency", "depth"]
    missing = set(required_cols) - set(df_all.columns)
    if missing:
        raise ValueError(f"Missing columns in combined CSV: {missing}")

    # 結合結果 CSV 保存
    df_all.to_csv("all_bind.csv", index=False)
    print("Saved combined CSV as all_bind.csv")

    # wide形式に pivot（行=Variable, 列=depth, 値=Frequency）
    heatmap_df = df_all.pivot(index="Variable", columns="depth", values="Frequency").fillna(0)

    # =========================
    # 出力フォルダ作成
    # =========================
    output_folder = Path("heatmap_output")
    output_folder.mkdir(exist_ok=True)
    output_png = output_folder / "heatmap_frequency.png"
    output_pdf = output_folder / "heatmap_frequency.pdf"

    # =========================
    # heatmap 描画
    # =========================
    plt.figure(figsize=(10, max(6, len(heatmap_df)/2)))

    sns.heatmap(
        heatmap_df,
        cmap="YlGnBu",       # 色の濃淡
        annot=True,           # セルに数値表示
        fmt=".2f",            # 小数点2桁
        linewidths=0.3,       # セル境界線の太さ
        linecolor='gray',    # セル境界線の色
        cbar_kws={"label": "Frequency"}  # カラーバーラベル
    )

    # X軸・Y軸ラベルとタイトル
    plt.title("Variables Frequency across Depths")
    plt.xlabel("Depth")
    plt.ylabel("Variable")
    plt.xticks(rotation=0)
    plt.yticks(rotation=0)
    plt.tight_layout()

    # =========================
    # 保存（PNG と PDF）
    # =========================
    plt.savefig(output_png, dpi=300, bbox_inches='tight')
    print(f"Saved heatmap as {output_png}")
    plt.savefig(output_pdf, dpi=300, bbox_inches='tight')
    print(f"Saved heatmap as {output_pdf}")

    # 表示
    plt.show()

# =========================
if __name__ == "__main__":
    main()

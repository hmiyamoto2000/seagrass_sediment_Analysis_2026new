suppressPackageStartupMessages({library(readr); library(dplyr); library(tidyr)})

v   <- read_csv("phase6e_full_validation_v2.csv", show_col_types=FALSE)
fit <- read_csv("phase5c_full_fit.csv", show_col_types=FALSE) %>%
  filter(converged, gfi>=0.95, agfi>=0.90, wrmr<=1.0)
uni <- read_csv("phase6d_universality.csv", show_col_types=FALSE)

# 697 Universal モデルに絞る
m <- fit %>% inner_join(uni %>% select(sr1, sr2, downset, n_universal,
                                       n_nonuniversal, min_interaction_p),
                        by=c("sr1","sr2","downset")) %>%
  filter(n_universal == k) %>%
  inner_join(v, by=c("sr1","sr2","downset"))

cat(sprintf("Universal models with full validation: %d\n\n", nrow(m)))

# Helper for formatting
fmt_med <- function(x) sprintf("%.3f [%.3f, %.3f]",
                                median(x, na.rm=TRUE),
                                quantile(x, 0.25, na.rm=TRUE),
                                quantile(x, 0.75, na.rm=TRUE))

# === Section 1: Fit indices ===
cat("=== ED Table 1A. SEM fit indices (697 Universal models) ===\n")
fit_summary <- tibble(
  Index = c("chi-square p-value","CFI","TLI","RMSEA","SRMR","WRMR","GFI","AGFI"),
  `median [IQR]` = c(fmt_med(m$pvalue), fmt_med(m$cfi), fmt_med(m$tli),
                     fmt_med(m$rmsea),  fmt_med(m$srmr), fmt_med(m$wrmr),
                     fmt_med(m$gfi),    fmt_med(m$agfi)),
  Threshold = c(">= 0.10", ">= 0.95", "> 0.90", "<= 0.06",
                "<= 0.08", "<= 1.00", ">= 0.95", ">= 0.90"),
  `% passing` = c(
    sprintf("%.1f%%", 100*mean(m$pvalue >= 0.10, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$cfi >= 0.95, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$tli > 0.90,  na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$rmsea <= 0.06, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$srmr <= 0.08, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$wrmr <= 1.0,  na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$gfi >= 0.95, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$agfi >= 0.90, na.rm=TRUE))))
print(fit_summary)

# === Section 2: Path coefficients ===
cat("\n=== ED Table 1B. SR path coefficients (697 Universal models) ===\n")
# 論文表示: SR_score1 = biome (内部 sr2), SR_score2 = chemistry (内部 sr1)
sr_summary <- tibble(
  Path = c("Seagrass ~ SR_score1 (biome)", "Seagrass ~ SR_score2 (chemistry)"),
  `std beta median [IQR]` = c(fmt_med(m$sr2_std), fmt_med(m$sr1_std)),
  `p-value max` = c(sprintf("%.2e", max(m$sr2_p, na.rm=TRUE)),
                    sprintf("%.2e", max(m$sr1_p, na.rm=TRUE))),
  `% SIG (p<0.05)` = c(sprintf("%.1f%%", 100*mean(m$sr2_p < 0.05, na.rm=TRUE)),
                       sprintf("%.1f%%", 100*mean(m$sr1_p < 0.05, na.rm=TRUE))))
print(sr_summary)

# === Section 3: Predictive validity (CV) ===
cat("\n=== ED Table 1C. Cross-validation (697 Universal models) ===\n")
cv_summary <- tibble(
  CV = c("4-fold AUC","4-fold Brier","8-fold AUC","8-fold Brier",
         "LORO AUC (4 regions)","LORO Brier"),
  `median [IQR]` = c(fmt_med(m$cv4_auc), fmt_med(m$cv4_brier),
                     fmt_med(m$cv8_auc), fmt_med(m$cv8_brier),
                     fmt_med(m$loro_auc), fmt_med(m$loro_brier)))
print(cv_summary)

# === Section 4: Likelihood ratio test ===
cat("\n=== ED Table 1D. Likelihood ratio test for SR contribution ===\n")
lrt_summary <- tibble(
  Test = c("SR_score1 (biome) LRT (vs reduced)", "SR_score2 (chemistry) LRT (vs reduced)"),
  `p median [IQR]` = c(fmt_med(m$sr2_lrt_p), fmt_med(m$sr1_lrt_p)),
  `p max` = c(sprintf("%.2e", max(m$sr2_lrt_p, na.rm=TRUE)),
              sprintf("%.2e", max(m$sr1_lrt_p, na.rm=TRUE))),
  `% SIG (p<0.05)` = c(sprintf("%.1f%%", 100*mean(m$sr2_lrt_p < 0.05, na.rm=TRUE)),
                       sprintf("%.1f%%", 100*mean(m$sr1_lrt_p < 0.05, na.rm=TRUE))))
print(lrt_summary)

# === Section 5: SR x Region universality (logistf) ===
cat("\n=== ED Table 1E. SR Region universality (logistf interaction p) ===\n")
reg_summary <- tibble(
  `SR x Region` = c("SR1 x Region B","SR1 x Region C","SR1 x Region D",
                    "SR2 x Region B","SR2 x Region C","SR2 x Region D"),
  `p median [IQR]` = c(fmt_med(m$sr1_regB_p), fmt_med(m$sr1_regC_p), fmt_med(m$sr1_regD_p),
                       fmt_med(m$sr2_regB_p), fmt_med(m$sr2_regC_p), fmt_med(m$sr2_regD_p)),
  `% NS (p>=0.05) = Universal` = c(
    sprintf("%.1f%%", 100*mean(m$sr1_regB_p >= 0.05, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$sr1_regC_p >= 0.05, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$sr1_regD_p >= 0.05, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$sr2_regB_p >= 0.05, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$sr2_regC_p >= 0.05, na.rm=TRUE)),
    sprintf("%.1f%%", 100*mean(m$sr2_regD_p >= 0.05, na.rm=TRUE))))
print(reg_summary)

# Save all to single CSV (long format for paper formatting)
writeLines(c(
  "=== ED Table 1A. Fit indices ===",
  capture.output(print(fit_summary)),
  "",
  "=== ED Table 1B. SR path coefficients ===",
  capture.output(print(sr_summary)),
  "",
  "=== ED Table 1C. Cross-validation ===",
  capture.output(print(cv_summary)),
  "",
  "=== ED Table 1D. LRT ===",
  capture.output(print(lrt_summary)),
  "",
  "=== ED Table 1E. SR x Region universality ===",
  capture.output(print(reg_summary))
), "ED_Table1_summary.txt")

# Combined CSV for easy paper inclusion
combined_csv <- bind_rows(
  fit_summary %>% mutate(Section="A. Fit indices") %>% rename(Item=Index, Value=`median [IQR]`),
  sr_summary  %>% mutate(Section="B. SR paths")    %>% rename(Item=Path,  Value=`std beta median [IQR]`),
  cv_summary  %>% mutate(Section="C. Cross-validation") %>% rename(Item=CV, Value=`median [IQR]`),
  lrt_summary %>% mutate(Section="D. LRT")         %>% rename(Item=Test,  Value=`p median [IQR]`),
  reg_summary %>% mutate(Section="E. Universality") %>% rename(Item=`SR x Region`, Value=`p median [IQR]`)
) %>% select(Section, Item, Value, everything())
write_csv(combined_csv, "ED_Table1_validation_summary.csv")
cat("\nSaved: ED_Table1_summary.txt and ED_Table1_validation_summary.csv\n")

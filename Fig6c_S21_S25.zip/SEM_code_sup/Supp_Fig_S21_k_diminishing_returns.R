suppressPackageStartupMessages({
  library(readr); library(dplyr); library(ggplot2); library(patchwork); library(tidyr)
})

# Helvetica font
if (Sys.info()["sysname"] == "Darwin") {
  theme_set(theme_classic(base_family="Helvetica", base_size=11))
}

ph4  <- read_csv("phase4_combined_results.csv", show_col_types=FALSE)
ph5c <- read_csv("phase5c_full_fit.csv", show_col_types=FALSE)
ph7  <- read_csv("phase7_universal_candidates.csv", show_col_types=FALSE)
ph7  <- ph7 %>% filter(tli >= 0.95, agfi >= 0.95)  # strict 505

count_k <- function(s) ifelse(is.na(s) | s == "", NA_integer_,
                              lengths(strsplit(s, split="|", fixed=TRUE)))
ph4$k  <- count_k(ph4$downset)
ph5c$k <- count_k(ph5c$downset)
ph7$k  <- count_k(ph7$downset)

actual <- tibble(k=1:7,
  attempted = as.integer(sapply(1:7, function(kk) choose(18, kk)) * 6)) %>%
  left_join(ph4 %>% filter(converged) %>% count(k, name="converged"), by="k") %>%
  left_join(ph5c %>% filter(converged, gfi>=0.95, agfi>=0.95, tli>=0.95, wrmr<=1.0) %>%
            count(k, name="qualified"), by="k") %>%
  left_join(ph7 %>% count(k, name="universal"), by="k") %>%
  mutate(across(-k, ~ replace_na(., 0L)))

# Totals for funnel
total_attempted  <- sum(actual$attempted)
total_converged  <- sum(actual$converged)
total_qualified  <- sum(actual$qualified)
total_universal  <- sum(actual$universal)

clean_theme <- theme_classic(base_size=11, base_family="Helvetica") +
  theme(
    panel.grid = element_blank(),
    plot.subtitle = element_text(size=8, color="grey40"),
    plot.title = element_text(size=11, face="bold")
  )

# ══════════════════════════════════════
# Panel A: FUNNEL DIAGRAM (縦横反転版: 縦向き棒グラフ)
# ══════════════════════════════════════
funnel_data <- tibble(
  stage = factor(c("1. Exhaustive\nenumeration",
                    "2. WLSMV\nconverged",
                    "3. 8 fit criteria\nqualified",
                    "4. Regional\nuniversality"),
                 levels=c("1. Exhaustive\nenumeration",
                           "2. WLSMV\nconverged",
                           "3. 8 fit criteria\nqualified",
                           "4. Regional\nuniversality")),
  n = c(total_attempted, total_converged, total_qualified, total_universal),
  fill = c("grey60","steelblue","darkorange","forestgreen")
)
funnel_data$label <- sprintf("%s\n(%.2f%%)", format(funnel_data$n, big.mark=","),
                              100 * funnel_data$n / total_attempted)
funnel_data$label[1] <- format(funnel_data$n[1], big.mark=",")

pA <- ggplot(funnel_data, aes(x=stage, y=n, fill=stage)) +
  geom_col(width=0.7, show.legend=FALSE) +
  geom_text(aes(label=label), vjust=-0.3, size=3, fontface="bold") +
  scale_fill_manual(values=c("grey60","steelblue","darkorange","forestgreen")) +
  scale_y_log10(labels=scales::comma,
                limits=c(1, total_attempted * 5),
                expand=c(0, 0)) +
  labs(x=NULL, y="Number of models (log10)",
       title="A. Model filtering pipeline",
       subtitle=sprintf("%s candidates → %d universal models (%.2f%%)",
                        format(total_attempted, big.mark=","),
                        total_universal,
                        100*total_universal/total_attempted)) +
  clean_theme

# ══════════════════════════════════════
# Panel B: convergence rate by k
# ══════════════════════════════════════
panelB_data <- actual %>% mutate(conv_rate = converged / attempted * 100)
pB <- ggplot(panelB_data, aes(x=k, y=conv_rate)) +
  geom_col(fill="steelblue", alpha=0.8) +
  geom_text(aes(label=sprintf("%.1f%%", conv_rate)),
            vjust=-0.3, size=2.8) +
  scale_x_continuous(breaks=1:7) +
  scale_y_continuous(limits=c(0, NA), expand=expansion(mult=c(0, 0.15))) +
  labs(x="k (downstream variables)", y="Convergence rate (%)",
       title="B. WLSMV convergence rate by complexity") +
  clean_theme

# ══════════════════════════════════════
# Panel C: Universal count by k
# ══════════════════════════════════════
panelC_data <- actual %>%
  mutate(uni_rate = ifelse(qualified>0, universal/qualified*100, NA))
pC <- ggplot(panelC_data, aes(x=k, y=universal)) +
  geom_col(fill="forestgreen", alpha=0.8) +
  geom_text(aes(label=sprintf("%d", universal)),
            vjust=-0.3, size=2.8) +
  scale_x_continuous(breaks=1:7) +
  scale_y_continuous(limits=c(0, NA), expand=expansion(mult=c(0, 0.15))) +
  labs(x="k", y="Number of universal models",
       title="C. Universal model count by complexity") +
  clean_theme

# ══════════════════════════════════════
# Panel D: cumulative coverage
# ══════════════════════════════════════
panelD_data <- panelC_data %>% arrange(k) %>%
  mutate(cum_universal = cumsum(universal),
         cum_pct = cum_universal / sum(universal) * 100)
pD <- ggplot(panelD_data, aes(x=k, y=cum_pct)) +
  geom_line(color="purple", linewidth=1.2) +
  geom_point(size=3, color="purple") +
  geom_text(aes(label=sprintf("%.1f%%", cum_pct)), vjust=-0.8, size=3) +
  scale_x_continuous(breaks=1:7) +
  scale_y_continuous(limits=c(0, 110), expand=c(0, 0)) +
  labs(x="k (cumulative up to)",
       y=sprintf("Cumulative %% of %d models", total_universal),
       title="D. Cumulative coverage") +
  clean_theme

# ══════════════════════════════════════
# Combine Page 1: A-D
# ══════════════════════════════════════
page1 <- (pA + pB) / (pC + pD) +
  plot_annotation(
    title = "Diminishing returns of model complexity in exhaustive SEM search",
    subtitle = sprintf("505 universal models: CFI>=0.95, TLI>=0.95, RMSEA<=0.06, SRMR<=0.08, GFI>=0.95, AGFI>=0.95, WRMR<=1.0"),
    theme = theme(plot.title=element_text(size=12, face="bold", family="Helvetica"),
                  plot.subtitle=element_text(size=9, color="grey30", family="Helvetica")))

# ── Source Data export (Fig. S20) ──────────────────────────────────────
# Panels b/c/d: per-k attempted, converged, qualified, universal counts.
# Panel a: funnel stage counts.
write_csv(actual,      "Supp_Fig_S20_per_k_counts.csv")
write_csv(funnel_data, "Supp_Fig_S20_panel_a_funnel.csv")
cat("Saved Source Data: Supp_Fig_S20_per_k_counts.csv,",
    "Supp_Fig_S20_panel_a_funnel.csv\n")

ggsave("Supp_Fig_S20_k_diminishing_returns.png", page1,
       width=15, height=10, dpi=300)
ggsave("Supp_Fig_S20_k_diminishing_returns.pdf", page1,
       width=15, height=10)
cat("Saved page 1: Supp_Fig_S20_k_diminishing_returns\n")

# ══════════════════════════════════════
# Panel E (separate page): Detailed funnel with criteria
# ══════════════════════════════════════
funnel_detail <- tibble(
  stage = factor(
    c("Exhaustive enumeration\nC(18,k) × 6 SR pairs, k=1..7",
      "WLSMV convergence",
      "χ² p > 0.1",
      "CFI ≥ 0.95",
      "TLI ≥ 0.95",
      "RMSEA ≤ 0.06",
      "SRMR ≤ 0.08",
      "GFI ≥ 0.95",
      "AGFI ≥ 0.95",
      "WRMR ≤ 1.0",
      "Regional universality\n(Seagrass × Region p ≥ 0.05)"),
    levels=rev(c(
      "Exhaustive enumeration\nC(18,k) × 6 SR pairs, k=1..7",
      "WLSMV convergence",
      "χ² p > 0.1",
      "CFI ≥ 0.95",
      "TLI ≥ 0.95",
      "RMSEA ≤ 0.06",
      "SRMR ≤ 0.08",
      "GFI ≥ 0.95",
      "AGFI ≥ 0.95",
      "WRMR ≤ 1.0",
      "Regional universality\n(Seagrass × Region p ≥ 0.05)"))
  ),
  n = c(total_attempted, total_converged,
        # Intermediate counts: apply filters cumulatively on ph5c
        nrow(ph5c %>% filter(converged, pvalue > 0.1)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95, rmsea <= 0.06)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95, rmsea <= 0.06, srmr <= 0.08)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95, rmsea <= 0.06, srmr <= 0.08, gfi >= 0.95)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95, rmsea <= 0.06, srmr <= 0.08, gfi >= 0.95, agfi >= 0.95)),
        nrow(ph5c %>% filter(converged, pvalue > 0.1, cfi >= 0.95, tli >= 0.95, rmsea <= 0.06, srmr <= 0.08, gfi >= 0.95, agfi >= 0.95, wrmr <= 1.0)),
        total_universal),
  color = c("grey60","steelblue",
            rep("darkorange", 8),
            "forestgreen")
)

funnel_detail$pct <- sprintf("%.2f%%", 100 * funnel_detail$n / total_attempted)
funnel_detail$label <- sprintf("%s  (%s)", format(funnel_detail$n, big.mark=","), funnel_detail$pct)

pE <- ggplot(funnel_detail, aes(x=stage, y=n, fill=color)) +
  geom_col(width=0.6, show.legend=FALSE) +
  geom_text(aes(label=label), hjust=-0.05, size=3.2, family="Helvetica") +
  scale_fill_identity() +
  scale_y_log10(labels=scales::comma,
                limits=c(1, total_attempted * 8),
                expand=c(0, 0)) +
  coord_flip() +
  labs(x=NULL, y="Number of models (log10)",
       title="E. Complete filtering pipeline: from exhaustive enumeration to universal models",
       subtitle=sprintf("%s candidates → %d universal models",
                        format(total_attempted, big.mark=","), total_universal)) +
  clean_theme +
  theme(axis.text.y = element_text(size=9))

write_csv(funnel_detail, "Supp_Fig_S20_panel_e_filtering_pipeline.csv")
cat("Saved Source Data: Supp_Fig_S20_panel_e_filtering_pipeline.csv\n")

ggsave("Supp_Fig_S20_filtering_pipeline.png", pE,
       width=14, height=8, dpi=300)
ggsave("Supp_Fig_S20_filtering_pipeline.pdf", pE,
       width=14, height=8)
cat("Saved page 2: Supp_Fig_S20_filtering_pipeline\n")

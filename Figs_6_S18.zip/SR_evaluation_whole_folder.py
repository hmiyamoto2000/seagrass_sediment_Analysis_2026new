#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#source /Users/****/opt/anaconda3/bin/activate
#conda activate pysr310

import sys
import pandas as pd
import matplotlib.pyplot as plt
import os

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 コード.py depth4_sr_results.csv depth5_sr_results.csv ...")
        sys.exit(1)

    csv_files = sys.argv[1:]
    plt.figure(figsize=(8,5))

    # ===== 出力フォルダー =====
    output_dir = "results"
    os.makedirs(output_dir, exist_ok=True)

    for csv_file in csv_files:
        try:
            df = pd.read_csv(csv_file)
        except Exception as e:
            print(f"Error reading CSV file {csv_file}: {e}")
            continue

        required_cols = ['Complexity', 'Loss', 'Equation']
        if not all(col in df.columns for col in required_cols):
            print(f"CSV {csv_file} is missing required columns. Skipping.")
            continue

        base_name = os.path.basename(csv_file)
        depth = ''.join([c for c in base_name if c.isdigit()])

        plt.plot(df['Complexity'], df['Loss'],
                 marker='o', linestyle='-', label=f"Depth {depth}")

    plt.xlabel("Complexity (Model Complexity)")
    plt.ylabel("Loss (Mean Squared Error)")
    plt.title("SR Loss vs Complexity for Different Depths")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()

    # ===== 保存先をフォルダー配下に =====
    pdf_path = os.path.join(output_dir, "SR_Loss_vs_Complexity_all_depths.pdf")
    png_path = os.path.join(output_dir, "SR_Loss_vs_Complexity_all_depths.png")

    plt.savefig(pdf_path, dpi=300)
    plt.savefig(png_path, dpi=300)

    print(f"Plot saved in '{output_dir}/'")
    plt.show()

if __name__ == "__main__":
    main()


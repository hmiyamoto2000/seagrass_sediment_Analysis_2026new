library(lavaan)
library(caret)
library(pROC)

# データ読み込み
input <- read.csv("causal_learning_data_seagrass_CLR_region_site.csv")

# Seagrass 二値category
input$Seagrass <- factor(input$Seagrass, levels = c(0,1))

# ===== SR_score 作成 =====

# ===== SR_score ===== depth7_loss_1
input$SR_score <- with(input,
                       ((B_Desulfobulbaceae * 7.283997e-5) * ((((B_uncultured_Aminicenantes_bacterium - E_Intramacronucleata) * ((E_Intramacronucleata * 2.198965) - (B_bacterium_enrichment_culture_clone_22_2013 + E_Corallinophycidae))) - (E_Corallinophycidae * B_Defluviitaleaceae)) + (((B_Defluviitaleaceae + B_Desulfobulbaceae) + (B_Desulfobulbaceae + B_Hyphomonadaceae)) * B_Desulfobulbaceae)))
)

# ===== SR_score ===== depth5_loss_1
input$SR_score <- with(input,
                       ((((E_Corallinophycidae * 0.002458644) * (E_Corallinophycidae - B_uncultured_Aminicenantes_bacterium)) - ((B_Pirellulaceae * 0.30556852) - -0.31194133)) + (((E_Intramacronucleata * -0.03973686) - (B_Desulfobulbaceae * -0.3685071)) - ((B_uncultured_Aminicenantes_bacterium * -0.0016488994) * (E_Diatomea + B_Defluviitaleaceae))))
)

# ===== SR_score ===== depth6_loss_1
input$SR_score <- with(input,
                       (((((B_Defluviitaleaceae * 0.024155827) - (B_Desulfobulbaceae * -0.19192262)) + ((B_Hyphomonadaceae - B_bacterium_enrichment_culture_clone_22_2013) * 0.011281977)) + -2.398586) - ((((E_Corallinophycidae + B_bacterium_enrichment_culture_clone_22_2013) - E_Intramacronucleata) - E_Diatomea) * ((B_uncultured_Aminicenantes_bacterium - E_Intramacronucleata) * 0.0016040233)))
)

# ===== SR_score ===== depth8_loss_1
input$SR_score <- with(input,
                       (((E_Corallinophycidae + 2.576786) * (B_Desulfobulbaceae * 0.015538846)) + ((((((E_Diatomea * 0.15299825) - 1.4424695) * (B_uncultured_Aminicenantes_bacterium - E_Intramacronucleata)) + (B_Defluviitaleaceae - (B_bacterium_enrichment_culture_clone_22_2013 * -0.42916533))) * 0.022189086) + (E_Corallinophycidae * -0.25449282)))
)


# ===== SR_score ===== depth9_loss_1
input$SR_score <- with(input,
                       (((((B_Desulfobulbaceae * 0.014800672) + -0.25695455) * E_Corallinophycidae) + 0.81182295) + (((B_uncultured_Aminicenantes_bacterium - E_Intramacronucleata) * (E_Diatomea + -10.908489)) * ((((B_bacterium_enrichment_culture_clone_22_2013 + E_Corallinophycidae) + (B_Defluviitaleaceae * 1.3861086)) * -0.00014761486) + 0.0057203313)))
)


# ===== SEMモデル =====
model_final <- '
  Seagrass ~ SR_score
  B_Desulfobulbaceae ~ Seagrass
'

############################################################
# ライブラリ
############################################################
library(lavaan)
library(caret)   # createFolds
library(pROC)    # auc

############################################################
# 1. クロスバリデーション関数
############################################################
run_cv <- function(df, score_var, model_final, k_folds = 4){
  
  # フォールド分割
  folds <- createFolds(df$Seagrass, k = k_folds)
  
  auc_vec   <- numeric(k_folds)
  brier_vec <- numeric(k_folds)
  
  for(i in seq_len(k_folds)){
    # -----------------------
    # 訓練・テスト分割
    # -----------------------
    train_data <- df[-folds[[i]], ]
    test_data  <- df[ folds[[i]], ]
    
    # -----------------------
    # SR_score を動的に割り当て & 標準化
    # -----------------------
    train_data$SR_score <- scale(train_data[[score_var]])
    # テストデータも同じ中心・スケールを使用
    test_data$SR_score <- scale(
      test_data[[score_var]],
      center = attr(train_data$SR_score, "scaled:center"),
      scale  = attr(train_data$SR_score, "scaled:scale")
    )
    
    # -----------------------
    # SEM 推定
    # -----------------------
    fit_cv <- sem(
      model_final,
      data      = train_data,
      estimator = "WLSMV",
      ordered   = "Seagrass"
    )
    
    coef_df <- parameterEstimates(fit_cv)
    
    # -----------------------
    # 線形予測（probitスケール）
    # -----------------------
    intercept <- coef_df$est[coef_df$lhs=="Seagrass" & coef_df$op=="~1"]
    b_SR      <- coef_df$est[coef_df$lhs=="Seagrass" & coef_df$rhs=="SR_score"]
    
    eta   <- intercept + b_SR * test_data$SR_score
    p_hat <- pnorm(eta)  # 0〜1 の確率
    
    # -----------------------
    # 評価指標
    # -----------------------
    y_true <- ifelse(test_data$Seagrass == 0, 0, 1)  # 明示的に0/1に変換
    auc_vec[i]   <- auc(y_true, p_hat)
    brier_vec[i] <- mean((y_true - p_hat)^2)
  }
  
  # -----------------------
  # 結果まとめ
  # -----------------------
  list(
    cv_results = data.frame(Fold = 1:k_folds, AUC = auc_vec, Brier = brier_vec),
    summary = data.frame(
      mean_AUC   = mean(auc_vec),
      sd_AUC     = sd(auc_vec),
      min_AUC    = min(auc_vec),
      max_AUC    = max(auc_vec),
      mean_Brier = mean(brier_vec),
      sd_Brier   = sd(brier_vec),
      min_Brier  = min(brier_vec),
      max_Brier  = max(brier_vec)
    )
  )
}

############################################################
# 2. 実行例（4-fold と 8-fold）
############################################################
# input: データフレーム（Seagrass 列と SR_score 列を含む）
# model_final: lavaan 形式の SEM モデル

cv_4fold <- run_cv(input, "SR_score", model_final, k_folds = 4)
cv_8fold <- run_cv(input, "SR_score", model_final, k_folds = 8)

# 結果確認
cv_4fold$cv_results
cv_4fold$summary

cv_8fold$cv_results
cv_8fold$summary


############################################################
# 6. CSV出力
############################################################

if(!dir.exists("results")) dir.create("results")

# 4-fold
write.csv(cv_4fold$cv_results, "results/CV_folds_SR_score_4fold.csv", row.names = FALSE)
write.csv(cv_4fold$summary,   "results/CV_summary_SR_score_4fold.csv", row.names = FALSE)

# 8-fold
write.csv(cv_8fold$cv_results, "results/CV_folds_SR_score_8fold.csv", row.names = FALSE)
write.csv(cv_8fold$summary,   "results/CV_summary_SR_score_8fold.csv", row.names = FALSE)

cat("CV結果（4-fold & 8-fold）が results/ フォルダに出力\n")


# SEM 推定（WLSMV, Seagrass は二値なので ordered 指定）
fit_final <- sem(model_final, data=input, estimator="WLSMV", ordered="Seagrass")

# 結果確認
summary(fit_final, standardized=TRUE, fit.measures=TRUE)

# 指標
fitMeasures(fit_final)

dir.create("./SEM_result_non_lin", showWarnings = TRUE, recursive = FALSE, mode = "0777")

#SEM fit
#if(!dir.exists("SEM_result_non_lin")) dir.create("SEM_result_non_lin")

res.l10=fit_final
model_final=res.l10

p0_0=input$SR_score
sink('./SEM_result_non_lin/lavaanstaticsmodel.l10_model.txt', append = TRUE)
print (p0_0)
sink()

p0=model_final
sink('./SEM_result_non_lin/lavaanstaticsmodel.l10.txt', append = TRUE)
print (p0)
sink()

p1=summary(fit_final, standardized=TRUE)
sink('./SEM_result_non_lin/lavaanstaticssummary.txt', append = TRUE)
print (p1)
sink()

p2=fitMeasures(fit_final)
sink('./SEM_result_non_lin/lavaanstaticsfitMeasures.txt', append = TRUE)
print (p2)
sink()

# bootstrap based on ML
input$Seagrass <- as.numeric(as.character(input$Seagrass))

createModel_SR <- function() {
  return('
    # 
    Seagrass ~ SR_score
    B_Desulfobulbaceae ~ Seagrass
  ')
}

model_SR <- createModel_SR()

res.l12 <- lavaan(model_SR, data = input, auto.var = TRUE,se="bootstrap",bootstrap=1000)
summary(res.l12, fit.measure=TRUE,　standardized = TRUE)
P4=summary(res.l12, fit.measure=TRUE,　standardized = TRUE)
fitMeasures(res.l12)

sink('./SEM_result_non_lin/lavaanstaticsmodel.lbootres12.txt', append = TRUE)
print (P4)
sink()

# fitMeasures
fm <- fitMeasures(res.l12)

# 結果をファイルに出力
sink('./SEM_result_non_lin/lavaanstaticsfitMeasures_lbootres12.txt', append = TRUE)
print(fm)
sink()


# モデル式地域特性用
model_region_all <- '
  Seagrass ~ SR_score
  B_Desulfobulbaceae ~ Seagrass
'

# group に列名を指定
fit_region <- sem(model_region_all,
                  data = input,
                  group = "Region",  # ← 
                  estimator = "WLSMV",
                  ordered = "Seagrass")


# SEM 推定（WLSMV, Seagrass は二値なので ordered 指定）
fit_final_all <- sem(model_region_all, data=input, estimator="WLSMV", ordered="Seagrass",missing = "pairwise")
fit_final_all

# 結果確認
summary(fit_final_all, standardized=TRUE, fit.measures=TRUE)
fitMeasures(fit_final_all)

library(dplyr)
input %>% group_by(Region) %>% summarize(mean_SR = mean(SR_score))

summary(fit_final_all, standardized=TRUE)


# group に列名を指定
fit <- sem(model_region_all,
           data = input,
           group = "Region",  # ←
           estimator = "WLSMV",
           ordered = "Seagrass")

p_region_fit=fit
sink('./SEM_result_non_lin_region/lavaanstaticsfitMeasures_region_fit.txt', append = TRUE)
print (p_region_fit)
sink()

summary(fit, standardized=TRUE)

p_region_fit_summary=summary(fit, standardized=TRUE)
sink('./SEM_result_non_lin_region/lavaanstaticsfitMeasures_region_fit_summary_A_D.txt', append = TRUE)
print (p_region_fit_summary)
sink()





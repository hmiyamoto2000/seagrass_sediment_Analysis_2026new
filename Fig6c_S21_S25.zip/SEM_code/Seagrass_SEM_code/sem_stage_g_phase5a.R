#!/usr/bin/env Rscript
# Stage gamma Phase 5a: ML re-fit of all qualified models for AIC/BIC ranking
# - Input: phase4_qualified_models.csv (12,745 models that passed Phase 2 criteria)
# - Estimator: ML (Seagrass treated as continuous; ordered= dropped)
# - Purpose: AIC/BIC ranking for parsimony-based pre-screening
# - Output: phase5a_ml_aic_bic.csv (one row per model)
# - Note: ML here is a SELECTION TOOL only; final fits in Phase 5c use WLSMV
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT     <- "/Fig6"
DATA_IN  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
Q_CSV    <- file.path(ROOT, "phase4_qualified_models.csv")
OUT_DIR  <- file.path(ROOT, "phase5a_chunks")
dir.create(OUT_DIR, showWarnings = FALSE)
SUMMARY  <- file.path(ROOT, "phase5a_ml_aic_bic.csv")

dat <- read_csv(DATA_IN, show_col_types = FALSE)
qual <- read_csv(Q_CSV, show_col_types = FALSE) %>%
  select(sr1, sr2, k, downset)
cat(sprintf("[Phase5a] Loaded: %d models, data %d rows\n", nrow(qual), nrow(dat)))

fit_one_ml <- function(sr1, sr2, downset_str) {
  d <- dat
  d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  downs <- strsplit(downset_str, split = "|", fixed = TRUE)[[1]]
  rhs <- paste(downs, collapse = " + ")
  mod <- sprintf("Seagrass ~ .SR1 + .SR2\n%s ~ Seagrass", rhs)
  res <- tryCatch({
    fit <- suppressWarnings(lavaan::sem(mod, data = d,
                                        estimator = "ML", se = "standard"))
    if (!isTRUE(lavaan::lavInspect(fit, "converged")))
      return(tibble(converged = FALSE))
    fm <- lavaan::fitMeasures(fit, c("aic","bic","chisq","df","pvalue",
                                     "cfi","tli","rmsea","srmr","logl","npar"))
    tibble(converged = TRUE,
           aic = unname(fm["aic"]), bic = unname(fm["bic"]),
           logl = unname(fm["logl"]), npar = unname(fm["npar"]),
           ml_chisq = unname(fm["chisq"]), ml_df = unname(fm["df"]),
           ml_pvalue = unname(fm["pvalue"]),
           ml_cfi = unname(fm["cfi"]), ml_tli = unname(fm["tli"]),
           ml_rmsea = unname(fm["rmsea"]), ml_srmr = unname(fm["srmr"]))
  }, error = function(e) tibble(converged = FALSE))
  res$sr1 <- sr1; res$sr2 <- sr2; res$downset <- downset_str
  res
}

plan(multisession, workers = 24)

CHUNK <- 500   # rows per chunk -> ~26 chunks
chunks <- split(seq_len(nrow(qual)), ceiling(seq_len(nrow(qual)) / CHUNK))
cat(sprintf("[Phase5a] %d chunks of up to %d models each\n",
            length(chunks), CHUNK))

t0 <- Sys.time()
for (ci in seq_along(chunks)) {
  out_path <- file.path(OUT_DIR, sprintf("phase5a_chunk_%03d.csv", ci))
  if (file.exists(out_path)) {
    cat(sprintf("[chunk %3d/%d] skip (exists)\n", ci, length(chunks))); next
  }
  rows_ci <- chunks[[ci]]
  res <- future_map_dfr(rows_ci, function(i) {
    fit_one_ml(qual$sr1[i], qual$sr2[i], qual$downset[i])
  }, .options = furrr_options(seed = TRUE), .progress = TRUE)
  write_csv(res, out_path)
  el <- as.numeric(Sys.time() - t0, units = "mins")
  pct <- ci / length(chunks) * 100
  cat(sprintf("[chunk %3d/%d] %d models, elapsed %.1f min, %.1f%% done\n",
              ci, length(chunks), nrow(res), el, pct))
}

cat("[Phase5a] Combining chunks...\n")
all_files <- list.files(OUT_DIR, pattern = "^phase5a_chunk_.*\\.csv$",
                        full.names = TRUE)
combined <- map_dfr(all_files, ~ read_csv(.x, show_col_types = FALSE))
write_csv(combined, SUMMARY)
cat(sprintf("[Phase5a] Wrote -> %s (%d rows)\n", SUMMARY, nrow(combined)))

cat(sprintf("[Phase5a] Total time: %.1f min\n",
            as.numeric(Sys.time() - t0, units = "mins")))
cat(sprintf("[Phase5a] ML converged: %d / %d (%.1f%%)\n",
            sum(combined$converged, na.rm = TRUE), nrow(combined),
            100 * sum(combined$converged, na.rm = TRUE) / nrow(combined)))

ok <- combined %>% filter(converged == TRUE)
cat("\n[Phase5a] Top 20 by AIC (lower = better):\n")
print(ok %>% arrange(aic) %>% slice_head(n = 20) %>%
      select(sr1, sr2, npar, aic, bic, ml_pvalue, ml_cfi, ml_srmr, downset),
      n = 20, width = Inf)

cat("\n[Phase5a] Top 20 by BIC (lower = better):\n")
print(ok %>% arrange(bic) %>% slice_head(n = 20) %>%
      select(sr1, sr2, npar, aic, bic, ml_pvalue, ml_cfi, ml_srmr, downset),
      n = 20, width = Inf)

cat("\n=== Phase 5a complete ===\n")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 使用例:
# python3.10 Causal_learning_Fisherz_final.py data_file.csv

import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

from causallearn.search.ConstraintBased.PC import pc
from scipy.stats import shapiro, anderson

# ----------------------------
# Utility functions
# ----------------------------
def detect_discrete_columns(df, threshold=5):
    return [col for col in df.columns if df[col].nunique() <= threshold]

def save_tikz(graph: nx.DiGraph, var_names, filepath):
    """
    TikZ形式で因果グラフを出力（距離依存 bend 自動調整）
    """
    lines = []
    lines.append(
        "\\begin{tikzpicture}[->,>=Stealth, thick, "
        "main node/.style={circle,draw,fill=yellow!20, "
        "font=\\sffamily\\bfseries, minimum size=1cm, inner sep=2pt}]"
    )

    # spring_layoutでノード配置
    pos = nx.spring_layout(graph, seed=42, k=1.2, iterations=200)

    xs = np.array([pos[node][0] for node in var_names])
    ys = np.array([pos[node][1] for node in var_names])

    x_min, x_max = xs.min(), xs.max()
    xs_scaled = 10 * (xs - x_min) / (x_max - x_min) if x_max != x_min else np.zeros_like(xs)

    y_min, y_max = ys.min(), ys.max()
    ys_scaled = -10 * (ys - y_min) / (y_max - y_min) if y_max != y_min else np.zeros_like(ys)

    # ノード定義
    for i, v in enumerate(var_names):
        lines.append(
            f"\\node[main node] ({v}) at ({xs_scaled[i]:.2f},{ys_scaled[i]:.2f}) {{{v}}};"
        )

    # エッジ定義（距離依存 bend）
    for source, target in graph.edges():
        dx = pos[target][0] - pos[source][0]
        dy = pos[target][1] - pos[source][1]
        dist = np.sqrt(dx**2 + dy**2)
        bend = max(15, min(45, 40/dist))  # 距離が近いほど曲げを大きく
        lines.append(f"\\path[->, bend left={bend:.1f}] ({source}) edge ({target});")

    lines.append("\\end{tikzpicture}")

    with open(filepath, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"TikZコードを保存: {filepath}")


# ----------------------------
# Main analysis
# ----------------------------
def main(csv_path):
    print(f"\nCSVファイルを読み込み: {csv_path}")
    data = pd.read_csv(csv_path)

    n_samples, n_vars = data.shape

    original_var_names = data.columns.tolist()
    var_names = [f"X{i+1}" for i in range(n_vars)]
    data.columns = var_names

    base_name = os.path.splitext(os.path.basename(csv_path))[0]
    output_dir = "causal_DAGs_X_Robust"
    os.makedirs(output_dir, exist_ok=True)

    # 変数マッピング保存
    mapping_df = pd.DataFrame({
        "NewName": var_names,
        "OriginalName": original_var_names
    })
    mapping_df.to_csv(os.path.join(output_dir, f"{base_name}_variable_mapping.csv"), index=False)
    data.to_csv(os.path.join(output_dir, f"{base_name}_X.csv"), index=False)

    # ----------------------------
    # Discrete / continuous check
    # ----------------------------
    discrete_cols = detect_discrete_columns(data, threshold=5)
    continuous_cols = [c for c in var_names if c not in discrete_cols]

    # ----------------------------
    # Normality diagnostics
    # ----------------------------
    shapiro_pvals = []
    ad_stats = []
    ad_crit_5 = []
    ad_flags = []

    for col in continuous_cols:
        sh_stat, sh_p = shapiro(data[col])
        ad_res = anderson(data[col], dist="norm")
        ad_stat = ad_res.statistic
        crit_5 = ad_res.critical_values[list(ad_res.significance_level).index(5.0)]
        ad_flag = ad_stat > crit_5

        shapiro_pvals.append(sh_p)
        ad_stats.append(ad_stat)
        ad_crit_5.append(crit_5)
        ad_flags.append(ad_flag)

    if continuous_cols:
        normality_df = pd.DataFrame({
            "Variable": continuous_cols,
            "Shapiro_p": shapiro_pvals,
            "Anderson_A2": ad_stats,
            "Anderson_crit_5pct": ad_crit_5,
            "Anderson_non_normal": ad_flags
        })
        normality_path = os.path.join(output_dir, f"{base_name}_normality_diagnostics.csv")
        normality_df.to_csv(normality_path, index=False)
        print(f"正規性診断結果を保存: {normality_path}")

    # ----------------------------
    # Independence test selection
    # ----------------------------
    indep_test = "chisq" if discrete_cols else "fisherz"

    # ----------------------------
    # PC algorithm
    # ----------------------------
    print("\nPCアルゴリズムを実行中...")
    cg = pc(data.values, alpha=0.05, indep_test_method=indep_test)
    G = cg.G
    nodes = list(G.get_nodes())

    nx_graph = nx.DiGraph()
    nx_graph.add_nodes_from(var_names)

    for i, n1 in enumerate(nodes):
        for j, n2 in enumerate(nodes):
            if i != j and G.get_edge(n1, n2) is not None:
                nx_graph.add_edge(var_names[i], var_names[j])

    # ----------------------------
    # Matplotlib描画（矢印改善）
    # ----------------------------
    import matplotlib as mpl
    mpl.rcParams["font.family"] = "Helvetica"

    print("因果グラフを描画し保存...")
    pos = nx.spring_layout(nx_graph, seed=42, k=1.2, iterations=200)
    plt.figure(figsize=(10,10))
    nx.draw(
        nx_graph, pos, with_labels=True,
        node_color="gold", node_size=700,
        font_size=10, arrows=True, arrowsize=10
    )
    plt.title("Causal DAG (PC Algorithm)", fontsize=12)
    plt.tight_layout()

    pdf_path = os.path.join(output_dir, f"{base_name}_X_causal_DAG.pdf")
    png_path = os.path.join(output_dir, f"{base_name}_X_causal_DAG.png")
    plt.savefig(pdf_path, dpi=300)
    plt.savefig(png_path, dpi=300)
    print(f"グラフを保存: {pdf_path}")
    print(f"グラフを保存: {png_path}")
    plt.show()

    # ----------------------------
    # TikZ出力
    # ----------------------------
    tikz_path = os.path.join(output_dir, f"{base_name}_causal_DAG.tex")
    save_tikz(nx_graph, var_names, tikz_path)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("使い方: python3.10 causal_analysis_X_with_tikz.py データファイル.csv")
        sys.exit(1)

    main(sys.argv[1])

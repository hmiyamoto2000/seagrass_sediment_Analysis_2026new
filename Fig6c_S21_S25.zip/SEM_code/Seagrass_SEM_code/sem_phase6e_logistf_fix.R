suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr)
  library(logistf); library(furrr); library(future)
})

ROOT <- "/Fig6"
dat <- read_csv(file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv"), show_col_types=FALSE)
dat$Region <- factor(dat$Region)
pool <- read_csv(file.path(ROOT, "phase7_universal_candidates.csv"), show_col_types=FALSE) %>%
  select(sr1, sr2, downset)

# 既存 Phase 6e の値も保持して join するため列を分ける
get_region_p <- function(sr_col_name) {
  d <- dat
  d$.X <- d[[sr_col_name]]
  fit <- tryCatch(logistf::logistf(Seagrass ~ .X * Region, data=d),
                  error=function(e) NULL)
  if (is.null(fit)) return(c(B=NA_real_, C=NA_real_, D=NA_real_))
  p <- fit$prob
  c(B = unname(p[".X:RegionB"]),
    C = unname(p[".X:RegionC"]),
    D = unname(p[".X:RegionD"]))
}

# 各 SR をユニークに 1 回だけ計算(SR1 と SR2 を分けてキャッシュ)
unique_sr <- unique(c(pool$sr1, pool$sr2))
cat(sprintf("Unique SR variables: %d\n", length(unique_sr)))

plan(multisession, workers=24)
sr_pvals <- future_map(unique_sr, get_region_p,
                       .options=furrr_options(seed=TRUE))
names(sr_pvals) <- unique_sr

# モデル単位で結果を組み立て
res <- pool %>% rowwise() %>%
  mutate(
    sr1_regB_p = sr_pvals[[sr1]]["B"],
    sr1_regC_p = sr_pvals[[sr1]]["C"],
    sr1_regD_p = sr_pvals[[sr1]]["D"],
    sr2_regB_p = sr_pvals[[sr2]]["B"],
    sr2_regC_p = sr_pvals[[sr2]]["C"],
    sr2_regD_p = sr_pvals[[sr2]]["D"]
  ) %>% ungroup()

write_csv(res, file.path(ROOT, "phase6e_logistf_region.csv"))
cat(sprintf("Wrote phase6e_logistf_region.csv (%d rows)\n", nrow(res)))

cat("\n=== Per-SR Region p-values (interaction tests) ===\n")
sr_summary <- tibble(
  sr_var = unique_sr,
  regB_p = sapply(sr_pvals, function(x) x["B"]),
  regC_p = sapply(sr_pvals, function(x) x["C"]),
  regD_p = sapply(sr_pvals, function(x) x["D"])
)
print(sr_summary, n=20)

cat("\n=== Aggregate over 697 universal models ===\n")
for (sr in c("sr1","sr2")) {
  for (r in c("B","C","D")) {
    col <- paste0(sr, "_reg", r, "_p")
    v <- res[[col]]
    cat(sprintf("  %s: median=%.3f, %% NS (>=0.05)=%.1f\n",
        col, median(v, na.rm=TRUE), 100*mean(v >= 0.05, na.rm=TRUE)))
  }
}

# 既存 Phase 6e CSV を更新(Region 部分のみ置換)
old <- read_csv(file.path(ROOT, "phase6e_full_validation.csv"), show_col_types=FALSE) %>%
  select(-sr1_regB_p, -sr1_regC_p, -sr1_regD_p, -sr2_regB_p, -sr2_regC_p, -sr2_regD_p)
new <- old %>% left_join(res, by=c("sr1","sr2","downset"))
write_csv(new, file.path(ROOT, "phase6e_full_validation_v2.csv"))
cat("\nUpdated -> phase6e_full_validation_v2.csv\n")

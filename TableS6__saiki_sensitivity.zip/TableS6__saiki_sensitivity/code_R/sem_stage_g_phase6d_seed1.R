#!/usr/bin/env Rscript
# Phase 6d: Universality verification via lmPerm (Seagrass:Region interaction test)
# For each model in pool, test each downstream variable's Region universality
#
# PORTABLE VERSION: paths are resolved automatically from the folder that
# contains THIS script, so it runs on any machine / any user.
# Place this script with its data CSV and its condition-specific pool
#   (balanced_seed01.csv + phase5c_full_fit_seed1.csv) in one folder and run:
#     Rscript <this_script>.R
# Input pool and all outputs are condition-named, so the four conditions
# can coexist in a single folder without name clashes.
# (optionally:  Rscript <this_script>.R  /path/to/data.csv  /path/to/pool.csv )

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lmPerm); library(furrr); library(future)
})

# ---- portable path resolution -------------------------------------------
get_script_dir <- function() {
  # 1) Rscript:   --file=/path/to/script.R
  a <- commandArgs(trailingOnly = FALSE)
  f <- grep("^--file=", a, value = TRUE)
  if (length(f)) return(dirname(normalizePath(sub("^--file=", "", f[1]))))
  # 2) source("script.R") in an R session
  if (!is.null(sys.frames()[[1]]$ofile))
    return(dirname(normalizePath(sys.frames()[[1]]$ofile)))
  # 3) fallback: current working directory
  normalizePath(getwd())
}
ROOT <- get_script_dir()

# optional command-line overrides: arg1 = data csv, arg2 = pool csv
cli <- commandArgs(trailingOnly = TRUE)

DATA_NAME <- "balanced_seed01.csv"
POOL_NAME <- "phase5c_full_fit_seed1.csv"

DATA_IN <- if (length(cli) >= 1 && nzchar(cli[1])) cli[1] else file.path(ROOT, DATA_NAME)
POOL_IN <- if (length(cli) >= 2 && nzchar(cli[2])) cli[2] else file.path(ROOT, POOL_NAME)
OUT_DIR <- file.path(ROOT, "phase6d_chunks_seed1")
dir.create(OUT_DIR, showWarnings = FALSE)
SUMMARY <- file.path(ROOT, "phase6d_universality_seed1.csv")

if (!file.exists(DATA_IN)) stop(sprintf("DATA_IN not found: %s", DATA_IN))
if (!file.exists(POOL_IN)) stop(sprintf("POOL_IN not found: %s", POOL_IN))
cat(sprintf("[Phase6d] ROOT    = %s\n", ROOT))
cat(sprintf("[Phase6d] DATA_IN = %s\n", DATA_IN))
cat(sprintf("[Phase6d] POOL_IN = %s\n", POOL_IN))

dat <- read_csv(DATA_IN, show_col_types=FALSE)
dat$Region <- factor(dat$Region)
pool <- read_csv(POOL_IN, show_col_types=FALSE) %>%
  filter(converged, gfi>=0.95, agfi>=0.90, wrmr<=1.0)
cat(sprintf("[Phase6d] Pool: %d models, Data: %d rows\n", nrow(pool), nrow(dat)))

# Get all unique (model, downstream_var) pairs
expand_jobs <- function(pool) {
  map_dfr(seq_len(nrow(pool)), function(i) {
    vars <- strsplit(pool$downset[i], split="|", fixed=TRUE)[[1]]
    tibble(model_idx=i, sr1=pool$sr1[i], sr2=pool$sr2[i],
           downset=pool$downset[i], variable=vars)
  })
}

cat("[Phase6d] Expanding model x variable jobs...\n")
jobs <- expand_jobs(pool)
cat(sprintf("[Phase6d] Total tests: %d\n", nrow(jobs)))

# Pre-compute unique variable Region universality (cache)
unique_vars <- unique(jobs$variable)
cat(sprintf("[Phase6d] Unique variables to test: %d\n", length(unique_vars)))

test_var <- function(v, dat, nperm=999) {
  if (sd(dat[[v]], na.rm=TRUE) == 0) {
    return(tibble(variable=v, main_p=NA, region_p=NA, interaction_p=NA,
                  note="zero-sd overall"))
  }
  reg_sd <- dat %>% group_by(Region) %>% summarise(s=sd(.data[[v]], na.rm=TRUE), .groups="drop")
  has_zero_region <- any(reg_sd$s == 0 | is.na(reg_sd$s))

  res <- tryCatch({
    f <- as.formula(sprintf("%s ~ Seagrass * Region", v))
    m <- summary(aovp(f, data=dat, perm="Prob", Ca=0.01,
                     maxIter=nperm, seqs=FALSE))[[1]]
    rownames(m) <- trimws(rownames(m))
    g <- function(nm) {
      if (nm %in% rownames(m)) m[nm, "Pr(Prob)"]
      else NA
    }
    tibble(variable=v,
           main_p     = g("Seagrass"),
           region_p   = g("Region"),
           interaction_p = g("Seagrass:Region"),
           note = ifelse(has_zero_region, "some Region has zero-sd", ""))
  }, error=function(e) tibble(variable=v, main_p=NA, region_p=NA,
                              interaction_p=NA, note=paste("error:", conditionMessage(e))))
  res
}

plan(multisession, workers=24)
cat("[Phase6d] Computing universality for unique variables (24 workers)...\n")
t0 <- Sys.time()
var_results <- future_map_dfr(unique_vars, ~ test_var(.x, dat),
                              .options=furrr_options(seed=TRUE),
                              .progress=TRUE)
cat(sprintf("[Phase6d] Variable-level tests done in %.2f min\n",
            as.numeric(Sys.time()-t0, units="mins")))

# Join back to full job table to get per-model x per-variable results
jobs_with_p <- jobs %>% left_join(var_results, by="variable")

# Per-model summary: how many downstream are Universal (interaction p >= 0.05)
model_summary <- jobs_with_p %>%
  group_by(sr1, sr2, downset) %>%
  summarise(k = n(),
            n_universal      = sum(interaction_p >= 0.05, na.rm=TRUE),
            n_nonuniversal   = sum(interaction_p < 0.05,  na.rm=TRUE),
            n_NA             = sum(is.na(interaction_p)),
            min_interaction_p = suppressWarnings(min(interaction_p, na.rm=TRUE)),
            .groups="drop")

write_csv(jobs_with_p, file.path(ROOT, "phase6d_per_variable_seed1.csv"))
write_csv(model_summary, SUMMARY)
cat(sprintf("[Phase6d] Wrote -> %s (%d models)\n", SUMMARY, nrow(model_summary)))
cat(sprintf("[Phase6d] Wrote -> phase6d_per_variable_seed1.csv (%d rows)\n", nrow(jobs_with_p)))

cat("\n[Phase6d] Universality distribution (per-model):\n")
print(model_summary %>%
      mutate(all_universal = (n_universal == k)) %>%
      count(all_universal))

cat(sprintf("\n[Phase6d] Total time: %.2f min\n",
            as.numeric(Sys.time()-t0, units="mins")))
cat("\n=== Phase 6d complete ===\n")

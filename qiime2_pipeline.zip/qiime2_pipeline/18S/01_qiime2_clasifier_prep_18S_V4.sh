#! /bin/sh


#####18S Euk454F/Euk964Rペアのデータベース準備#####
### home directoryの下に「software」directoryを作成し、その中にSILVA release 132（以下URLからダウンロード）のQIIME用データベースを置く
### https://www.arb-silva.de/no_cache/download/archive/qiime/


#Command
conda activate qiime2-2021.4


#18Sデータベース配列のインプット
qiime tools import \
  --type 'FeatureData[Sequence]' \
  --input-path ~/software/SILVA_132_QIIME_release/rep_set/rep_set_18S_only/99/silva_132_99_18S.fna \
  --output-path ~/software/SILVA_132_QIIME_release/rep_set/rep_set_18S_only/99/silva_132_99_18S.qza
  
#タクソン情報のインプット
qiime tools import \
  --type 'FeatureData[Taxonomy]' \
  --input-format HeaderlessTSVTaxonomyFormat \
  --input-path ~/software/SILVA_132_QIIME_release/taxonomy/18S_only/99/taxonomy_all_levels.txt \
  --output-path ~/software/SILVA_132_QIIME_release/taxonomy/18S_only/99/taxonomy_all_levels.qza

#Euk454F/Euk964RペアによるPCR領域の切り出し（Euk454F, Euk964R）
#FW (Euk454F (Read1 side)) : CCAGCASCYGCGGTAATTCC
#RV (Euk964R (Read2 side)) : ACTTTCGTTCTTGATYRA

qiime feature-classifier extract-reads \
  --i-sequences ~/software/SILVA_132_QIIME_release/rep_set/rep_set_18S_only/99/silva_132_99_18S.qza \
  --p-f-primer CCAGCASCYGCGGTAATTCC\
  --p-r-primer ACTTTCGTTCTTGATYRA \
  --o-reads ~/software/SILVA_132_QIIME_release/rep_set/rep_set_18S_only/99/99_otus_18S_amplicon_Euk454FEuk964R.qza

#実際のターゲット配列検出に対する最適化による検出用データ「Classifier」の作成（長いのでバックグラウンドでやる）
qiime feature-classifier fit-classifier-naive-bayes \
  --i-reference-reads ~/software/SILVA_132_QIIME_release/rep_set/rep_set_18S_only/99/99_otus_18S_amplicon_Euk454FEuk964R.qza \
  --i-reference-taxonomy ~/software/SILVA_132_QIIME_release/taxonomy/18S_only/99/taxonomy_all_levels.qza \
  --o-classifier ~/software/SILVA_132_QIIME_release/taxonomy/18S_only/99/classifier_Euk454FEuk964R_all.qza

#ここで出来たEuk454F/Euk964Rペア専用の「classifier_Euk454FEuk964R.qza」を使用してタクソンの同定を行う




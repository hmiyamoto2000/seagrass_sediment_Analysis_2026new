#python plot_ordination.py NMDS_scores.csv NMDS1 NMDS2
#python plot_ordination.py PCA_sites.csv PC1 PC2
#python plot_ordination.py dbRDA_sites.csv CAP1 CAP2

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Ellipse
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
import numpy as np

# -----------------------------
# 引数
# -----------------------------
if len(sys.argv) != 4:
    print("Usage: python plot_ordination.py <input.csv> <axis1> <axis2>")
    sys.exit(1)

input_csv = sys.argv[1]
axis1 = sys.argv[2]
axis2 = sys.argv[3]

output_dir = "ordination_output"
os.makedirs(output_dir, exist_ok=True)

# -----------------------------
# データ
# -----------------------------
df = pd.read_csv(input_csv)

required = {"name", axis1, axis2, "cnd", "env"}
if not required.issubset(df.columns):
    print(f"CSV must contain columns: {required}")
    sys.exit(1)

df["group"] = df["env"]

# -----------------------------
# 楕円関数
# -----------------------------
def draw_ellipse(position, covariance, ax, color, alpha=0.25):

    U, s, Vt = np.linalg.svd(covariance)

    orient = np.arctan2(U[1, 0], U[0, 0]) * 180 / np.pi
    width, height = 2 * np.sqrt(s)

    ellipse = Ellipse(
        position,
        width,
        height,
        angle=orient,
        facecolor=color,
        edgecolor='black',
        alpha=alpha,
        linewidth=1,
        zorder=3
    )

    ax.add_patch(ellipse)

# -----------------------------
# 図設定
# -----------------------------
sns.set(style="whitegrid")
plt.rcParams["font.family"] = "Helvetica"

# -----------------------------
# envカラー
# -----------------------------
unique_env = sorted(df['env'].dropna().unique())

palette = sns.color_palette("Set2", len(unique_env))

color_dict = dict(zip(unique_env, palette))

# -----------------------------
# cndマーカー
# -----------------------------
marker_dict = {
    "seagrass": "o",
    "non": "s"
}

# -----------------------------
# 描画
# -----------------------------
plt.figure(figsize=(8,6))

ax = plt.gca()

for env_val in unique_env:

    subset = df[df['env'] == env_val]

    base_color = color_dict[env_val]

    for _, row in subset.iterrows():

        marker = marker_dict.get(str(row['cnd']).lower(), "o")

        ax.scatter(
            row[axis1],
            row[axis2],
            color=base_color,
            edgecolor="black",
            s=100,
            marker=marker,
            linewidth=1,
            zorder=2
        )

    if len(subset) >= 3:

        cov = np.cov(subset[[axis1, axis2]].values.T)

        mean = subset[[axis1, axis2]].mean().values

        draw_ellipse(mean, cov, ax, color=base_color)

# -----------------------------
# 軸ラベル
# -----------------------------
plt.xlabel(axis1)
plt.ylabel(axis2)

title = os.path.basename(input_csv).replace(".csv","")

plt.title(title)

# -----------------------------
# 凡例
# -----------------------------
handles_env = [
    mpatches.Patch(color=color_dict[e], label=e)
    for e in unique_env
]

legend_env = ax.legend(
    handles=handles_env,
    title="Region",
    bbox_to_anchor=(1.05,1),
    loc="upper left"
)

handles_cnd = [
    mlines.Line2D([],[],
    marker=marker_dict[k],
    color="black",
    markerfacecolor="white",
    linestyle="None",
    markersize=8,
    label=k)
    for k in marker_dict
]

ax.add_artist(legend_env)

ax.legend(
    handles=handles_cnd,
    title="Habitat",
    bbox_to_anchor=(1.05,0.5),
    loc="upper left"
)

plt.subplots_adjust(right=0.75)

# -----------------------------
# 保存
# -----------------------------
outfile = os.path.join(output_dir, title)

plt.savefig(outfile + ".pdf", dpi=300)
plt.savefig(outfile + ".png", dpi=300)

plt.close()

print("Figure saved:", outfile)

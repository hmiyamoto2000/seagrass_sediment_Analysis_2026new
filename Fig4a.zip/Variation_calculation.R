############################################################
# R: Variation Partitioning + CSV出力
############################################################
#
# Usage:
#   Rscript Variation_calculation.R Bacteria
#   Rscript Variation_calculation.R Eukaryota
#
############################################################

library(vegan)

############################################################
# 0 コマンドライン引数
############################################################
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  target <- "Bacteria"
  cat("No argument given. Defaulting to:", target, "\n")
} else {
  target <- args[1]
}

bac_file <- paste0(target, "_diversity_sample.csv")

if (!file.exists(bac_file)) {
  stop(paste("File not found:", bac_file))
}

output_dir <- paste0("output_", target)
dir.create(output_dir, showWarnings = FALSE, recursive = TRUE)

cat("=== Variation Partitioning for:", target, "===\n")

############################################################
# 1 データ読み込み
############################################################
bac  <- read.csv(bac_file)
chem <- read.csv("Chemical_seagrass_sample.csv")
meta <- read.csv("List.csv")

bac_mat  <- as.matrix(bac[, 2:ncol(bac)])
chem_mat <- chem[, 2:ncol(chem)]

############################################################
# 2 欠損値補完（中央値）
############################################################
for (i in 1:ncol(chem_mat)) {
  chem_mat[is.na(chem_mat[, i]), i] <- median(chem_mat[, i], na.rm = TRUE)
}

############################################################
# 3 rare taxa filtering & relative abundance
############################################################
# PCA_dbRDA スクリプトと同一の前処理を適用
bac_filt <- bac_mat[, colSums(bac_mat > 0) >= 3]
bac_rel  <- decostand(bac_filt, method = "total")

############################################################
# 4 VIF後の化学変数
############################################################
chem_scaled <- scale(chem_mat)
chem_df <- as.data.frame(chem_scaled)
mod <- capscale(bac_rel ~ ., data = chem_df, distance = "bray")

vif_step <- function(mod, chem_df) {
  v <- vif.cca(mod)
  while (max(v) > 10) {
    remove_var <- names(which.max(v))
    cat("Removing (VIF):", remove_var, "\n")
    terms_keep <- attr(terms(mod), "term.labels")
    terms_keep <- terms_keep[terms_keep != remove_var]
    new_formula <- as.formula(paste("bac_rel ~", paste(terms_keep, collapse = "+")))
    mod <- capscale(new_formula, data = chem_df, distance = "bray")
    v <- vif.cca(mod)
  }
  return(mod)
}

dbrda_final <- vif_step(mod, chem_df)

# VIF後の化学変数
vars_final <- attr(terms(dbrda_final), "term.labels")
chem_final <- chem_df[, vars_final, drop = FALSE]

cat("Variables retained after VIF:", paste(vars_final, collapse = ", "), "\n")

############################################################
# 5 Variation Partitioning
############################################################
region  <- meta["env"]
habitat <- meta["cnd"]

vp <- varpart(bac_rel, region, habitat, chem_final)
print(vp)

############################################################
# 6 Python用CSV出力
############################################################
indfract <- vp$part$indfract
shared   <- vp$part$shared
residual <- vp$part$tot$unexplained

# Adjusted R² を使用
if ("Adj.R.square" %in% colnames(indfract)) {
  ind_vals <- indfract[, "Adj.R.square"]
} else if ("Adj.R.squared" %in% colnames(indfract)) {
  ind_vals <- indfract[, "Adj.R.squared"]
} else {
  ind_vals <- indfract[, ncol(indfract)]
}

if ("Adj.R.square" %in% colnames(shared)) {
  sh_vals <- shared[, "Adj.R.square"]
} else if ("Adj.R.squared" %in% colnames(shared)) {
  sh_vals <- shared[, "Adj.R.squared"]
} else {
  sh_vals <- shared[, ncol(shared)]
}

vp_values <- data.frame(
  fraction = c("Region", "Habitat", "Chemistry",
               "Region:Habitat", "Region:Chemistry", "Habitat:Chemistry",
               "Region:Habitat:Chemistry", "Residual"),
  "variance.Adj.R.square" = c(
    ind_vals[1], ind_vals[2], ind_vals[3],
    sh_vals[1], sh_vals[2], sh_vals[3],
    ifelse(length(sh_vals) > 3, sh_vals[4], 0),
    residual
  ),
  check.names = FALSE
)

write.csv(vp_values, file.path(output_dir, "vp_variance.csv"), row.names = FALSE)

cat("Variation partitioning CSV saved:", file.path(output_dir, "vp_variance.csv"), "\n")

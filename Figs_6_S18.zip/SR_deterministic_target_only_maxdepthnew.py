#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#brew install julia 
#conda activate pysr310
#pip install --upgrade pip
#pip install pysr pandas numpy

#source /Users/h_studio/opt/anaconda3/bin/activate
#conda activate pysr310

#戻す時

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import pandas as pd
from pysr import PySRRegressor

def main():

    if len(sys.argv) != 2:
        print("Usage: python sr_seagrass_deterministic.py data.csv")
        sys.exit(1)

    csv_file = sys.argv[1]
    df = pd.read_csv(csv_file)

    # 列名のスペースを_に置換
    df.columns = [c.replace(" ", "_") for c in df.columns]

    if "target" not in df.columns:
        print("Error: CSV must contain a 'target' column")
        sys.exit(1)

    # =========================
    # Prepare data
    # =========================
    X = df.drop(columns=["target"])
    y = df["target"]

    # =========================
    # Symbolic Regression model (deterministic)
    # =========================
    model = PySRRegressor(
        niterations=200,
        population_size=100,
        binary_operators=["+", "-", "*"],
        unary_operators=[],
        maxdepth=5,
        elementwise_loss="(x, y) -> (x - y)^2",  # 新しいLoss指定
        parallelism="serial",  # 再現性のためシリアル実行
        deterministic=True,    # 完全再現性を確保
        model_selection="best",
        verbosity=1,
        random_state=42,       # これで同じ結果が得られる
    )

    # =========================
    # Fit model
    # =========================
    model.fit(X, y)

    # =========================
    # Output results
    # =========================
    print("\n===================================")
    print("Best symbolic equation")
    print("===================================")
    print(model.get_best())

    print("\n===================================")
    print("All discovered equations")
    print("===================================")
    print(model)

if __name__ == "__main__":
    main()

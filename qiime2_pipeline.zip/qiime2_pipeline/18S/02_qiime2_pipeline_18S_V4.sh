#! /bin/sh




#####Qiime2によるプロセス#####
### MiSeqのアウトプットをこのスクリプトを置いたディレクトリ上に置いた「reads」ディレクトリに置く
### このスクリプトを置いたディレクトリ上にカレントディレクトリを移動して実行


#Command
conda activate qiime2-2021.4


### Sequence import
qiime tools import \
  --type 'SampleData[PairedEndSequencesWithQuality]' \
  --input-path ./reads \
  --input-format CasavaOneEightSingleLanePerSampleDirFmt \
  --output-path ./demux-paired-end.qza


### Denoise, marge the reads and statistic counting ###
# Use dada2 for remove 18S PCR primer then marge paired reads
# Low quarity seq truncation setting is Zero
# Table that created in this step is counting data

#Primerの除去
#FW (Euk454F (Read1 side)) : CCAGCASCYGCGGTAATTCC (comp.seq.: GGAATTACCGCYGSTGCTGG )
##RV (Euk964R (Read2 side)) : ACTTTCGTTCTTGATYRA (comp.seq.: TRYATCAAGAACGAAAGT)
#--p-adapter-f : Read1の3'末のアダプタ配列（この場合Euk964Rの相補鎖...突き抜け対策）。それ以降の配列も除去される
#--p-front-f : Read1の5'末のアダプタ配列（この場合Euk454F）。それ以前の配列も除去される
#--p-adapter-r : Read2の3'末のアダプタ配列（この場合Euk454Fの相補鎖...突き抜け対策）。それ以降の配列も除去される
#--p-front-r :  Read2の5'末のアダプタ配列（この場合Euk964R）。それ以前の配列も除去される
qiime cutadapt trim-paired \
--i-demultiplexed-sequences ./demux-paired-end.qza \
--p-adapter-f TRYATCAAGAACGAAAGT \
--p-front-f CCAGCASCYGCGGTAATTCC \
--p-adapter-r GGAATTACCGCYGSTGCTGG \
--p-front-r ACTTTCGTTCTTGATYRA \
--o-trimmed-sequences ./cutadapt-paired-end.qza

#品質管理（無し）とマージ
qiime dada2 denoise-paired \
--i-demultiplexed-seqs ./cutadapt-paired-end.qza \
--p-trunc-len-f 0 \
--p-trunc-len-r 0 \
--o-representative-sequences ./rep-seqs.qza \
--o-table ./table.qza \
--o-denoising-stats ./stats.qza

###ここまでの結果の可視化
#処理の統計を可読テーブルにする
qiime metadata tabulate \
  --m-input-file ./stats.qza \
  --o-visualization ./stats.qzv

# 品質評価などの結果の可視化
qiime feature-table summarize \
  --i-table ./table.qza \
  --o-visualization ./table.qzv \
  --m-sample-metadata-file ./sample-metadata.tsv

#結果表の表示
qiime feature-table tabulate-seqs \
  --i-data ./rep-seqs.qza \
  --o-visualization ./rep-seqs.qzv


### 種の同定と定量値の計算 ###
# 以下のdenoiseし結合したrep-seq配列に対して行う
# ./rep-seqs.qza


###Classifierを用いた同定
qiime feature-classifier classify-sklearn \
  --i-classifier ~/software/SILVA_132_QIIME_release/taxonomy/18S_only/99/classifier_Euk454FEuk964R_all.qza \
  --i-reads ./rep-seqs.qza \
  --o-classification ./taxonomy_rev.qza

###メタデータに対応したLCAでの種情報の表作成
qiime metadata tabulate \
  --m-input-file ./taxonomy_rev.qza \
  --o-visualization ./taxonomy_rev.qzv
 
###バープロットの作成・各taxonレベルでのカウントデータの作成
qiime taxa barplot \
  --i-table ./table.qza \
  --i-taxonomy ./taxonomy_rev.qza \
  --m-metadata-file ./sample-metadata.tsv \
  --o-visualization ./taxa-bar-plots.qzv

###加工
# トータルで１０カウント以下のfeatureをフィルタリング
qiime feature-table filter-features \
--i-table ./table.qza \
--p-min-frequency 10 \
--o-filtered-table ./filtered_table10.qza

#ミトコンとクロロプラスとのエントリーを除去
qiime taxa filter-table \
--i-table ./filtered_table10.qza \
--i-taxonomy ./taxonomy_rev.qza \
--p-exclude mitochondria,chloroplast \
--o-filtered-table ./filtered_table.qza

# 品質評価などの結果の可視化
qiime feature-table summarize \
  --i-table ./filtered_table.qza \
  --m-sample-metadata-file ./sample-metadata.tsv \
  --o-visualization ./filtered_table.qzv &

#結果表の表示
qiime feature-table tabulate-seqs \
  --i-data ./rep-seqs.qza \
  --o-visualization ./filtered_rep-seqs.qzv &
  
#メタデータに対応したLCAでの種情報の表作成
qiime metadata tabulate \
  --m-input-file ./taxonomy_rev.qza \
  --o-visualization ./taxonomy_rev.qzv &

#バープロットの作成・各taxonレベルでのカウントデータの作成
qiime taxa barplot \
  --i-table ./filtered_table.qza \
  --i-taxonomy ./taxonomy_rev.qza \
  --m-metadata-file ./sample-metadata.tsv \
  --o-visualization ./filtered_taxa-bar-plots_rev.qzv &

#「https://view.qiime2.org/」でxxx.pzvを可視化出来る



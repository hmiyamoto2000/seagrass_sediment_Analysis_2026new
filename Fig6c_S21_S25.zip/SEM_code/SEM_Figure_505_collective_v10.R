library(DiagrammeR); library(DiagrammeRsvg); library(rsvg)
library(readr); library(dplyr)

down <- read_csv("phase9_downstream_path_summary_strict505.csv", show_col_types=FALSE)
TOTAL <- 505
down$pct <- round(100 * down$n_models / TOTAL, 1)

edge_color <- function(b, sig_pct) {
  if (is.na(sig_pct) || sig_pct == 0) return("grey50")
  if (b >= 0) return("forestgreen"); return("firebrick")
}
edge_style <- function(sig_pct) {
  if (is.na(sig_pct) || sig_pct == 0) return("dashed"); return("solid")
}
penwidth <- function(pct) {
  w <- (pct/100) * 6; pmin(pmax(w, 0.6), 6)
}

# ── ABC order ──
all_vars <- list(
  B_Defluviitaleaceae      = "B_Dflv",
  B_Desulfobulbaceae       = "B_Dslf",
  B_Hyphomonadaceae        = "B_Hyph",
  B_uncultured_Aminicenantes_bacterium = "B_Amini",
  B_bacterium_enrichment_culture_clone_22_2013 = "B_bct22",
  E_Corallinophycidae      = "E_Cral",
  E_Diatomea               = "E_Diat",
  E_Intramacronucleata     = "E_Intra",
  chemical_CaO_log         = "CaO",
  chemical_CEC_log         = "CEC",
  chemical_NO3_N_log       = "NO3-N",
  chemical_P2O5_log        = "P2O5"
)

ids_all <- c(
  setNames(c("BDflv","BDslf","BHyph","BAmini","Bbct22"), names(all_vars)[1:5]),
  setNames("ECral", names(all_vars)[6]),
  setNames(c("EDiat","EIntra"), names(all_vars)[7:8]),
  setNames(c("CaO","CEC","NO3","P2O5"), names(all_vars)[9:12])
)

build_node <- function(varname, dispname) {
  row <- down[down$lhs == varname, ]
  if (nrow(row) == 0) return(NULL)
  fill <- if (row$std_median > 0 && row$p_sig_pct > 50) "#A8D5A8" else
          if (row$std_median < 0 && row$p_sig_pct > 50) "#F5A8A8" else "#E5E5E5"
  lbl <- sprintf("%s\\nfreq: %.0f%%", dispname, row$pct)
  sprintf("%s [label='%s' shape=ellipse style=filled fillcolor='%s']",
          ids_all[[varname]], lbl, fill)
}

all_nodes <- na.omit(unlist(lapply(names(all_vars), function(v) build_node(v, all_vars[[v]]))))

# ── Edges: median std coefficient (number only) ──
sr_med <- list(SR1=0.282, SR2=0.811)
edges <- c(
  sprintf("SR2 -> Seagrass [label='%+.2f' fontsize=11 fontcolor='forestgreen' color='forestgreen' penwidth=6.0]",
          sr_med$SR2),
  sprintf("SR1 -> Seagrass [label='%+.2f' fontsize=11 fontcolor='forestgreen' color='forestgreen' penwidth=6.0]",
          sr_med$SR1))

for (v in names(ids_all)) {
  row <- down[down$lhs == v, ]
  if (nrow(row) == 0) next
  edges <- c(edges,
    sprintf("Seagrass -> %s [label='%+.2f' fontsize=9 fontcolor='%s' color='%s' penwidth=%.2f style='%s']",
            ids_all[[v]], row$std_median,
            edge_color(row$std_median, row$p_sig_pct),
            edge_color(row$std_median, row$p_sig_pct),
            penwidth(row$pct), edge_style(row$p_sig_pct)))
}

# ── v5 stable layout, ranksep=1.0 ──
top_order <- paste(ids_all, collapse=" ")
rank_top  <- sprintf("{rank=same; %s}", top_order)
rank_mid  <- "{rank=same; Seagrass}"
rank_bot  <- "{rank=same; SR2 SR1}"

dot <- sprintf("
digraph SEM_505 {
rankdir=TB
ranksep=1.0
nodesep=0.4
splines=true
node [fontname=Helvetica fontsize=11]
edge [fontname=Helvetica]

%s

Seagrass [label='Seagrass' shape=box style=filled fillcolor='#C6E0B4' fontsize=20 width=2 height=1]
SR2 [label='SR2 (biome)' shape=ellipse style=filled fillcolor='#FFB347']
SR1 [label='SR1 (chem)' shape=ellipse style=filled fillcolor='#FFF2CC']

%s
%s
%s

SR2 -> SR1 [style=invis]

%s
}",
paste(all_nodes, collapse="\n"),
rank_top, rank_mid, rank_bot,
paste(edges, collapse="\n"))

p <- grViz(dot)
export_svg(p) |> charToRaw() |> rsvg_png("SEM_505_collective_v10.png", width=3200, height=2200)
export_svg(p) |> charToRaw() |> rsvg_pdf("SEM_505_collective_v10.pdf", width=16, height=11)
cat("Saved SEM_505_collective_v10.png and .pdf\n")
cat("505 strict models (TLI>=0.95, AGFI>=0.95)\n")
cat("Edge labels: median standardized coefficient\n")
cat("Node labels: inclusion frequency (freq: XX%)\n")

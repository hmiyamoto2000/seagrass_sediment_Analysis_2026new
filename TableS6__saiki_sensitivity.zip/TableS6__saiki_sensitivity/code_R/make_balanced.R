#!/usr/bin/env Rscript
# 均衡化リサンプリング: Saiki(X8) と Noto(X2) を seagrass6/non6 に間引く
# 他6サイトは元のまま 6/6 → 全8サイト均衡、計96行、各海域24標本
# コマンドライン引数で seed を指定: Rscript make_balanced.R 1
suppressPackageStartupMessages({ library(readr) })

args <- commandArgs(trailingOnly = TRUE)
SEED <- if (length(args) >= 1) as.integer(args[1]) else 1
set.seed(SEED)

d <- read_csv("New_seagrass_CLR_region_site_Chem_with_SR.csv", show_col_types = FALSE)

# Saiki = X8 を 6/6 に
saiki_sg  <- which(d$Site == "X8" & d$Seagrass == 1)  # 24
saiki_non <- which(d$Site == "X8" & d$Seagrass == 0)  # 12
keep_saiki <- c(sample(saiki_sg, 6), sample(saiki_non, 6))

# Noto = X2 を 6/6 に
noto_sg  <- which(d$Site == "X2" & d$Seagrass == 1)   # 12
noto_non <- which(d$Site == "X2" & d$Seagrass == 0)   # 12
keep_noto <- c(sample(noto_sg, 6), sample(noto_non, 6))

# 他サイトは全部残す
others <- which(!d$Site %in% c("X8", "X2"))

keep <- sort(c(others, keep_saiki, keep_noto))
db <- d[keep, ]

out <- sprintf("balanced_seed%02d.csv", SEED)
write_csv(db, out)
# ============================================================
# LightGBM ネイティブ SHAP + Gain 複数グラフ出力
# ============================================================

dir.create("./Result_AA_RF_XG", showWarnings = FALSE, recursive = TRUE)

library(lightgbm)
library(data.table)
library(ggplot2)

# ------------------------------------------------------------
# 1. データ読み込み
# ------------------------------------------------------------
dt <- fread("MBA_selected_MLrawsのコピー.csv")

# 目的変数 0/1
y <- as.integer(dt$Species)
stopifnot(length(unique(y)) == 2)

# 説明変数
X_df <- dt[, !"Species", with = FALSE]
X_df <- X_df[, lapply(.SD, as.numeric)]
X_mat <- as.matrix(X_df)

# ------------------------------------------------------------
# 2. LightGBM データセット
# ------------------------------------------------------------
dtrain <- lgb.Dataset(X_mat, label = y)

# ------------------------------------------------------------
# 3. LightGBM パラメータ
# ------------------------------------------------------------
params <- list(
  objective = "binary",
  metric = "binary_logloss",
  learning_rate = 0.1,
  num_leaves = 15,
  min_data_in_leaf = 1
)

# ------------------------------------------------------------
# 4. CV → best_iter
# ------------------------------------------------------------
set.seed(123)
cv_lgb <- lgb.cv(
  params = params,
  data = dtrain,
  nrounds = 200,
  nfold = 3,
  early_stopping_rounds = 10,
  verbose = -1
)
best_iter <- cv_lgb$best_iter
cat("LightGBM best_iter =", best_iter, "\n")

# ------------------------------------------------------------
# 5. LightGBM モデル訓練
# ------------------------------------------------------------
model <- lgb.train(
  params = params,
  data = dtrain,
  nrounds = best_iter
)

# ------------------------------------------------------------
# 6. ネイティブ SHAP 計算
# ------------------------------------------------------------
shap_mat <- predict(model, X_mat, type = "contrib")

# bias 列（最後の列）を削除
shap_dt <- as.data.table(shap_mat[, -ncol(shap_mat)])
setnames(shap_dt, colnames(X_df))

# 長い形式に変換
shap_long <- melt(shap_dt, measure.vars = colnames(shap_dt),
                  variable.name = "Feature", value.name = "phi")

# 特徴量ごとの平均絶対値
shap_summary <- shap_long[, .(Importance = mean(abs(phi))), by = Feature]
shap_summary[, Type := "SHAP"]

# ------------------------------------------------------------
# 7. LightGBM Gain
# ------------------------------------------------------------
gain_summary <- lgb.importance(model, percentage = TRUE)[, .(Feature, Gain)]
gain_summary[, Importance := Gain]
gain_summary[, Type := "Gain"]
gain_summary <- gain_summary[, .(Feature, Importance, Type)]

# ------------------------------------------------------------
# 8. 両方結合（long format）
# ------------------------------------------------------------
importance_all <- rbind(gain_summary, shap_summary)

# ------------------------------------------------------------
# 9. CSV 出力
# ------------------------------------------------------------
fwrite(shap_summary[, .(Feature, SHAP = Importance)], "./Result_AA_RF_XG/SHAP_importance_mean_abs.csv")
fwrite(gain_summary[, .(Feature, Gain = Importance)], "./Result_AA_RF_XG/LightGBM_importance_gain.csv")
fwrite(importance_all, "./Result_AA_RF_XG/FeatureImportance_LongFormat.csv")

# ------------------------------------------------------------
# 10. グラフ作成
# ------------------------------------------------------------

# Gain のみ
p_gain <- ggplot(gain_summary, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "skyblue") +
  coord_flip() +
  labs(title = "LightGBM Feature Importance (Gain)", x = "Feature", y = "Gain") +
  theme_minimal() +
  theme(axis.line = element_line(color = "black"),
        axis.ticks = element_line(color = "black"),
        panel.grid = element_blank())
ggsave("./Result_AA_RF_XG/LightGBM_Gain_only.png", p_gain, width = 9, height = 7, dpi = 300)

# SHAP のみ
p_shap <- ggplot(shap_summary, aes(x = reorder(Feature, Importance), y = Importance)) +
  geom_bar(stat = "identity", fill = "darkorange") +
  coord_flip() +
  labs(title = "LightGBM Feature Importance (SHAP)", x = "Feature", y = "Mean Absolute SHAP") +
  theme_minimal() +
  theme(axis.line = element_line(color = "black"),
        axis.ticks = element_line(color = "black"),
        panel.grid = element_blank())
ggsave("./Result_AA_RF_XG/LightGBM_SHAP_only.png", p_shap, width = 9, height = 7, dpi = 300)

# Gain vs SHAP
p_both <- ggplot(importance_all, aes(x = reorder(Feature, Importance), y = Importance, fill = Type)) +
  geom_bar(stat = "identity", position = position_dodge(width = 0.8)) +
  coord_flip() +
  scale_x_discrete(expand = c(0,0)) +
  scale_y_continuous(expand = c(0,0)) +
  labs(title = "Feature Importance: Gain vs SHAP", x = "Feature", y = "Importance") +
  scale_fill_manual(values = c("Gain" = "skyblue", "SHAP" = "darkorange")) +
  theme_minimal() +
  theme(axis.line.x = element_line(color = "black", size = 0.8),
        axis.line.y = element_line(color = "black", size = 0.8),
        axis.ticks = element_line(color = "black", size = 0.8),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())
ggsave("./Result_AA_RF_XG/LightGBM_Gain_vs_SHAP.png", p_both, width = 10, height = 8, dpi = 300)

cat("\n=== グラフ出力完了: Gain, SHAP, Gain vs SHAP ===\n")


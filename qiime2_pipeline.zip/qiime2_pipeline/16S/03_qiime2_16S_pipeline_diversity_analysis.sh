#! /bin/sh




#####Qiime2によるプロセス#####
#データのあるディレクトリで実行する


# Activate command
conda activate qiime2-2021.4


conda activate qiime2-2022.11

#QIIME2にかける前に、古細菌や哺乳類を取り除く

qiime taxa filter-table \
--i-table filtered_table.qza \
--i-taxonomy taxonomy_rev.qza \
--p-exclude Archaea,Mammalia \
--o-filtered-table filtered_table2.qza


### Phylogenetic analysis
qiime phylogeny align-to-tree-mafft-fasttree \
--i-sequences rep-seqs.qza \
--o-alignment aligned-rep-seqs.qza \
--o-masked-alignment masked-aligned-rep-seqs.qza \
--o-tree unrooted-tree.qza \
--o-rooted-tree rooted-tree.qza \
--p-n-threads auto


### Diversity analysis
qiime diversity core-metrics-phylogenetic \
--i-phylogeny rooted-tree.qza \
--i-table filtered_table2.qza \
--p-sampling-depth 5000 \
--m-metadata-file sample-metadata.tsv \
--output-dir core-metrics-results
####paramater : --p-sampling-depth 最小のリード数@table.qzvに設定###


##### alpha #####

#Alpha diversity: observed features
qiime diversity alpha-group-significance \
--i-alpha-diversity core-metrics-results/observed_features_vector.qza \
--m-metadata-file sample-metadata.tsv \
--o-visualization alpha_obs_feat-farming_type-significance.qzv

#Alpha diversity: shannon index
qiime diversity alpha-group-significance \
--i-alpha-diversity core-metrics-results/shannon_vector.qza \
--m-metadata-file sample-metadata.tsv \
--o-visualization alpha_shannon-farming_type-significance.qzv

#Alpha diversity: faith pd
qiime diversity alpha-group-significance \
--i-alpha-diversity core-metrics-results/faith_pd_vector.qza \
--m-metadata-file sample-metadata.tsv \
--o-visualization alpha_faith-pd-farming_type-significance.qzv

#Alpha diversity: evenness
qiime diversity alpha-group-significance \
--i-alpha-diversity core-metrics-results/evenness_vector.qza \
--m-metadata-file sample-metadata.tsv \
--o-visualization alpha_evenness-farming_type-significance.qzv


#Alpha diversity: chao1
qiime diversity alpha   \
--i-table filtered_table2.qza  \
--p-metric 'chao1' \
--o-alpha-diversity core-metrics-results/chao1_vector.qza

#通常はchao1は以下らしい
qiime feature-table rarefy \
--i-table filtered_table2.qza \
--p-sampling-depth 5000 \
--o-rarefied-table rarefied_table.qza

qiime diversity alpha \
--i-table rarefied_table.qza \
--p-metric chao1 \
--o-alpha-diversity chao1_vector.qza


#Alpha diversity: simpson
qiime diversity alpha   \
--i-table filtered_table2.qza  \
--p-metric 'simpson' \
--o-alpha-diversity core-metrics-results/simpson_vector.qza

#Simpsonも以下らしい
qiime feature-table rarefy \
  --i-table filtered_table2.qza \
  --p-sampling-depth 5000 \
  --o-rarefied-table rarefied_table.qza

qiime diversity alpha \
  --i-table rarefied_table.qza \
  --p-metric simpson \
  --o-alpha-diversity simpson_vector.qza

qiime diversity alpha-group-significance \
  --i-alpha-diversity simpson_vector.qza \
  --m-metadata-file sample-metadata.tsv \
  --o-visualization alpha_simpson-significance.qzv

qiime diversity alpha-rarefaction \
  --i-table filtered_table2.qza \
  --i-phylogeny rooted-tree.qza \
  --p-max-depth 5000 \
  --m-metadata-file sample-metadata.tsv \
  --o-visualization alpha-rarefaction.qzv

qiime feature-table rarefy \
  --i-table filtered_table2.qza \
  --p-sampling-depth 5000 \
  --o-rarefied-table rarefied_table.qza

qiime diversity alpha \
  --i-table rarefied_table.qza \
  --p-metric simpson_e \
  --o-alpha-diversity core-metrics-results/simpson_e_vector.qza

qiime diversity alpha \
  --i-table rarefied_table.qza \
  --p-metric simpson \
  --o-alpha-diversity simpson_vector.qza

qiime feature-table rarefy \
  --i-table filtered_table2.qza \
  --p-sampling-depth 5000 \
  --o-rarefied-table rarefied_table.qza


qiime diversity alpha-rarefaction \
  --i-table filtered_table2.qza \
  --i-phylogeny rooted-tree.qza \
  --p-max-depth 5000 \
  --m-metadata-file sample-metadata.tsv \
  --o-visualization alpha-rarefaction.qzv


#以下はなくても良い
qiime diversity alpha-rarefaction \
--i-table filtered_table2.qza \
--i-phylogeny rooted-tree.qza \
--p-metrics 'pielou_e' \
--p-max-depth 5000 \
--m-metadata-file sample-metadata.tsv \
--o-visualization alpha-rarefaction_pielou_e.qzv

####paramater : --p-max-depthはリード数のmedian@table.qzvに設定###


# エクセルでまとめて表示
#cdでcore-metrics-resultに入る。
#stats.qzvをqiime2viewで表示してmetadataをダウンロードしてこのフォルダに入れておく

qiime metadata tabulate \
--m-input-file metadata.tsv \
--m-input-file faith_pd_vector.qza \
--m-input-file shannon_vector.qza \
--m-input-file observed_features_vector.qza \
--m-input-file evenness_vector.qza \
--m-input-file chao1_vector.qza \
--m-input-file simpson_vector.qza \
--o-visualization metadata-combined-adiv.qzv



https://qiita.com/kohei-108/items/1ea384c2ac04015d1580




#「https://view.qiime2.org/」でxxx.pzvを可視化出来る





##### beta Diversity_1 #####
#Beta-diversity：unweighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_1 \
--o-visualization beta_unweighted-unifrac-Diversity_1-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：weighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_1 \
--o-visualization beta_weighted_unifrac-Diversity_1-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：bray_curtis
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_1 \
--o-visualization beta_bray_curtis-Diversity_1-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：jaccard
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_1 \
--o-visualization beta_jaccard-Diversity_1-significance.qzv \
--p-pairwise
--p-permutations 5000


##### beta Diversity_2 #####
#Beta-diversity：unweighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_2 \
--o-visualization beta_unweighted-unifrac-Diversity_2-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：weighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_2 \
--o-visualization beta_weighted_unifrac-Diversity_2-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：bray_curtis
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_2 \
--o-visualization beta_bray_curtis-Diversity_2-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：jaccard
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_2 \
--o-visualization beta_jaccard-Diversity_2-significance.qzv \
--p-pairwise
--p-permutations 5000



##### beta Diversity_3 #####
#Beta-diversity：unweighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_3 \
--o-visualization beta_unweighted-unifrac-Diversity_3-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：weighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_3 \
--o-visualization beta_weighted_unifrac-Diversity_3-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：bray_curtis
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_3 \
--o-visualization beta_bray_curtis-Diversity_3-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：jaccard
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Diversity_3 \
--o-visualization beta_jaccard-Diversity_3-significance.qzv \
--p-pairwise
--p-permutations 5000

#####beta diversity修正
##### beta Diversity_1 #####
# Beta-diversity: unweighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_1 \
  --o-visualization beta_unweighted-unifrac-Diversity_1-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: weighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_1 \
  --o-visualization beta_weighted_unifrac-Diversity_1-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: bray_curtis
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_1 \
  --o-visualization beta_bray_curtis-Diversity_1-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: jaccard
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_1 \
  --o-visualization beta_jaccard-Diversity_1-significance.qzv \
  --p-pairwise \
  --p-permutations 5000


##### beta Diversity_2 #####
# Beta-diversity: unweighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_2 \
  --o-visualization beta_unweighted-unifrac-Diversity_2-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: weighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_2 \
  --o-visualization beta_weighted_unifrac-Diversity_2-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: bray_curtis
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_2 \
  --o-visualization beta_bray_curtis-Diversity_2-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: jaccard
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_2 \
  --o-visualization beta_jaccard-Diversity_2-significance.qzv \
  --p-pairwise \
  --p-permutations 5000


##### beta Diversity_3 #####
# Beta-diversity: unweighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_3 \
  --o-visualization beta_unweighted-unifrac-Diversity_3-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: weighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_3 \
  --o-visualization beta_weighted_unifrac-Diversity_3-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: bray_curtis
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_3 \
  --o-visualization beta_bray_curtis-Diversity_3-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: jaccard
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Diversity_3 \
  --o-visualization beta_jaccard-Diversity_3-significance.qzv \
  --p-pairwise \
  --p-permutations 5000


##### beta Remarks #####
# Beta-diversity: unweighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Remarks \
  --o-visualization beta_unweighted-unifrac-Remarks-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: weighted_unifrac
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Remarks \
  --o-visualization beta_weighted_unifrac-Remarks-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: bray_curtis
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Remarks \
  --o-visualization beta_bray_curtis-Remarks-significance.qzv \
  --p-pairwise \
  --p-permutations 5000

# Beta-diversity: jaccard
qiime diversity beta-group-significance \
  --i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
  --m-metadata-file sample-metadata.tsv \
  --m-metadata-column Remarks \
  --o-visualization beta_jaccard-Remarks-significance.qzv \
  --p-pairwise \
  --p-permutations 5000







##### beta Remarks #####以前のもの
#Beta-diversity：unweighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/unweighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Remarks \
--o-visualization beta_unweighted-unifrac-Remarks-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：weighted_unifrac
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/weighted_unifrac_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Remarks \
--o-visualization beta_weighted_unifrac-Remarks-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：bray_curtis
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/bray_curtis_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Remarks \
--o-visualization beta_bray_curtis-Remarks-significance.qzv \
--p-pairwise
--p-permutations 5000

#Beta-diversity：jaccard
qiime diversity beta-group-significance \
--i-distance-matrix core-metrics-results/jaccard_distance_matrix.qza \
--m-metadata-file sample-metadata.tsv \
--m-metadata-column Remarks \
--o-visualization beta_jaccard-Remarks-significance.qzv \
--p-pairwise
--p-permutations 5000



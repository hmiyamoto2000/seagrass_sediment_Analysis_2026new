# =====================================
# CODA-LASSO for Countdata
# =====================================

# install.packages("coda4microbiome")
# install.packages("glmnet")

# Bioconductor経由でインストール
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
BiocManager::install("ComplexHeatmap")

# 必要パッケージ
library(coda4microbiome)
library(glmnet)

# -------------------------------
# 1. データ読み込み
# -------------------------------
# 重複行名の問題を避けるため row.names は指定しない
data <- read.csv("Input_count_data.csv", header = TRUE, check.names = FALSE)

# データ確認
str(data)
dim(data)
head(data)

# -------------------------------
# 2. Outcome (Y)
# -------------------------------
# "Seagrass"列をアウトカムとして抽出
Y <- data$Seagrass

# 二値アウトカムとして factor に変換
Y <- factor(Y, levels = c(0, 1), labels = c("non_seagrass", "seagrass"))

table(Y)

# -------------------------------
# 3. CLR microbiome data (X)
# -------------------------------
# アウトカム列を除外
X <- data[, colnames(data) != "Seagrass"]

# 行列化
X <- as.matrix(X)

# 安全チェック
stopifnot(is.numeric(X))
stopifnot(all(is.finite(X)))

dim(X)

# -------------------------------
# 4. CODA-LASSO 実行
# -------------------------------
set.seed(123)

# family 引数は不要
fit <- coda_glmnet(
  x = X,
  y = Y,
  alpha = 1,      # LASSO
  nfolds = 10     # クロスバリデーション
)

# -------------------------------
# 5. 選択された log-contrast 係数
# -------------------------------
coefs <- fit$`log-contrast coefficients`
taxa  <- fit$taxa.name

result <- data.frame(
  taxon = taxa,
  log_contrast_coef = as.numeric(coefs),
  row.names = NULL
)

# 非ゼロ係数のみ抽出
result_selected <- subset(result, log_contrast_coef != 0)

# 絶対値で降順に並び替え
result_selected <- result_selected[order(abs(result_selected$log_contrast_coef), decreasing = TRUE), ]

# 確認
print(result_selected)

# -------------------------------
# 6. CSV保存
# -------------------------------
write.csv(result_selected, file = "coda_lasso_selected_taxa.csv", row.names = FALSE)


#!/usr/bin/env Rscript
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
})

ROOT      <- "/Fig6"
DATA_IN   <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem.csv")
DATA_OUT  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
EQ_OUT    <- file.path(ROOT, "phase0_sr_equations.csv")
DIAG_OUT  <- file.path(ROOT, "phase0_sr_diagnostics.csv")
CHEM_DIR  <- file.path(ROOT, "depths/chemical_depth")
BIOME_DIR <- file.path(ROOT, "depths/biome_depth")

TARGET_COMPLEXITIES <- c(27L, 29L)
cat("=== Stage gamma Phase 0 ===\n")
cat("Time:", format(Sys.time()), "\n\n")

read_hof <- function(path, family, depth) {
  if (!file.exists(path)) { warning("Missing: ", path); return(tibble()) }
  readr::read_csv(path, show_col_types = FALSE,
    col_types = cols(Complexity = col_integer(), Loss = col_double(), Equation = col_character())) %>%
    filter(Complexity %in% TARGET_COMPLEXITIES) %>%
    transmute(family = family, depth = depth, complexity = Complexity, loss = Loss, eq_str = Equation)
}

chem_files <- tibble(depth = 5:10,
  path = file.path(CHEM_DIR, sprintf("hall_of_fame_depth%d.csv", 5:10)), family = "chem")
biome_files <- tibble(depth = 5:10,
  path = file.path(BIOME_DIR, sprintf("hall_of_fame_%ddepth.csv", 5:10)), family = "biome")

eq_tbl <- bind_rows(
  pmap_dfr(chem_files, function(depth, path, family) read_hof(path, family, depth)),
  pmap_dfr(biome_files, function(depth, path, family) read_hof(path, family, depth))
) %>%
  mutate(sr_id = sprintf("SR_%s_d%d_c%d", family, depth, complexity)) %>%
  select(sr_id, family, depth, complexity, loss, eq_str) %>%
  arrange(family, depth, complexity)

cat(sprintf("[Phase0] Extracted %d equations (chem=%d, biome=%d)\n",
    nrow(eq_tbl), sum(eq_tbl$family=="chem"), sum(eq_tbl$family=="biome")))
if (nrow(eq_tbl) != 23L) {
  cat("[Phase0] WARNING: expected 23, got ", nrow(eq_tbl), "\n", sep="")
  print(eq_tbl %>% count(family, depth, complexity))
}
write_csv(eq_tbl, EQ_OUT)
cat("[Phase0] Wrote equations -> ", EQ_OUT, "\n", sep="")

forbidden_pat <- "(?i)\\b(square|cube|safe_log|safe_sqrt|log|exp|sin|cos|tan|sqrt|abs|pow|max|min)\\b|\\^"
bad <- str_detect(eq_tbl$eq_str, forbidden_pat)
if (any(bad)) { print(eq_tbl[bad, c("sr_id","eq_str")]); stop("Unsupported tokens") }
cat("[Phase0] Operator safety check passed\n")

dat <- read_csv(DATA_IN, show_col_types = FALSE)
cat(sprintf("[Phase0] Loaded data: %d rows x %d cols\n", nrow(dat), ncol(dat)))

required_cols <- c("Seagrass",
  "chemical_TC_log","chemical_TN_log","chemical_NH4_N_log","chemical_NO3_N_log",
  "chemical_P2O5_log","chemical_CaO_log","chemical_K2O_log","chemical_CEC_log","chemical_Zn_log",
  "B_Desulfobulbaceae","B_Hyphomonadaceae","B_Defluviitaleaceae","B_BD7_8",
  "B_bacterium_enrichment_culture_clone_22_2013","B_uncultured_Aminicenantes_bacterium",
  "E_Corallinophycidae","E_Intramacronucleata","E_Diatomea")
missing_cols <- setdiff(required_cols, names(dat))
if (length(missing_cols) > 0) stop("Missing columns: ", paste(missing_cols, collapse=", "))
cat("[Phase0] All 19 required columns present\n")

eval_eq <- function(eq_str, df) {
  out <- eval(parse(text = eq_str), envir = df)
  as.numeric(out)
}

cat("[Phase0] Evaluating ", nrow(eq_tbl), " equations...\n", sep="")
sr_mat <- map(eq_tbl$eq_str, function(es) {
  tryCatch(eval_eq(es, dat), error = function(e) {
    cat("  ERROR: ", conditionMessage(e), "\n", sep="")
    rep(NA_real_, nrow(dat))
  })
})
names(sr_mat) <- eq_tbl$sr_id
sr_df <- as_tibble(sr_mat)
cat("[Phase0] Built ", ncol(sr_df), " SR columns\n", sep="")

diag_tbl <- tibble(
  sr_id = eq_tbl$sr_id, family = eq_tbl$family, depth = eq_tbl$depth,
  complexity = eq_tbl$complexity, loss_pysr = eq_tbl$loss,
  n_NA = map_int(sr_mat, ~ sum(is.na(.x))),
  n_Inf = map_int(sr_mat, ~ sum(is.infinite(.x))),
  sd_val = map_dbl(sr_mat, ~ sd(.x, na.rm=TRUE)),
  min_val = map_dbl(sr_mat, ~ suppressWarnings(min(.x, na.rm=TRUE))),
  max_val = map_dbl(sr_mat, ~ suppressWarnings(max(.x, na.rm=TRUE))),
  cor_seagrass = map_dbl(sr_mat, ~ suppressWarnings(cor(.x, dat$Seagrass, use="pairwise.complete.obs")))
)
write_csv(diag_tbl, DIAG_OUT)
cat("\n[Phase0] Diagnostics summary:\n")
print(diag_tbl %>% select(sr_id, n_NA, n_Inf, sd_val, cor_seagrass), n=30)

flag <- diag_tbl$sd_val==0 | is.na(diag_tbl$sd_val) | diag_tbl$n_NA>0 | diag_tbl$n_Inf>0
if (any(flag)) { cat("\n[Phase0] WARNING: problematic SR columns:\n"); print(diag_tbl[flag,])
} else cat("\n[Phase0] All SR columns healthy\n")

out_df <- bind_cols(dat, sr_df)
write_csv(out_df, DATA_OUT)
cat(sprintf("[Phase0] Wrote: %s (%d rows x %d cols, +%d SR)\n", DATA_OUT, nrow(out_df), ncol(out_df), ncol(sr_df)))
cat("\n=== Phase 0 complete ===\n")

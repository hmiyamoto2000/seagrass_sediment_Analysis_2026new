# ============================================================
# Causal Mediation Analysis (CMA)
# ============================================================
# ============================================================
# Libraries
# ============================================================
library(mediation)
library(dplyr)
library(DiagrammeR)
library(DiagrammeRsvg)
library(rsvg)

# ============================================================
# Data
# ============================================================
input <- read.csv(
  "input_file.csv"
)
dir.create("./CMA_Desulf", showWarnings = FALSE)

# ============================================================
# Desulfobulbaceae を mediator とした CMA パス生成
# ============================================================
# 上流候補: 他のBacteria + Eukaryota
upstream_vars <- c(
  "B_bacterium_enrichment_culture_clone_22_2013",
  "B_Defluviitaleaceae",
  "B_Hyphomonadaceae",
  "E_Corallinophycidae",
  "B_uncultured_Aminicenantes_bacterium",
  "E_Diatomea",
  "E_Intramacronucleata"
)

# mediator と outcome 固定
mediator_var <- "B_Desulfobulbaceae"
outcome_var <- "Seagrass"

# CMA パス作成
mediation_paths <- lapply(upstream_vars, function(up) {
  list(
    treat = up,
    mediator = mediator_var,
    outcome = outcome_var
  )
})

# ============================================================
# mediation 解析
# ============================================================
all_results <- list()
sink("./CMA_Desulf/mediation_detailed_results.txt")

for (path in mediation_paths) {
  cat("============================================================\n")
  cat("Treat:", path$treat, "Mediator:", path$mediator, "Outcome:", path$outcome, "\n")
  cat("============================================================\n")
  
  # Mediator ~ Treat
  fit_m <- lm(as.formula(paste(path$mediator, "~", path$treat)), data = input)
  # Outcome ~ Treat + Mediator
  fit_y <- lm(as.formula(paste(path$outcome, "~", path$treat, "+", path$mediator)), data = input)
  
  cat("\n--- LM: Mediator ~ Treat ---\n")
  print(summary(fit_m))
  
  cat("\n--- LM: Outcome ~ Treat + Mediator ---\n")
  print(summary(fit_y))
  
  # Quasi-Bayes
  med_bayes <- tryCatch(
    mediate(fit_m, fit_y, treat = path$treat, mediator = path$mediator, sims = 1000),
    error = function(e) NULL
  )
  
  # Bootstrap
  med_boot <- tryCatch(
    mediate(fit_m, fit_y, treat = path$treat, mediator = path$mediator, boot = TRUE, sims = 1000),
    error = function(e) NULL
  )
  
  if (!is.null(med_bayes)) {
    cat("\n--- Quasi-Bayes Mediation ---\n")
    print(summary(med_bayes))
  }
  if (!is.null(med_boot)) {
    cat("\n--- Bootstrap Mediation ---\n")
    print(summary(med_boot))
  }
  
  # 結果格納
  df <- data.frame(
    Treat = path$treat,
    Mediator = path$mediator,
    Outcome = path$outcome,
    Method = c("Bootstrap", "QuasiBayes"),
    ACME = c(ifelse(is.null(med_boot), NA, med_boot$d0),
             ifelse(is.null(med_bayes), NA, med_bayes$d0)),
    ADE = c(ifelse(is.null(med_boot), NA, med_boot$z0),
            ifelse(is.null(med_bayes), NA, med_bayes$z0)),
    Total = c(ifelse(is.null(med_boot), NA, med_boot$tau.coef),
              ifelse(is.null(med_bayes), NA, med_bayes$tau.coef)),
    Prop.Mediated = c(ifelse(is.null(med_boot), NA, med_boot$n0),
                      ifelse(is.null(med_bayes), NA, med_bayes$n0))
  )
  
  all_results <- append(all_results, list(df))
}

sink()
all_df <- bind_rows(all_results)
write.csv(all_df, "./CMA_Desulf/mediation_summary.csv", row.names = FALSE)

# ============================================================
# SEM + DAG 可視化
# mediator を中心に DAG 作成
# ============================================================
edges <- data.frame(
  from = character(),
  to   = character(),
  est  = numeric(),
  p    = numeric(),
  stringsAsFactors = FALSE
)

for (path in mediation_paths) {
  fit_m <- lm(as.formula(paste(path$mediator, "~", path$treat)), data = input)
  coef_m <- summary(fit_m)$coefficients
  edges <- rbind(edges, data.frame(
    from = path$treat,
    to   = path$mediator,
    est  = coef_m[2,1],
    p    = coef_m[2,4]
  ))
  
  fit_y <- lm(as.formula(paste(path$outcome, "~", path$treat, "+", path$mediator)), data = input)
  coef_y <- summary(fit_y)$coefficients
  edges <- rbind(edges, data.frame(
    from = path$mediator,
    to   = path$outcome,
    est  = coef_y[3,1],
    p    = coef_y[3,4]
  ))
}

edges <- edges[!duplicated(edges[,c("from","to")]), ]

get_p_star <- function(p) {
  ifelse(p < 0.001, "***",
         ifelse(p < 0.01, "**",
                ifelse(p < 0.05, "*", "(ns)")))
}

edges$label <- paste0(round(edges$est, 3), get_p_star(edges$p))
edges$color <- ifelse(edges$p < 0.05 & edges$est > 0, "green",
                      ifelse(edges$p < 0.05 & edges$est < 0, "red", "gray"))
edges$style <- ifelse(edges$p < 0.05, "solid", "dashed")

edge_lines <- paste0(
  edges$from, " -> ", edges$to,
  " [label='", edges$label,
  "', color='", edges$color,
  "', style='", edges$style, "'];"
)

dot_code <- paste0("
digraph SEM_CMA_Desulf {
  graph [layout = dot, rankdir = TB];
  node [shape = rectangle, style = filled, fillcolor = white, fontname='Helvetica'];
  edge [fontname='Helvetica'];
  ", paste(edge_lines, collapse = "\n"), "
  label = 'Desulf-centered SEM + CMA';
}")

graph <- grViz(dot_code)
graph

svg_code <- export_svg(graph)
rsvg_pdf(charToRaw(svg_code), "./CMA_Desulf/SEM_CMA_Desulf.pdf")
rsvg_png(charToRaw(svg_code), "./CMA_Desulf/SEM_CMA_Desulf.png",
         width = 2480, height = 3508)


cat("Desulf-centered CMA 解析が ./CMA_Desulf に出力されました。\n")


#!/usr/bin/env Rscript
# =====================================================================
# Fig. 6c (main text, simplified)  — R1-G6 対応
# ---------------------------------------------------------------------
# 2種類を同時に出力:
#   _clean … 丸枠内は名前だけ。集約ノードは "Biome others" / "Chemical others" ← 本番用
#   _check … 丸枠内に included% と個別有意性を併記 ← 確認用
#
# 【2026-10-11 の修正】
#   1. ★矢じりの形: arrowsize=1.5。太い線（penwidth 6）に対して矢じりが小さく
#      潰れて見えていたため。
#   2. ★SR 潜在変数の名称を SR_score1 / SR_score2 に戻す（本文凡例と一致）。
#      biome/chemistry の対応は data_type 列から取る。
#   3. ★ライン上の数字の重なり: 辺のラベルを midpoint ではなく headlabel /
#      taillabel にし、左半分は +角度・右半分は −角度にして線の外側へ出す。
#      あわせて ranksep を広げて扇を縦に伸ばす。
#   4. ★書き出しサイズの単位バグ: rsvg_png / rsvg_pdf は width と height の
#      両方を指定すると画像が引き伸ばされる（縦横比が崩れる）。片方のみ指定する。
#      また rsvg_pdf の単位は「ポイント」なので width=13 では 13pt（約0.18インチ）の
#      極小 PDF になる。元の SEM_Figure_505_collective_v10.R も同じ問題を抱えている。
#
# 符号化（★凡例もこのとおりに書くこと）:
#   エッジの太さ … そのパスが含まれたモデルの割合（pct = n_models/505）＝ 群レベル
#   色 / 線種    … 個別パスの有意性 ＝ 個別レベル
#                   緑・赤の実線 = 含まれたすべてのモデルで有意
#                   灰色の破線   = どのモデルでも有意にならなかった
#   ※ 実データでは p_sig_pct は 100 か 0 のみ（中間値なし）
#
# 入力:  phase9_downstream_path_summary_strict505.csv
#        phase9_sr_path_summary_strict505.csv（無ければ既知の値で代替）
# 出力:  Fig6c_main_simplified_clean.png / .pdf
#        Fig6c_main_simplified_check.png / .pdf
# =====================================================================

library(DiagrammeR); library(DiagrammeRsvg); library(rsvg)
library(readr); library(dplyr); library(tibble)

TOTAL <- 505

## --- 設定 -----------------------------------------------------------
AGGREGATE_BIOME <- TRUE   # FALSE にすると biome の非有意2変数を個別ノードのまま残す

NODE_FONTSIZE  <- 18      # 丸枠内の文字サイズ（clean 版）
CHECK_FONTSIZE <- 13      # check 版は3行入るので小さめ
EDGE_FONTSIZE  <- 14      # 線上の数字
ARROWSIZE      <- 1.5     # ★矢じりの大きさ
NODE_HEIGHT    <- 0.8     # ★楕円の高さ。既定（0.5）のままだと平たすぎて、
                          #   arrowsize を大きくしたとき矢じりが楕円の内側に食い込む。
                          #   0.8 にすると矢じりの先端がちょうど楕円の縁で止まる。
                          #   副次効果として図の横幅も縮む（同じ文字量でも楕円が横に短くなるため）。
RANKSEP        <- 1.5     # ★上下の線の長さ。小さいほど図が低くなる
NODESEP        <- 0.22    # ★下段の詰め具合。小さいほど図が狭くなる
LABELDIST      <- 4.5     # ★ラベルを円から離す距離。4.5 が最適
                          #   これ以上大きくするとラベルが隣の線に乗る
LABELANG       <- 30      # ★下流の辺：左半分 +、右半分 − （線の外側に出す）
SR_LABELDIST   <- 3.4
SR_LABELANG    <- 60      # ★SR の辺：太い線に重ならないよう大きめ

OUT_PREFIX <- "Fig6c_main_simplified"

# ★書き出しサイズ。片方のみ指定すること（両方だと引き伸ばされる）
PNG_WIDTH_PX  <- 3200     # ピクセル
PDF_WIDTH_PT  <- 1300     # ★ポイント（1300pt ≒ 18 インチ）

AGG_LABEL <- c(Biome = "Biome others", Chemical = "Chemical others")

CAPTION <- "505 of 378,018 candidate specifications satisfied all eight goodness-of-fit criteria and regional universality"
CAPTION_FONTSIZE <- 15
SHOW_CAPTION <- TRUE

## --- 表示名（R1: アンダースコア・コード表記を使わない） ---------------
disp <- c(
  B_Defluviitaleaceae                          = "Defluviitaleaceae",
  B_Desulfobulbaceae                           = "Desulfobulbaceae",
  B_Hyphomonadaceae                            = "Hyphomonadaceae",
  B_uncultured_Aminicenantes_bacterium         = "uncultured Aminicenantes",
  B_bacterium_enrichment_culture_clone_22_2013 = "bacterium enrichment clone 22",
  E_Corallinophycidae                          = "Corallinophycidae",
  E_Diatomea                                   = "Diatomea",
  E_Intramacronucleata                         = "Intramacronucleata",
  chemical_CaO_log                             = "CaO",
  chemical_CEC_log                             = "CEC",
  chemical_NO3_N_log                           = "NO3-N",
  chemical_P2O5_log                            = "P2O5"
)
node_id <- function(x) gsub("[^A-Za-z0-9]", "", x)

## --- データ読み込み --------------------------------------------------
DOWN_CSV <- "phase9_downstream_path_summary_strict505.csv"
SR_CSV   <- "phase9_sr_path_summary_strict505.csv"

if (!file.exists(DOWN_CSV))
  stop(sprintf("必須ファイルがありません: %s\n  カレントディレクトリ: %s", DOWN_CSV, getwd()))
down <- read_csv(DOWN_CSV, show_col_types = FALSE)

if (file.exists(SR_CSV)) {
  sr <- read_csv(SR_CSV, show_col_types = FALSE)
} else {
  warning(sprintf("%s が無いため既知の値で代替します（SR1 biome +0.811, SR2 chemistry +0.282）。", SR_CSV))
  sr <- tibble(lhs = c(".SR1", ".SR2"), n = c(505, 505),
               std_median = c(0.811496, 0.281868),
               p_sig_pct = c(100, 100), data_type = c("biome", "chemistry"))
}

down <- down %>%
  mutate(pct      = 100 * n_models / TOTAL,
         is_sig   = p_sig_pct > 50,
         domain   = ifelse(grepl("^chemical_", lhs), "Chemical", "Biome"),
         # ★マーカー（16S / 18S / 化学）で分類して並べ替える
         marker   = ifelse(grepl("^B_", lhs), "16S",
                    ifelse(grepl("^E_", lhs), "18S", "Chemical")),
         mrank    = ifelse(grepl("^B_", lhs), 1L,
                    ifelse(grepl("^E_", lhs), 2L, 3L)),
         dispname = unname(disp[lhs])) %>%
  # ★左から右へ: 16S → 18S → 化学、各群内は表示名のアルファベット順（大小文字を無視）
  arrange(mrank, tolower(dispname))
stopifnot(!any(is.na(down$dispname)))

fill_of  <- function(b) if (b > 0) "#A8D5A8" else "#F5A8A8"
color_of <- function(b) if (b > 0) "forestgreen" else "firebrick"
penw     <- function(pct) min(max((pct / 100) * 6, 0.6), 6)
sig_txt  <- function(p) {
  if (is.na(p))         "significance not available"
  else if (p >= 99.999) "significant in all of them"
  else if (p <= 0.001)  "significant in none"
  else         sprintf("significant in %.0f%% of them", p)
}

indiv <- down %>% filter(is_sig)
if (!AGGREGATE_BIOME) indiv <- bind_rows(indiv, down %>% filter(!is_sig, domain == "Biome")) %>% arrange(mrank, tolower(dispname))
agg_domains <- if (AGGREGATE_BIOME) c("Biome", "Chemical") else c("Chemical")
agg <- down %>% filter(!is_sig, domain %in% agg_domains)

## --- 上流（SR）: 番号は lhs（.SR1/.SR2）、種別は data_type から ---------
sr <- sr %>% mutate(num = gsub("[^0-9]", "", lhs),
                    shown = ifelse(data_type == "biome", "microbiome", data_type))
sr_b <- sr %>% filter(data_type == "biome")     %>% slice(1)
sr_c <- sr %>% filter(data_type == "chemistry") %>% slice(1)

## --- DOT 生成 --------------------------------------------------------
build_dot <- function(mode) {
  fs <- if (mode == "clean") NODE_FONTSIZE else CHECK_FONTSIZE
  n_all <- nrow(indiv) + length(agg_domains)
  half  <- n_all / 2

  indiv_nodes <- vapply(seq_len(nrow(indiv)), function(i) {
    r <- indiv[i, ]
    lbl <- if (mode == "clean") r$dispname
           else sprintf("%s\\nincluded in %.0f%% of models\\n%s",
                        r$dispname, r$pct, sig_txt(r$p_sig_pct))
    sprintf("%s [label='%s' shape=ellipse style=filled fillcolor='%s' fontsize=%d height=%.1f]",
            node_id(r$lhs), lbl, fill_of(r$std_median), fs, NODE_HEIGHT)
  }, character(1))

  # ★左半分は +角度、右半分は −角度 → ラベルが線の外側に出て重ならない
  indiv_edges <- vapply(seq_len(nrow(indiv)), function(i) {
    r   <- indiv[i, ]
    ang <- if (i <= half) LABELANG else -LABELANG
    sprintf(paste0("Seagrass -> %s [headlabel='%+.2f' labeldistance=%.1f labelangle=%d ",
                   "fontsize=%d fontcolor='%s' color='%s' penwidth=%.2f arrowsize=%.1f style=solid]"),
            node_id(r$lhs), r$std_median, LABELDIST, ang,
            EDGE_FONTSIZE, color_of(r$std_median), color_of(r$std_median),
            penw(r$pct), ARROWSIZE)
  }, character(1))

  agg_nodes <- c(); agg_edges <- c()
  for (dm in agg_domains) {
    g <- agg %>% filter(domain == dm) %>% arrange(desc(pct))
    if (nrow(g) == 0) next
    id  <- paste0("AGG", dm)
    lbl <- if (mode == "clean") unname(AGG_LABEL[dm]) else {
      nm <- g$dispname
      lines <- vapply(split(nm, ceiling(seq_along(nm) / 2)),
                      function(z) paste(z, collapse = ", "), character(1))
      paste0(paste(lines, collapse = "\\n"),
             sprintf("\\nincluded in %.0f-%.0f%% of models", min(g$pct), max(g$pct)),
             "\\nnot significant in any model")
    }
    agg_nodes <- c(agg_nodes,
      sprintf("%s [label='%s' shape=ellipse style=filled fillcolor='#E5E5E5' fontsize=%d height=%.1f]", id, lbl, fs, NODE_HEIGHT))
    # 集約ノードは数値を置かない（標準化係数は合計・平均できないため）
    agg_edges <- c(agg_edges,
      sprintf("Seagrass -> %s [color='grey50' penwidth=1.3 arrowsize=%.1f style=dashed]", id, ARROWSIZE))
  }

  top_ids <- c(vapply(indiv$lhs, node_id, character(1)), paste0("AGG", agg_domains))

  cap <- if (SHOW_CAPTION)
    sprintf("label='%s'\nlabelloc=b\nlabeljust=c\nfontname=Helvetica\nfontsize=%d\n",
            CAPTION, CAPTION_FONTSIZE) else ""

  sprintf("
digraph SEM_505_simplified {
rankdir=TB
ranksep=%s
nodesep=%.1f
splines=true
%s
node [fontname=Helvetica]
edge [fontname=Helvetica]

%s
%s

Seagrass [label='Seagrass' shape=box style=filled fillcolor='#C6E0B4' fontsize=22 width=1.9 height=0.9]
SRbio  [label='SR_score%s\\n(microbiome)' shape=ellipse style=filled fillcolor='#FFB347' fontsize=%d]
SRchem [label='SR_score%s\\n(chemistry)'  shape=ellipse style=filled fillcolor='#FFF2CC' fontsize=%d]

{rank=same; %s}
{rank=same; Seagrass}
{rank=same; SRbio SRchem}

SRbio -> SRchem [style=invis]

SRbio  -> Seagrass [taillabel='%+.2f' labeldistance=%.1f labelangle=%d fontsize=%d fontcolor='forestgreen' color='forestgreen' penwidth=6.0 arrowsize=%.1f]
SRchem -> Seagrass [taillabel='%+.2f' labeldistance=%.1f labelangle=%d fontsize=%d fontcolor='forestgreen' color='forestgreen' penwidth=3.0 arrowsize=%.1f]
%s
%s
}",
  if (mode == "clean") RANKSEP else RANKSEP + 0.3, NODESEP, cap,
  paste(indiv_nodes, collapse = "\n"),
  paste(agg_nodes,   collapse = "\n"),
  sr_b$num, fs, sr_c$num, fs,
  paste(top_ids, collapse = " "),
  sr_b$std_median, SR_LABELDIST, -SR_LABELANG, EDGE_FONTSIZE, ARROWSIZE,
  sr_c$std_median, SR_LABELDIST,  SR_LABELANG, EDGE_FONTSIZE, ARROWSIZE,
  paste(indiv_edges, collapse = "\n"),
  paste(agg_edges,   collapse = "\n"))
}

## --- 出力（★width のみ指定。height も指定すると引き伸ばされる）---------
for (mode in c("clean", "check")) {
  p   <- grViz(build_dot(mode))
  svg <- export_svg(p) |> charToRaw()
  png <- sprintf("%s_%s.png", OUT_PREFIX, mode)
  pdf <- sprintf("%s_%s.pdf", OUT_PREFIX, mode)
  rsvg_png(svg, png, width = PNG_WIDTH_PX)
  rsvg_pdf(svg, pdf, width = PDF_WIDTH_PT)
  cat(sprintf("  出力: %s / %s\n", png, pdf))
}

## --- 凡例に書く数値（clean 版は図中に出ない）---------------------------
cat("\n=== 凡例に記載する数値（clean 版は図中に出ません）===\n")
cat(sprintf("AGGREGATE_BIOME = %s  -> ノード数 %d（元 %d）\n\n",
            AGGREGATE_BIOME, nrow(indiv) + length(agg_domains), nrow(down)))
cat("--- 個別ノード（図の左から右の順: 16S -> 18S、各群内アルファベット順）---\n")
print(indiv %>% transmute(marker, name = dispname, included = sprintf("%.1f%%", pct),
                          beta = round(std_median, 3)) %>% as.data.frame())
cat("\n--- 集約ノード（どのモデルでも有意にならなかった）---\n")
for (dm in agg_domains) {
  g <- agg %>% filter(domain == dm) %>% arrange(desc(pct))
  if (nrow(g) == 0) next
  cat(sprintf("\n  [%s] = %s\n", AGG_LABEL[dm], paste(g$dispname, collapse = ", ")))
  cat(sprintf("     included %.1f-%.1f%% / beta %+.3f to %+.3f / not significant in any model\n",
              min(g$pct), max(g$pct), min(g$std_median), max(g$std_median)))
  print(g %>% transmute(name = dispname, included = sprintf("%.1f%%", pct),
                        beta = round(std_median, 3)) %>% as.data.frame())
}
cat(sprintf("\n--- 上流 ---\n  SR_score%s (microbiome) %+.2f / SR_score%s (chemistry) %+.2f\n",
            sr_b$num, sr_b$std_median, sr_c$num, sr_c$std_median))

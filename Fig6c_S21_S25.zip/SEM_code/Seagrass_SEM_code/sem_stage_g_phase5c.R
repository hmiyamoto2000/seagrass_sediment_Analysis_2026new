#!/usr/bin/env Rscript
# Phase 5c: WLSMV re-fit of 12,651 candidates with full fit indices including GFI/AGFI/WRMR
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT     <- "/Fig6"
DATA_IN  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
Q_CSV    <- file.path(ROOT, "phase5b_final_candidates.csv")
OUT_DIR  <- file.path(ROOT, "phase5c_chunks")
dir.create(OUT_DIR, showWarnings = FALSE)
SUMMARY  <- file.path(ROOT, "phase5c_full_fit.csv")

dat  <- read_csv(DATA_IN, show_col_types=FALSE)
qual <- read_csv(Q_CSV, show_col_types=FALSE) %>% select(sr1, sr2, k, downset)
cat(sprintf("[Phase5c] Models: %d   Data: %d rows\n", nrow(qual), nrow(dat)))

fit_one <- function(sr1, sr2, downset_str) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  downs <- strsplit(downset_str, split="|", fixed=TRUE)[[1]]
  rhs <- paste(downs, collapse=" + ")
  mod <- sprintf("Seagrass ~ .SR1 + .SR2\n%s ~ Seagrass", rhs)
  res <- tryCatch({
    fit <- suppressWarnings(lavaan::sem(mod, data=d, ordered="Seagrass",
                                        estimator="WLSMV", se="robust"))
    if (!isTRUE(lavaan::lavInspect(fit, "converged")))
      return(tibble(converged=FALSE))
    fm <- lavaan::fitMeasures(fit, c("chisq.scaled","df","pvalue.scaled",
            "cfi.scaled","tli.scaled","rmsea.scaled","srmr","wrmr","gfi","agfi"))
    pe <- lavaan::parameterEstimates(fit, standardized=TRUE)
    g <- function(lhs, rhs) {
      r <- pe[pe$lhs==lhs & pe$op=="~" & pe$rhs==rhs, ]
      if (nrow(r)==0) c(NA,NA) else c(r$std.all[1], r$pvalue[1])
    }
    s1 <- g("Seagrass",".SR1"); s2 <- g("Seagrass",".SR2")
    down_p <- map(downs, ~ g(.x, "Seagrass"))
    n_sig <- sum(map_dbl(down_p, ~ .x[2]) < 0.05, na.rm=TRUE)
    tibble(converged=TRUE, k=length(downs),
           chisq=unname(fm["chisq.scaled"]), df=unname(fm["df"]),
           pvalue=unname(fm["pvalue.scaled"]),
           cfi=unname(fm["cfi.scaled"]), tli=unname(fm["tli.scaled"]),
           rmsea=unname(fm["rmsea.scaled"]),
           srmr=unname(fm["srmr"]), wrmr=unname(fm["wrmr"]),
           gfi=unname(fm["gfi"]), agfi=unname(fm["agfi"]),
           sr1_std=s1[1], sr1_p=s1[2], sr2_std=s2[1], sr2_p=s2[2],
           n_down_sig=n_sig)
  }, error=function(e) tibble(converged=FALSE))
  res$sr1 <- sr1; res$sr2 <- sr2; res$downset <- downset_str
  res
}

plan(multisession, workers=24)
CHUNK <- 500
chunks <- split(seq_len(nrow(qual)), ceiling(seq_len(nrow(qual))/CHUNK))
cat(sprintf("[Phase5c] %d chunks of up to %d models\n", length(chunks), CHUNK))

t0 <- Sys.time()
for (ci in seq_along(chunks)) {
  out_path <- file.path(OUT_DIR, sprintf("phase5c_chunk_%03d.csv", ci))
  if (file.exists(out_path)) {
    cat(sprintf("[chunk %3d/%d] skip\n", ci, length(chunks))); next
  }
  rows_ci <- chunks[[ci]]
  res <- future_map_dfr(rows_ci,
           function(i) fit_one(qual$sr1[i], qual$sr2[i], qual$downset[i]),
           .options=furrr_options(seed=TRUE), .progress=TRUE)
  write_csv(res, out_path)
  el <- as.numeric(Sys.time()-t0, units="mins")
  cat(sprintf("[chunk %3d/%d] %d models, elapsed %.1f min, %.1f%% done\n",
              ci, length(chunks), nrow(res), el, ci/length(chunks)*100))
}

cat("[Phase5c] Combining...\n")
all_files <- list.files(OUT_DIR, pattern="^phase5c_chunk_.*\\.csv$", full.names=TRUE)
combined <- map_dfr(all_files, ~ read_csv(.x, show_col_types=FALSE))
write_csv(combined, SUMMARY)
cat(sprintf("[Phase5c] Wrote %s (%d rows, total %.1f min)\n",
            SUMMARY, nrow(combined), as.numeric(Sys.time()-t0, units="mins")))

ok <- combined %>% filter(converged) %>%
  filter(gfi >= 0.95, agfi >= 0.90, wrmr <= 1.0)
cat(sprintf("[Phase5c] After GFI>=0.95 & AGFI>=0.90 & WRMR<=1.0: %d models\n", nrow(ok)))
write_csv(ok, "phase5c_final_filtered.csv")

cat("\n[Phase5c] Top 30 by SRMR (post all filters):\n")
print(ok %>% arrange(srmr) %>% slice_head(n=30) %>%
      select(sr1, sr2, k, pvalue, cfi, tli, gfi, agfi, rmsea, srmr, wrmr,
             sr1_std, sr1_p, sr2_std, sr2_p, n_down_sig, downset),
      n=30, width=Inf)

cat("\n=== Phase 5c complete ===\n")

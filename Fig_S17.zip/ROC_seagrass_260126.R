
library(Epi)

# 出力フォルダ作成（必要なら）
dir.create("./ROC_seagrass", showWarnings = TRUE, recursive = TRUE)

# データ読み込み
Data <- read.csv("yourfile.csv") #1列目の表題 group　#file名は自分のfile 一列目はgroupとして設定

# 菌種名の取得（1列目 group を除く）
bacteria_names <- colnames(Data)[-1]

# AUC 結果を保存するデータフレームを用意
auc_results <- data.frame(
  Feature = character(),
  AUC = numeric(),
  stringsAsFactors = FALSE
)

# ROC解析ループ
for (bacteria in bacteria_names) {
  
  # ROC解析（plot=FALSE で描画しない）
  roc_result <- ROC(test = Data[[bacteria]], stat = Data$group, plot = FALSE,legend = FALSE) #roc_result <- ROC(test = Data[[bacteria]], stat = Data$group, plot = FALSE)
  
  # AUC値を取得
  auc_value <- roc_result$AUC
  
  # AUC情報を結果に追加
  auc_results <- rbind(auc_results, data.frame(Feature = bacteria, AUC = auc_value))
  
  # PNG保存
  png_filename <- paste0("./ROC_seagrass/ROC_graph_", bacteria, ".png")
  png(filename = png_filename, width = 6 * 300, height = 6 * 300, res = 300)
  ROC(test = Data[[bacteria]], stat = Data$group, plot = "ROC")
  dev.off()
  
  # PDF保存
  pdf_filename <- paste0("./ROC_seagrass/ROC_graph_", bacteria, ".pdf")
  pdf(file = pdf_filename, width = 6, height = 6)
  ROC(test = Data[[bacteria]], stat = Data$group, plot = "ROC")
  dev.off()
  
  # テキスト保存
  txt_filename <- paste0("./ROC_seagrass/ROC_graph_raw_data_", bacteria, ".txt")
  sink(txt_filename, append = TRUE)
  cat("ROC result for:", bacteria, "\n\n")
  print(roc_result)
  sink()
}

# AUCフィルタ（AUC >= 0.6 または AUC <= 0.4）
filtered_auc <- subset(auc_results, AUC >= 0.6 | AUC <= 0.4)

# 結果をCSVファイルに保存
write.csv(filtered_auc, "./ROC_seagrass/Filtered_AUC_Features.csv", row.names = FALSE)

# whole AUC
whole_auc <- subset(auc_results)

# 結果をCSVファイルに保存
write.csv(whole_auc, "./ROC_seagrass/whole_AUC_Features.csv", row.names = FALSE)


##############################
#install.packages("pROC")

library(pROC)

# 保存フォルダの作成（なければ）
if(!dir.exists("./ROC_seagrass")) dir.create("./ROC_seagrass")

# 菌種名（group列を除く）
bacteria_names <- colnames(Data)[-1]

for (bacteria in bacteria_names) {
  
  # ROC計算
  roc_result <- roc(
    response  = Data$group,
    predictor = Data[[bacteria]],
    quiet = TRUE
  )
  
  # FPR/TPR を取得
  roc_df <- data.frame(
    x = 1 - roc_result$specificities,   # 1 - Specificity
    y = roc_result$sensitivities
  )
  
  # PNG 出力
  png_filename <- paste0("./ROC_seagrass/ROC_graph_", bacteria, ".png")
  png(filename = png_filename, width = 6*300, height = 6*300, res = 300)
  
  # プロット
  plot(
    roc_df$x,
    roc_df$y,
    type = "s",          # 階段状にする
    lwd  = 2,
    col  = "green", #色はここで変えるblueとかlightgreenとかblackとか
    xlab = "1 - Specificity",
    ylab = "Sensitivity",
    main = paste("ROC:", bacteria),
    frame.plot = FALSE   # 枠線なし
  )
  
  # 対角線（必要なら）
  abline(0, 1, lty = 2, col = "grey")
  
  dev.off()
  
  # AUC をコンソール表示（任意）
  cat(bacteria, "AUC =", round(auc(roc_result), 3), "\n")
}


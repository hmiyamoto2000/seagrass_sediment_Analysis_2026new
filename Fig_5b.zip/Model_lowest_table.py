#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import sys
import pandas as pd
from pathlib import Path

def main():
    if len(sys.argv) < 2:
        print("Usage: python collect_min_loss_hof.py <input_folder> [output_csv]")
        sys.exit(1)

    input_folder = Path(sys.argv[1])
    output_csv = Path(sys.argv[2]) if len(sys.argv) >= 3 else Path("all_min_loss_hof.csv")

    if not input_folder.exists() or not input_folder.is_dir():
        print(f"Error: {input_folder} is not a valid folder")
        sys.exit(1)

    # サブフォルダを作成順に取得
    subfolders = sorted([f for f in input_folder.iterdir() if f.is_dir()],
                        key=lambda x: x.stat().st_ctime)

    all_min_rows = []

    for subfolder in subfolders:
        hof_file = subfolder / "hall_of_fame.csv"
        if not hof_file.exists():
            print(f"[SKIP] {hof_file} not found")
            continue

        df = pd.read_csv(hof_file)

        if "Loss" not in df.columns or "Equation" not in df.columns:
            print(f"[SKIP] 'Loss' or 'Equation' column not found in {hof_file}")
            continue

        # 最小 Loss 行だけ取得
        min_row = df.loc[df["Loss"].idxmin()]
        min_row_dict = min_row.to_dict()
        min_row_dict["SourceFolder"] = subfolder.name
        all_min_rows.append(min_row_dict)

    if not all_min_rows:
        print("No valid hall_of_fame.csv found.")
        return

    # データフレーム作成
    result_df = pd.DataFrame(all_min_rows)
    result_df.to_csv(output_csv, index=False)
    print(f"Saved: {output_csv}")

if __name__ == "__main__":
    main()

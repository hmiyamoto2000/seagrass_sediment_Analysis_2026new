#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#python3.10 code.py A.csv
#python3.10 txtデータから時系列グラフ.py *.csv

#各ファイルには yyyy,mm,dd,areaNo.,flag,Temp. の列があり、
#areaNo. と flag の組み合わせが固定（つまり6個セットで1グループ）。
#それぞれの組み合わせ（例: areaNo.＝508, flag＝P）ごとに
#年平均・月平均の時系列グラフ を作成


#pip install pandas matplotlib

#Time course/
#├─ merged_data.csv             ← すべてのファイルを統合したCSV
#├─ yearly_area508_flagP.png
#├─ monthly_area508_flagP.png
#├─ yearly_area509_flagP.png
#├─ monthly_area509_flagP.png

#"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#python3.10 code.py file1.csv file2.csv ...

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#python3.10 code.py A.csv
#python3.10 txtデータから時系列グラフ.py *.csv

#各ファイルには yyyy,mm,dd,areaNo.,flag,Temp. の列があり、
#areaNo. と flag の組み合わせが固定（つまり6個セットで1グループ）。
#それぞれの組み合わせ（例: areaNo.＝508, flag＝P）ごとに
#年平均・月平均の時系列グラフ を作成


#pip install pandas matplotlib

#Time course/
#├─ merged_data.csv             ← すべてのファイルを統合したCSV
#├─ yearly_area508_flagP.png
#├─ monthly_area508_flagP.png
#├─ yearly_area509_flagP.png
#├─ monthly_area509_flagP.png

#"""
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#python3.10 code.py file1.csv file2.csv ...

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#python3.10 code.py A.csv
#python3.10 txtデータから時系列グラフ.py *.csv

#Python では for の中の処理は必ず 1段階（通常4スペース）インデント しなければならず、あなたのコードだと df_area_year = df_yearly[...] の行が for と同じレベルになってしまっています。

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.ticker import FormatStrFormatter

# フォント設定
rcParams['font.family'] = 'Helvetica'
rcParams['font.size'] = 20

def detect_date_column(df):
    df.columns = [c.lower().replace(".", "").replace(" ", "").replace("　","") for c in df.columns]
    if all(x in df.columns for x in ["yyyy","mm","dd"]):
        for col in ["yyyy","mm","dd"]:
            df[col] = pd.to_numeric(df[col].astype(str).str.strip(), errors="coerce")
        df = df.dropna(subset=["yyyy","mm","dd"])
        df["date"] = pd.to_datetime(
            df.apply(lambda row: f"{int(row['yyyy'])}-{int(row['mm']):02d}-{int(row['dd']):02d}", axis=1)
        )
        return df
    elif all(x in df.columns for x in ["year","month","day"]):
        for col in ["year","month","day"]:
            df[col] = pd.to_numeric(df[col].astype(str).str.strip(), errors="coerce")
        df = df.dropna(subset=["year","month","day"])
        df["date"] = pd.to_datetime(
            df.apply(lambda row: f"{int(row['year'])}-{int(row['month']):02d}-{int(row['day']):02d}", axis=1)
        )
        return df
    elif "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"].astype(str).str.strip(), errors="coerce")
        return df

    print("❌ 日付列が見つかりません。")
    sys.exit(1)

def save_both_formats(fig, filepath_base):
    fig.savefig(filepath_base + ".png", dpi=300)
    fig.savefig(filepath_base + ".pdf", dpi=300)
    plt.close(fig)

def set_yformat():
    """Y軸を常に小数点1桁に固定"""
    plt.gca().yaxis.set_major_formatter(FormatStrFormatter('%.1f'))

def main():
    if len(sys.argv) < 2:
        print("使用法: python コード.py file1.csv file2.csv ...")
        sys.exit(1)

    files = sys.argv[1:]
    output_dir = "Time course"
    os.makedirs(output_dir, exist_ok=True)

    all_data = []
    for f in files:
        try:
            df = pd.read_csv(f, sep=",", header=0, encoding="utf-8")
            df = detect_date_column(df)
            df.columns = [c.lower().replace(".", "").replace(" ", "").replace("　","") for c in df.columns]
            all_data.append(df)
            print(f"✅ 読み込み完了: {f}")
        except Exception as e:
            print(f"❌ 読み込み失敗: {f} ({e})")

    if not all_data:
        print("読み込めるデータがありません。")
        sys.exit(1)

    df_all = pd.concat(all_data, ignore_index=True)
    df_all = df_all[df_all["date"].dt.year >= 2016]

    if df_all.empty:
        print("2016年以降のデータが存在しません。")
        sys.exit(1)

    df_all["year"] = df_all["date"].dt.year
    df_all["month"] = df_all["date"].dt.month

    df_yearly = df_all.groupby(["areano","year"])["temp"].mean().reset_index()
    df_monthly = df_all.groupby(["areano","year","month"])["temp"].mean().reset_index()
    df_monthly_10yr = df_monthly.groupby(["areano","month"])["temp"].mean().reset_index()

    area_list = sorted(df_all["areano"].unique())

    # --- 個別グラフ ---
    for area in area_list:

        df_area_year = df_yearly[df_yearly["areano"] == area]
        df_area_month = df_monthly[df_monthly["areano"] == area].copy()
        df_area_month["year_month"] = pd.to_datetime(
            df_area_month[["year","month"]].assign(day=1)
        )

        # 年平均
        fig = plt.figure(figsize=(10,8))
        plt.plot(df_area_year["year"], df_area_year["temp"], marker="o")
        plt.title(f"Area {area} Yearly Average Temp")
        plt.xlabel("Year")
        plt.ylabel("Temperature (°C)")
        set_yformat()
        plt.grid(True)
        plt.tight_layout()
        save_both_formats(fig, os.path.join(output_dir, f"Area{area}_Yearly"))

        # 月平均
        fig = plt.figure(figsize=(10,8))
        plt.plot(df_area_month["year_month"], df_area_month["temp"], marker="o")
        plt.title(f"Area {area} Monthly Average Temp")
        plt.xlabel("Year-Month")
        plt.ylabel("Temperature (°C)")
        set_yformat()
        plt.grid(True)
        plt.tight_layout()
        save_both_formats(fig, os.path.join(output_dir, f"Area{area}_Monthly"))

        # 月平均（年度別）
        import numpy as np
        from matplotlib import cm

        fig = plt.figure(figsize=(10,8))
        years = sorted(df_area_month["year"].unique())
        colors = cm.viridis(np.linspace(0,1,len(years)))

        for i, year in enumerate(years):
            df_year = df_area_month[df_area_month["year"] == year]
            plt.plot(df_year["month"], df_year["temp"],
                     marker="o", label=str(year), color=colors[i])

        plt.title(f"Area {area} Monthly Temp by Year")
        plt.xlabel("Month")
        plt.ylabel("Temperature (°C)")
        plt.xticks(range(1,13))
        set_yformat()
        plt.grid(True)
        plt.legend(title="Year")
        plt.tight_layout()
        save_both_formats(fig, os.path.join(output_dir, f"Area{area}_Monthly_ByYear"))

    # --- 年平均まとめ ---
    fig = plt.figure(figsize=(10,8))
    for area in area_list:
        df_area_year = df_yearly[df_yearly["areano"] == area]
        plt.plot(df_area_year["year"], df_area_year["temp"],
                 marker="o", label=f"Area {area}")

    plt.title("Yearly Average Temp (All Areas)")
    plt.xlabel("Year")
    plt.ylabel("Temperature (°C)")
    set_yformat()
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    save_both_formats(fig, os.path.join(output_dir, "AllAreas_Yearly"))

    print(f"✅ すべてのグラフを '{output_dir}' に出力しました（小数点1桁固定）。")

if __name__ == "__main__":
    main()

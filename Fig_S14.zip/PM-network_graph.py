##!/usr/bin/env python3
# -*- coding: utf-8 -*-
#Precision matrix の上位25%をネットワークとして可視化
#ヒストグラム（通常・logスケール）および累積分布（CDF）作成
#PNG / PDF 出力

import sys
import os
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import seaborn as sns
import matplotlib as mpl
from matplotlib.lines import Line2D

# =========================
# フォント設定
# =========================
mpl.rcParams["font.family"] = "Helvetica"
mpl.rcParams["pdf.fonttype"] = 42
mpl.rcParams["ps.fonttype"] = 42

# =========================
# CSV読み込み
# =========================
filename = sys.argv[1]
df = pd.read_csv(filename, index_col=0)
print("Data shape:", df.shape)

# =========================
# 共分散・逆共分散（Precision matrix）計算
# =========================
cov_matrix = np.cov(df.values, rowvar=False)
inv_cov = np.linalg.pinv(cov_matrix)

# =========================
# 出力フォルダ作成
# =========================
output_dir = "Network_Output"
os.makedirs(output_dir, exist_ok=True)

# =========================
# 上位25%閾値計算
# =========================
abs_vals_all = np.abs(inv_cov[np.triu_indices_from(inv_cov, k=1)])
threshold_25pct = np.percentile(abs_vals_all, 75)
fixed_threshold = 0.05
print(f"Top 25% threshold (75 percentile): {threshold_25pct:.5f}")

# =========================
# ヒストグラム（通常スケール）
# =========================
plt.figure(figsize=(6, 4))
sns.histplot(abs_vals_all, bins=50, color="gray")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red", linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element|")
plt.ylabel("Frequency")
plt.title("Distribution of |Precision matrix elements|")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_histogram.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# ヒストグラム（logスケール）
# =========================
plt.figure(figsize=(6, 4))
sns.histplot(abs_vals_all, bins=50, color="gray")
plt.xscale("log")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red", linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element| (log scale)")
plt.ylabel("Frequency")
plt.title("Distribution of |Precision matrix elements| (log scale)")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_histogram_logscale.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# 累積分布（CDF）
# =========================
sorted_vals = np.sort(abs_vals_all)
cdf = np.arange(1, len(sorted_vals)+1) / len(sorted_vals)

plt.figure(figsize=(5,4))
plt.plot(sorted_vals, cdf, color="black")
plt.axvline(threshold_25pct, color="green", linestyle="--", label="Top 25%")
plt.axvline(fixed_threshold, color="red", linestyle="--", label="0.05")
plt.xlabel("|Precision matrix element|")
plt.ylabel("Cumulative proportion")
plt.title("CDF of |Precision matrix elements|")
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "precision_matrix_cdf.png"), dpi=300, bbox_inches="tight")
plt.close()

# =========================
# CSV出力（全ペア）
# =========================
records = []
cols = df.columns.tolist()
n = len(cols)
for i in range(n):
    for j in range(i + 1, n):
        val = inv_cov[i, j]
        records.append({
            "node_1": cols[i],
            "node_2": cols[j],
            "precision_ij": val,
            "abs_precision_ij": abs(val),
            "above_fixed_0.05": abs(val) > fixed_threshold,
            "above_top25pct": abs(val) >= threshold_25pct,
            "sign": "positive" if val > 0 else "negative"
        })
edges_df = pd.DataFrame(records)
edges_df.to_csv(os.path.join(output_dir, "precision_matrix_all_pairs.csv"), index=False)
print("Precision table saved to CSV.")

# =========================
# ネットワーク可視化（無向グラフ）
# =========================
mask = np.abs(inv_cov) >= threshold_25pct
np.fill_diagonal(mask, 0)
G = nx.from_numpy_array(inv_cov * mask)
G = nx.relabel_nodes(G, dict(enumerate(cols)))

# ノード重要度（簡易指標）
importance = {node: np.sum(np.abs(inv_cov[i])) for i, node in enumerate(cols)}

plt.figure(figsize=(14, 14))
pos = nx.spring_layout(G, seed=42, k=0.8)
edges = G.edges(data=True)

edge_colors = ["green" if d["weight"] > 0 else "violet" for (_, _, d) in edges]
edge_widths = [abs(d["weight"]) * 5 for (_, _, d) in edges]
node_sizes = [importance[n] * 50 for n in G.nodes()]
node_colors = ["lightblue" if n.startswith("B_") else "lightgreen" if n.startswith("E_") else "gray" for n in G.nodes()]

nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, edgecolors="black", linewidths=0.5)
nx.draw_networkx_edges(G, pos, width=edge_widths, edge_color=edge_colors, alpha=0.7)
nx.draw_networkx_labels(G, pos, font_size=12, font_family="Helvetica")

legend_elements = [
    Line2D([0], [0], color='green', lw=2, label='Positive edge'),
    Line2D([0], [0], color='violet', lw=2, label='Negative edge'),
    Line2D([0], [0], marker='o', color='w', label='Bacterial (B_)', markerfacecolor='lightblue', markersize=12),
    Line2D([0], [0], marker='o', color='w', label='Eukaryotic (E_)', markerfacecolor='lightgreen', markersize=12),
    Line2D([0], [0], marker='o', color='w', label='High importance', markerfacecolor='yellow', markersize=20),
    Line2D([0], [0], marker='o', color='w', label='Low importance', markerfacecolor='yellow', markersize=10),
]

plt.legend(handles=legend_elements, loc='upper right', fontsize=12)
plt.title("Precision matrix-based Network (Top 25% Precision)", fontsize=20)
plt.axis("off")
plt.tight_layout()
plt.savefig(os.path.join(output_dir, "Network_top25pct_with_legend.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(output_dir, "Network_top25pct_with_legend.pdf"), bbox_inches="tight")
plt.close()
print("Network saved to PNG and PDF.")

# =========================
# Bipartite Graph（上位25%のみ）
# =========================
top_edges = edges_df[edges_df["above_top25pct"]].copy()
if not top_edges.empty:
    left_nodes = sorted(set(top_edges["node_1"]))
    right_nodes = sorted(set(top_edges["node_2"]))

    B = nx.Graph()
    B.add_nodes_from(left_nodes, bipartite=0)
    B.add_nodes_from(right_nodes, bipartite=1)
    for _, row in top_edges.iterrows():
        B.add_edge(row["node_1"], row["node_2"], weight=row["precision_ij"])

    pos = {}
    pos.update({n: (0, i) for i, n in enumerate(left_nodes)})
    pos.update({n: (1, i) for i, n in enumerate(right_nodes)})

    edge_widths = [abs(d["weight"])*5 for (_, _, d) in B.edges(data=True)]
    edge_colors = ["green" if d["weight"] > 0 else "violet" for (_, _, d) in B.edges(data=True)]

    plt.figure(figsize=(12, 8))
    nx.draw_networkx_nodes(B, pos, nodelist=left_nodes, node_color="skyblue", node_size=700)
    nx.draw_networkx_nodes(B, pos, nodelist=right_nodes, node_color="lightgreen", node_size=700)
    nx.draw_networkx_edges(B, pos, width=edge_widths, edge_color=edge_colors, alpha=0.7)
    nx.draw_networkx_labels(B, pos, font_size=12, font_family="Helvetica")

    legend_elements_bipartite = [
        Line2D([0], [0], color='green', lw=2, label='Positive edge'),
        Line2D([0], [0], color='violet', lw=2, label='Negative edge'),
        Line2D([0], [0], marker='o', color='w', label='Left nodes', markerfacecolor='skyblue', markersize=12),
        Line2D([0], [0], marker='o', color='w', label='Right nodes', markerfacecolor='lightgreen', markersize=12),
    ]
    plt.legend(handles=legend_elements_bipartite, loc='upper right', fontsize=12)

    plt.title("Bipartite Network (Top 25% Precision)", fontsize=20)
    plt.axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "Bipartite_top25pct_with_legend.png"), dpi=300, bbox_inches="tight")
    plt.savefig(os.path.join(output_dir, "Bipartite_top25pct_with_legend.pdf"), bbox_inches="tight")
    plt.close()
    print("Bipartite network saved to PNG and PDF.")
else:
    print("No top 25% edges for Bipartite graph.")

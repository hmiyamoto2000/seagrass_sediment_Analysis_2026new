# =============================================================================
# Supplementary Fig. S24 — Robustness of the holobiont network across
#                          SEM fit-criteria stringency
# -----------------------------------------------------------------------------
# (a) Per-variable inclusion frequency in universal models, under three
#     stringency scenarios (Current / Excellent / MostStrict).
# (b) Median standardised path coefficient (beta) for Seagrass -> downstream.
#
# 併読図: Supplementary Fig. S22（シナリオの定義とモデル数）
#
# -----------------------------------------------------------------------------
# 旧版からの変更点:
#   1. 図番号を FIG 定数に統一
#      旧版はヘッダ "S19" / 出力ファイル "S23" / 実際の図 "S24" が混在していた
#   2. B_bacterium_enrichment_culture_clone_22_2013 の短縮ラベルを
#      bct22 -> Sva22 に変更（LAB_SVA22 で一括管理）
#   3. パネルの subtitle を図の内容に合わせて修正
#      旧版は "Top hubs maintain high frequency across all stringency levels"
#      と書いていたが、E_Diat は MostStrict で 0% になるため事実と異なる
#   4. ヘッダの "Fig. 5c" -> "Fig. 6c"
#   5. rename(variable = all_vars, n = n) の自己リネームを削除
#   6. フォントサイズを冒頭の定数に集約（目盛り 8.8 -> 10、凡例 8 -> 10）
#
# 入力（作業ディレクトリに置くこと）:
#   phase5c_full_fit.csv         WLSMV-fitted SEMs
#   phase6d_universality.csv     Region x Seagrass interaction test
#   phase6b_full_path_coefs.csv  Standardised path coefficients
# =============================================================================

FIG   <- "S24"   # 補足図番号。出力ファイル名がこれに従う
FIG_W <- 14      # width  in inches
FIG_H <- 10      # height in inches

# ---- フォントサイズ（紙面 pt。100% 配置時の実寸）----------------------------
FONT_BASE   <- 14   # ベース
FONT_TICK   <- 14   # 軸の目盛りラベル（X軸の変数名・Y軸の数値）  旧 8.8
FONT_AXIS   <- 16   # 軸タイトル
FONT_LEGEND <- 14   # 凡例の文字                                  旧 8
FONT_TITLE  <- 16   # パネルタイトル (a) / (b)
FONT_SUB    <- 9    # パネル副題

# B_bacterium_enrichment_culture_clone_22_2013 の表示名。
# SILVA 上は Sva0485 (clone 22) に相当するため bct22 から変更。
# データの列名は変更しないこと（ここは表示ラベルのみ）。
LAB_SVA22 <- "B_Sva22"

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(ggplot2); library(tidyr)
  library(stringr); library(gridExtra); library(grid); library(scales)
})

# -------------------------------------------------------------------
# 1. Load inputs
# -------------------------------------------------------------------
fit <- read_csv("phase5c_full_fit.csv", show_col_types = FALSE) %>%
  filter(converged)
uni <- read_csv("phase6d_universality.csv",   show_col_types = FALSE)
pe  <- read_csv("phase6b_full_path_coefs.csv", show_col_types = FALSE)

cat("Loaded:\n")
cat(sprintf("  phase5c_full_fit.csv         (converged): %d rows\n", nrow(fit)))
cat(sprintf("  phase6d_universality.csv               : %d rows\n", nrow(uni)))
cat(sprintf("  phase6b_full_path_coefs.csv            : %d rows\n", nrow(pe)))

# -------------------------------------------------------------------
# 2. Scenario definitions (Supplementary Fig. S22 と同一)
# -------------------------------------------------------------------
scenarios <- list(
  Current = list(
    p     = 0.10, cfi = 0.95, tli = 0.95, rmsea = 0.06,
    srmr  = 0.08, wrmr = 1.00, gfi = 0.95, agfi = 0.95
  ),
  Excellent = list(
    p     = 0.20, cfi = 0.97, tli = 0.95, rmsea = 0.06,
    srmr  = 0.06, wrmr = 0.80, gfi = 0.95, agfi = 0.95
  ),
  MostStrict = list(
    p     = 0.30, cfi = 0.97, tli = 0.95, rmsea = 0.05,
    srmr  = 0.05, wrmr = 0.60, gfi = 0.97, agfi = 0.95
  )
)

# -------------------------------------------------------------------
# 3. Filtering helpers
# -------------------------------------------------------------------
apply_filter <- function(s) {
  fit %>% filter(
    pvalue >= s$p,
    cfi    >= s$cfi,
    tli    >= s$tli,
    rmsea  <= s$rmsea,
    srmr   <= s$srmr,
    wrmr   <= s$wrmr,
    gfi    >= s$gfi,
    agfi   >= s$agfi,
    sr1_p  <  0.05,
    sr2_p  <  0.05
  )
}

get_universal <- function(qualified) {
  qualified %>%
    inner_join(
      uni %>% select(sr1, sr2, downset, n_universal, k),
      by = c("sr1", "sr2", "downset", "k")
    ) %>%
    filter(n_universal == k)
}

universal_sets <- lapply(scenarios, function(s) {
  get_universal(apply_filter(s))
})

cat("\nUniversal model counts per scenario:\n")
for (name in names(universal_sets)) {
  cat(sprintf("  %s: %d\n", name, nrow(universal_sets[[name]])))
}

# -------------------------------------------------------------------
# 4. Panel a: per-variable inclusion frequency
# -------------------------------------------------------------------
get_downstream_freq <- function(univ_set) {
  if (nrow(univ_set) == 0) return(tibble())
  all_vars <- unlist(strsplit(univ_set$downset, split = "|", fixed = TRUE))
  total <- nrow(univ_set)
  table(all_vars) %>%
    as_tibble() %>%
    rename(variable = all_vars) %>%
    mutate(freq = 100 * n / total)
}

freq_list <- lapply(names(universal_sets), function(name) {
  get_downstream_freq(universal_sets[[name]]) %>%
    mutate(Scenario = name)
})
freq_all <- bind_rows(freq_list) %>%
  mutate(Scenario = factor(Scenario,
                           levels = c("Current", "Excellent", "MostStrict")))

# --- Fill missing variable x scenario combinations with zero -----------------
# table() は出現 0 の変数を落とすため、あるシナリオに存在しない変数は行自体が
# 生成されない。position_dodge ではその分だけ残りの棒が太くなってしまう。
# complete() で変数 x シナリオの全格子を復元し、欠けた組み合わせを freq = 0
# として描く（E_Diat の MostStrict がこれに該当）。
freq_all <- freq_all %>%
  complete(variable, Scenario, fill = list(n = 0, freq = 0))

cat("\nFour core hubs (Fig. 6c):\n")
print(freq_all %>%
        filter(variable %in% c("E_Corallinophycidae", "E_Intramacronucleata",
                               "B_Desulfobulbaceae", "E_Diatomea")) %>%
        arrange(variable, Scenario), n = 50)

# Variable order from the Current scenario (descending by frequency)
var_order <- freq_all %>%
  filter(Scenario == "Current") %>%
  arrange(desc(freq)) %>%
  pull(variable)
freq_all$variable <- factor(freq_all$variable, levels = var_order)

short_labels <- c(
  "E_Corallinophycidae"                          = "E_Cral",
  "E_Intramacronucleata"                         = "E_Intra",
  "E_Diatomea"                                   = "E_Diat",
  "B_Desulfobulbaceae"                           = "B_Dslf",
  "B_Hyphomonadaceae"                            = "B_Hyph",
  "B_Defluviitaleaceae"                          = "B_Dflv",
  "B_uncultured_Aminicenantes_bacterium"         = "B_Amini",
  "B_bacterium_enrichment_culture_clone_22_2013" = LAB_SVA22,
  "chemical_NO3_N_log"                           = "NO3-N",
  "chemical_CEC_log"                             = "CEC",
  "chemical_P2O5_log"                            = "P2O5",
  "chemical_CaO_log"                             = "CaO"
)

# 短縮名の取りこぼし検出（levels に無い変数があると NA ラベルになる）
.missing <- setdiff(levels(freq_all$variable), names(short_labels))
if (length(.missing))
  stop("short_labels に未登録の変数があります: ", paste(.missing, collapse = ", "))

levels(freq_all$variable) <- short_labels[levels(freq_all$variable)]

# 2パネル共通のテーマ
theme_panel <- function() {
  theme_classic(base_size = FONT_BASE) +
    theme(
      panel.grid           = element_blank(),
      plot.title           = element_text(size = FONT_TITLE, face = "bold"),
      plot.subtitle        = element_text(size = FONT_SUB, color = "grey40"),
      axis.title           = element_text(size = FONT_AXIS),
      axis.text            = element_text(size = FONT_TICK),   # y の数値
      axis.text.x          = element_text(angle = 45, hjust = 1),  # size は継承
      legend.position      = c(0.98, 1.02),
      legend.justification = c("right", "bottom"),
      legend.direction     = "horizontal",
      legend.title         = element_blank(),
      legend.background    = element_rect(fill = alpha("white", 0.8), color = NA),
      legend.text          = element_text(size = FONT_LEGEND),
      legend.key.size      = unit(1.0, "lines")
    )
}

pA <- ggplot(freq_all, aes(x = variable, y = freq, fill = Scenario)) +
  geom_col(position = position_dodge(width = 0.85), width = 0.75) +
  scale_fill_manual(values = c("Current"    = "steelblue",
                               "Excellent"  = "darkorange",
                               "MostStrict" = "firebrick")) +
  scale_y_continuous(limits = c(0, NA),
                     expand = expansion(mult = c(0, 0.15))) +
  labs(
    x        = "Downstream variable",
    y        = "Inclusion frequency (% of Universal models)",
    title    = "(a)  Inclusion frequency of each downstream variable",
    subtitle = paste("Three of the four core hubs are retained under all scenarios;",
                     "E_Diat falls to zero under MostStrict")
  ) +
  theme_panel()

# -------------------------------------------------------------------
# 5. Panel b: median standardised path coefficient
# -------------------------------------------------------------------
get_downstream_beta <- function(univ_set, label) {
  if (nrow(univ_set) == 0) return(tibble())
  pe %>%
    inner_join(univ_set %>% select(sr1, sr2, downset),
               by = c("sr1", "sr2", "downset")) %>%
    filter(op == "~", rhs == "Seagrass") %>%
    group_by(lhs) %>%
    summarise(median_beta = median(std.all, na.rm = TRUE), .groups = "drop") %>%
    rename(variable = lhs) %>%
    mutate(Scenario = label)
}

beta_list <- lapply(names(universal_sets), function(name) {
  get_downstream_beta(universal_sets[[name]], name)
})
# 注: パネル a と異なり complete() しない。あるシナリオで採用されなかった変数は
#     beta が存在しないため、点を打たないのが正しい（0 ではない）。
beta_all <- bind_rows(beta_list) %>%
  mutate(
    Scenario = factor(Scenario,
                      levels = c("Current", "Excellent", "MostStrict")),
    variable = factor(variable, levels = var_order)
  )
levels(beta_all$variable) <- short_labels[levels(beta_all$variable)]

pB <- ggplot(beta_all,
             aes(x = variable, y = median_beta,
                 color = Scenario, group = Scenario)) +
  geom_hline(yintercept = 0, color = "grey50", linetype = "dashed") +
  geom_point(size = 3.5, position = position_dodge(width = 0.5)) +
  scale_color_manual(values = c("Current"    = "steelblue",
                                "Excellent"  = "darkorange",
                                "MostStrict" = "firebrick")) +
  labs(
    x        = "Downstream variable",
    y        = "Median std beta (Seagrass -> downstream)",
    title    = "(b)  Standardised path coefficient stability",
    subtitle = paste("For every variable that is retained, magnitude and sign of beta",
                     "are preserved; absent variables have no point")
  ) +
  theme_panel()

# -------------------------------------------------------------------
# 6. Layout
# -------------------------------------------------------------------
fig <- arrangeGrob(
  pA, pB,
  ncol = 1, heights = c(1.0, 1.0),
  top = textGrob(
    "Robustness of the holobiont network across SEM fit-criteria stringency",
    gp = gpar(fontsize = FONT_TITLE, fontface = "bold")
  )
)

# ── Source Data export ───────────────────────────────────────────────────────
write_csv(freq_all, sprintf("Supp_Fig_%s_panel_a_inclusion_frequency.csv", FIG))
write_csv(beta_all, sprintf("Supp_Fig_%s_panel_b_path_coefficient.csv",    FIG))
cat(sprintf("Saved Source Data: Supp_Fig_%s_panel_a_inclusion_frequency.csv, Supp_Fig_%s_panel_b_path_coefficient.csv\n",
            FIG, FIG))

pdf(sprintf("Supp_Fig_%s.pdf", FIG), width = FIG_W, height = FIG_H)
grid.draw(fig)
dev.off()

png(sprintf("Supp_Fig_%s.png", FIG),
    width = FIG_W * 300, height = FIG_H * 300, res = 300)
grid.draw(fig)
dev.off()

if (file.exists("Rplots.pdf")) file.remove("Rplots.pdf")

cat(sprintf("\nSaved Supp_Fig_%s.pdf and .png (%g x %g inches)\n", FIG, FIG_W, FIG_H))

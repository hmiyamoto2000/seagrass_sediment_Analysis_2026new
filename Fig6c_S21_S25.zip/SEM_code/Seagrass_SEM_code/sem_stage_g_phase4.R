#!/usr/bin/env Rscript
# Stage gamma Phase 4: exhaustive downstream combination search
# - SR pairs: 6 qualified (Phase 2 / Phase 3a)
# - downstream pool: 18 SR-stable factors (chem 9 + biome 9)
# - k = 1..7, total ~247,356 fits
# - WLSMV, ordered="Seagrass", furrr 24 workers
# - chunked output: phase4_results_chunk_NNN.csv to survive partial failure
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT     <- "/Fig6"
DATA_IN  <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
Q_CSV    <- file.path(ROOT, "phase2_qualified6_pairs.csv")
OUT_DIR  <- file.path(ROOT, "phase4_chunks")
dir.create(OUT_DIR, showWarnings = FALSE)
SUMMARY  <- file.path(ROOT, "phase4_combined_results.csv")

dat  <- read_csv(DATA_IN, show_col_types = FALSE)
qual <- read_csv(Q_CSV,   show_col_types = FALSE) %>% select(sr1, sr2)
cat(sprintf("[Phase4] Pairs: %d   Data: %d rows\n", nrow(qual), nrow(dat)))

POOL <- c(
  "chemical_TC_log","chemical_TN_log","chemical_NH4_N_log","chemical_NO3_N_log",
  "chemical_P2O5_log","chemical_CaO_log","chemical_K2O_log","chemical_CEC_log","chemical_Zn_log",
  "B_Desulfobulbaceae","B_Hyphomonadaceae","B_Defluviitaleaceae","B_BD7_8",
  "B_bacterium_enrichment_culture_clone_22_2013","B_uncultured_Aminicenantes_bacterium",
  "E_Corallinophycidae","E_Intramacronucleata","E_Diatomea"
)
K_MAX <- 7

# ---- generate all combinations -------------------------------------------
all_combos <- list()
for (k in 1:K_MAX) {
  cb <- combn(POOL, k, simplify = FALSE)
  all_combos <- c(all_combos, cb)
}
n_combo <- length(all_combos)
n_total <- n_combo * nrow(qual)
cat(sprintf("[Phase4] Combinations: %d  x  %d pairs  =  %d fits\n",
            n_combo, nrow(qual), n_total))

# ---- fit function --------------------------------------------------------
fit_one <- function(sr1, sr2, downset, dat) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  rhs <- paste(downset, collapse = " + ")
  mod <- sprintf("Seagrass ~ .SR1 + .SR2\n%s ~ Seagrass", rhs)
  res <- tryCatch({
    fit <- suppressWarnings(lavaan::sem(mod, data = d, ordered = "Seagrass",
                       estimator = "WLSMV", se = "robust"))
    if (!isTRUE(lavaan::lavInspect(fit, "converged")))
      return(tibble(converged = FALSE))
    fm <- lavaan::fitMeasures(fit, c("chisq.scaled","df","pvalue.scaled",
            "cfi.scaled","tli.scaled","rmsea.scaled","srmr","wrmr"))
    pe <- lavaan::parameterEstimates(fit, standardized = TRUE)
    g  <- function(lhs, rhs) {
      r <- pe[pe$lhs==lhs & pe$op=="~" & pe$rhs==rhs, ]
      if (nrow(r)==0) c(NA, NA) else c(r$std.all[1], r$pvalue[1])
    }
    s1 <- g("Seagrass", ".SR1"); s2 <- g("Seagrass", ".SR2")
    down_p <- map(downset, ~ g(.x, "Seagrass"))
    n_sig  <- sum(map_dbl(down_p, ~ .x[2]) < 0.05, na.rm = TRUE)
    tibble(converged = TRUE,
           k = length(downset),
           chisq = unname(fm["chisq.scaled"]), df = unname(fm["df"]),
           pvalue = unname(fm["pvalue.scaled"]),
           cfi = unname(fm["cfi.scaled"]), tli = unname(fm["tli.scaled"]),
           rmsea = unname(fm["rmsea.scaled"]),
           srmr = unname(fm["srmr"]), wrmr = unname(fm["wrmr"]),
           sr1_std = s1[1], sr1_p = s1[2],
           sr2_std = s2[1], sr2_p = s2[2],
           n_down_sig = n_sig)
  }, error = function(e) tibble(converged = FALSE))
  res$sr1 <- sr1; res$sr2 <- sr2
  res$downset <- paste(downset, collapse = "|")
  res
}

# ---- chunked parallel run ------------------------------------------------
plan(multisession, workers = 24)
CHUNK <- 2000   # combos per chunk; chunk size of fits = CHUNK * 6 pairs = 12k
chunks <- split(seq_along(all_combos), ceiling(seq_along(all_combos) / CHUNK))
cat(sprintf("[Phase4] %d chunks of up to %d combos each\n", length(chunks), CHUNK))

t0 <- Sys.time()
for (ci in seq_along(chunks)) {
  out_path <- file.path(OUT_DIR, sprintf("phase4_chunk_%03d.csv", ci))
  if (file.exists(out_path)) {
    cat(sprintf("[chunk %3d/%d] skip (exists)\n", ci, length(chunks))); next
  }
  combos_ci <- all_combos[chunks[[ci]]]
  jobs <- expand.grid(combo_idx = seq_along(combos_ci),
                      pair_idx  = seq_len(nrow(qual)),
                      KEEP.OUT.ATTRS = FALSE)
  res <- future_map_dfr(seq_len(nrow(jobs)), function(j) {
    ci2 <- jobs$combo_idx[j]; pi <- jobs$pair_idx[j]
    fit_one(qual$sr1[pi], qual$sr2[pi], combos_ci[[ci2]], dat)
  }, .options = furrr_options(seed = TRUE))
  write_csv(res, out_path)
  el <- as.numeric(Sys.time() - t0, units = "mins")
  pct <- ci / length(chunks) * 100
  cat(sprintf("[chunk %3d/%d] %d fits, elapsed %.1f min, %.1f%% done\n",
              ci, length(chunks), nrow(res), el, pct))
}

# ---- combine -------------------------------------------------------------
cat("[Phase4] Combining chunks...\n")
all_files <- list.files(OUT_DIR, pattern = "^phase4_chunk_.*\\.csv$", full.names = TRUE)
combined <- map_dfr(all_files, ~ read_csv(.x, show_col_types = FALSE))
write_csv(combined, SUMMARY)
cat(sprintf("[Phase4] Wrote -> %s (%d rows)\n", SUMMARY, nrow(combined)))

cat(sprintf("[Phase4] Total time: %.1f min\n",
            as.numeric(Sys.time() - t0, units = "mins")))
cat(sprintf("[Phase4] Converged: %d / %d\n",
            sum(combined$converged, na.rm = TRUE), nrow(combined)))

cat("\n=== Phase 4 complete ===\n")

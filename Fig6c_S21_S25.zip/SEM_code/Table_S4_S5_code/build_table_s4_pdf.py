"""
build_table_s4_pdf.py
=====================
Generate the A4 print version of Supplementary Table S4 for the seagrass
holobiont paper, styled to match Tables S1-S3 (Nature Ecology & Evolution
minimalist convention: white background, horizontal rules only, no fills).

Two A4 pages (landscape):
  Page 1  Table S4a  Variable composition of biome SR formulas
          Table S4b  Variable composition of chem  SR formulas
  Page 2  Table S4c  Variable prevalence (biome + chem side by side)
          Table S4d  Six SR pairs forwarded to exhaustive SEM enumeration

Style conventions (matching the project's existing Supplementary Tables):
  - Arial sans-serif throughout
  - Black text on white background, no cell fills, no vertical rules
  - Header row: bold, separated by horizontal rules above and below
  - Significance/qualified status indicated by a single asterisk in a
    "sig" column (S1/S2 convention)
  - dpi = 300, pdf.fonttype = 42 (TrueType embed for journal compliance)

Inputs (place in INPUT_DIR):
  - hall_of_fame_<depth>depth.csv      (biome, depth = 5..10)
  - hall_of_fame_depth<depth>.csv      (chem,  depth = 5..10)
  - phase1_sr_pair_results.csv
  - phase2_qualified6_pairs.csv

Output:
  - Table_S4.pdf                       (multi-page, vector)
  - Table_S4_p1.png, Table_S4_p2.png   (300 dpi raster previews)
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

# ----------------------------------------------------------------------
# Style — minimalist Nature-style supplementary tables
# ----------------------------------------------------------------------
mpl.rcParams.update({
    "font.family":     "Arial",
    "pdf.fonttype":    42,
    "ps.fonttype":     42,
    "savefig.dpi":     300,
    "axes.linewidth":  0.5,
})

TEXT       = "#000000"
RULE_HEAVY = "#000000"   # outer horizontal rules
RULE_LIGHT = "#888888"   # group-header sub-rule

A4_W, A4_H = 11.69, 8.27

# ----------------------------------------------------------------------
# Reuse data parsing from build_table_s4.py
# ----------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).resolve().parent))
from build_table_s4 import (  # noqa: E402
    BIOME_VARS, CHEM_VARS, BIOME_SHORT, CHEM_SHORT,
    PHASE2_GLOB,
    load_hall_of_fame, build_records, find_file,
)

INPUT_DIR      = Path(".")
OUT_PDF        = Path("Table_S4.pdf")
OUT_PNG_PREFIX = Path("Table_S4")

# Compact display labels for biome variables in the matrix headers.
# Full taxonomic names appear in the page footnote.
BIOME_MATRIX_LABEL = {
    "B_Desulfobulbaceae":                            "Desulfo",
    "B_Hyphomonadaceae":                             "Hypho",
    "B_Defluviitaleaceae":                           "Defluv",
    "B_BD7_8":                                       "BD7-8",
    "B_uncultured_Aminicenantes_bacterium":          "Amini",
    "B_bacterium_enrichment_culture_clone_22_2013":  "bct22",
    "E_Corallinophycidae":                           "Coralli",
    "E_Intramacronucleata":                          "Intramacro",
    "E_Diatomea":                                    "Diatomea",
}


# ----------------------------------------------------------------------
# Minimalist table renderer
# ----------------------------------------------------------------------
def draw_table(
    ax, *,
    x0: float, y_top: float,
    col_widths: list[float],
    headers: list[str],
    rows: list[list],
    body_align: list[str] | None = None,
    row_height: float = 0.024,
    header_height: float = 0.028,
    header_fontsize: float = 8.0,
    body_fontsize: float = 7.5,
) -> float:
    """Draw a Nature-style minimalist table.
    Layout: top rule → header row → header bottom rule → body rows → bottom rule.
    No vertical rules, no cell fills.
    Returns the y-coordinate of the bottom rule.
    """
    n_cols = len(col_widths)
    if body_align is None:
        body_align = ["center"] * n_cols
    total_width = sum(col_widths)

    # Column x-positions (left edges)
    col_x = [x0]
    for w in col_widths:
        col_x.append(col_x[-1] + w)

    # ---- Top rule ----
    ax.plot([x0, x0 + total_width], [y_top, y_top],
            color=RULE_HEAVY, lw=0.7, transform=ax.transAxes,
            solid_capstyle="butt")

    # ---- Header row ----
    hdr_bottom = y_top - header_height
    for j, h_text in enumerate(headers):
        cx = col_x[j]
        w  = col_widths[j]
        ha = body_align[j]
        tx = cx + (0.005 if ha == "left"
                    else (w - 0.005 if ha == "right" else w / 2))
        ax.text(tx, hdr_bottom + header_height / 2, h_text,
                ha=ha, va="center",
                fontsize=header_fontsize, fontweight="bold",
                color=TEXT, transform=ax.transAxes)

    # ---- Sub-rule beneath header ----
    ax.plot([x0, x0 + total_width], [hdr_bottom, hdr_bottom],
            color=RULE_HEAVY, lw=0.4, transform=ax.transAxes,
            solid_capstyle="butt")

    # ---- Body rows ----
    cy = hdr_bottom
    for row in rows:
        cy -= row_height
        for j, val in enumerate(row):
            cx = col_x[j]
            w  = col_widths[j]
            ha = body_align[j]
            tx = cx + (0.005 if ha == "left"
                        else (w - 0.005 if ha == "right" else w / 2))
            txt = "" if val is None or (isinstance(val, str) and val == "") \
                  else str(val)
            ax.text(tx, cy + row_height / 2, txt,
                    ha=ha, va="center",
                    fontsize=body_fontsize, color=TEXT,
                    transform=ax.transAxes)

    # ---- Bottom rule ----
    ax.plot([x0, x0 + total_width], [cy, cy],
            color=RULE_HEAVY, lw=0.7, transform=ax.transAxes,
            solid_capstyle="butt")

    return cy


# ----------------------------------------------------------------------
# Data preparation helpers
# ----------------------------------------------------------------------
def matrix_to_rows(df: pd.DataFrame, vars_list: list[str], short_map: dict):
    """Compose row-strings for a variable × formula occurrence matrix.
    Empty string for absent variables (count = 0); * marker for qualified."""
    df = df.sort_values(["depth", "complexity"]).reset_index(drop=True)
    rows = []
    for _, rec in df.iterrows():
        row = [
            rec["formula_id"],
            int(rec["depth"]),
            int(rec["complexity"]),
            f"{rec['loss']:.4f}",
            int(rec["n_unique_vars"]),
        ]
        for v in vars_list:
            cnt = int(rec[v])
            row.append(str(cnt) if cnt > 0 else "")
        # Qualified marker: '*' (consistent with S1/S2 'sig' column convention)
        row.append("*" if rec["in_qualified_6_pairs"] else "")
        rows.append(row)

    headers = ["formula_id", "depth", "compl.", "loss", "n_var"]
    headers += [short_map[v] for v in vars_list]
    headers.append("sig")
    return headers, rows


# ----------------------------------------------------------------------
# Page builders
# ----------------------------------------------------------------------
def render_page1(pdf, biome_df: pd.DataFrame, chem_df: pd.DataFrame) -> None:
    """Page 1: Title + caption + S4a (biome) + S4b (chem)."""
    fig = plt.figure(figsize=(A4_W, A4_H))
    ax  = fig.add_axes([0.04, 0.04, 0.92, 0.92])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    # ---- Title (matches S1-S3: "Table SX" then bold descriptive line) ----
    ax.text(0.0, 0.985, "Table S4",
            ha="left", va="top", fontsize=12, fontweight="bold",
            transform=ax.transAxes)
    ax.text(0.0, 0.96,
            "Symbolic regression formula composition for the SEM pipeline",
            ha="left", va="top", fontsize=10.5, fontweight="bold",
            transform=ax.transAxes)

    # ---- Caption ----
    caption = (
        "PySR was run on (a) 16S/18S CLR-transformed biome features and "
        "(b) log-transformed chemical features across tree depth = 5–10. "
        "For each depth, complexity 27 and 29 formulas were retained, "
        "yielding 12 biome and 11 chem candidate formulas (one chem formula, "
        "SR_chem_d6_c29, did not reach complexity 29 on the Pareto front). "
        "Cell entries indicate the number of times each variable token "
        "occurs in the equation (blank = absent). The \"sig\" column marks "
        "formulas appearing in the six pairs forwarded to exhaustive SEM "
        "enumeration."
    )
    ax.text(0.0, 0.93, caption, ha="left", va="top", fontsize=8,
            wrap=True, transform=ax.transAxes)

    # ---- Layout for the 9-variable matrices ----
    # formula_id | depth | compl. | loss | n_var | 9 var cols | sig
    cw = [0.13, 0.030, 0.045, 0.052, 0.045] + [0.058] * 9 + [0.030]
    body_align = (["left"] + ["center"] * 4
                  + ["center"] * 9 + ["center"])

    # ---- Table S4a biome ----
    ax.text(0.0, 0.85, "(a)  Biome SR formulas",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)
    headers, rows = matrix_to_rows(biome_df, BIOME_VARS, BIOME_MATRIX_LABEL)
    bottom_a = draw_table(
        ax, x0=0.0, y_top=0.835,
        col_widths=cw, headers=headers, rows=rows,
        body_align=body_align,
        row_height=0.024, header_height=0.030,
    )

    # ---- Table S4b chem ----
    ax.text(0.0, bottom_a - 0.030, "(b)  Chemical SR formulas",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)
    headers, rows = matrix_to_rows(chem_df, CHEM_VARS, CHEM_SHORT)
    draw_table(
        ax, x0=0.0, y_top=bottom_a - 0.045,
        col_widths=cw, headers=headers, rows=rows,
        body_align=body_align,
        row_height=0.024, header_height=0.030,
    )

    # ---- Footnote: full names + abbreviation key ----
    foot_lines = [
        "Biome column abbreviations:  Desulfo, B_Desulfobulbaceae;  Hypho, "
        "B_Hyphomonadaceae;  Defluv, B_Defluviitaleaceae;  BD7-8, B_BD7-8;  "
        "Amini, B_uncultured_Aminicenantes_bacterium;",
        "bct22, B_bacterium_enrichment_culture_clone_22(2013);  Coralli, "
        "E_Corallinophycidae;  Intramacro, E_Intramacronucleata;  Diatomea, "
        "E_Diatomea.",
        "Chemical variables (TC, TN, CaO, CEC, K2O, NH4-N, NO3-N, P2O5, Zn) "
        "are log-transformed.  *, qualified for exhaustive SEM enumeration.",
    ]
    for i, line in enumerate(foot_lines):
        ax.text(0.0, 0.045 - i * 0.016, line,
                ha="left", va="bottom", fontsize=7,
                color=TEXT, transform=ax.transAxes)

    pdf.savefig(fig, bbox_inches=None)
    fig.savefig(f"{OUT_PNG_PREFIX}_p1.png", dpi=300, bbox_inches=None)
    plt.close(fig)


def render_page2(pdf, biome_df: pd.DataFrame, chem_df: pd.DataFrame,
                 phase2: pd.DataFrame) -> None:
    """Page 2: prevalence summary + 6 qualified pairs."""
    fig = plt.figure(figsize=(A4_W, A4_H))
    ax  = fig.add_axes([0.04, 0.04, 0.92, 0.92])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    # ---- Title ----
    ax.text(0.0, 0.985, "Table S4",
            ha="left", va="top", fontsize=12, fontweight="bold",
            transform=ax.transAxes)
    ax.text(0.0, 0.96, "(continued)",
            ha="left", va="top", fontsize=10.5, fontweight="bold",
            transform=ax.transAxes)

    # ----------------------------------------------------------------
    # (c) Variable prevalence — biome and chem panels side by side
    # ----------------------------------------------------------------
    ax.text(0.0, 0.92,
            "(c)  Variable prevalence across SR candidate formulas",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)

    def prevalence_rows(df: pd.DataFrame, vars_list: list[str],
                        n_formulas: int, name_map: dict[str, str]):
        out = []
        for v in vars_list:
            n_pres = int((df[v] > 0).sum())
            total  = int(df[v].sum())
            mean_  = total / n_pres if n_pres else 0
            cls = ("universal" if n_pres == n_formulas else
                   "high"      if n_pres >= 0.8 * n_formulas else
                   "moderate"  if n_pres >= 0.45 * n_formulas else
                   "low")
            out.append((name_map[v], n_pres, n_formulas, total, mean_, cls))
        out.sort(key=lambda r: (-r[1], -r[3]))
        return out

    bio_prev  = prevalence_rows(biome_df, BIOME_VARS, 12, BIOME_SHORT)
    chem_prev = prevalence_rows(chem_df,  CHEM_VARS,  11, CHEM_SHORT)

    def to_rows(prev):
        rows = []
        for name, n_p, n_total, total, mean_, cls in prev:
            rows.append([
                name,
                f"{n_p}/{n_total}",
                f"{n_p/n_total:.0%}",
                str(total),
                f"{mean_:.2f}",
                cls,
            ])
        return rows

    cw_prev = [0.155, 0.062, 0.060, 0.060, 0.060, 0.080]
    hdr_prev = ["variable", "present in", "% of f.",
                "total occ.", "mean occ.", "class"]
    body_align_prev = ["left", "center", "center",
                       "center", "center", "center"]

    # Biome panel (left)
    ax.text(0.0, 0.89, "biome (n = 12 candidate formulas)",
            fontsize=8, fontstyle="italic",
            transform=ax.transAxes)
    bottom_bio = draw_table(
        ax, x0=0.0, y_top=0.876,
        col_widths=cw_prev, headers=hdr_prev,
        rows=to_rows(bio_prev),
        body_align=body_align_prev,
        row_height=0.024, header_height=0.028,
    )

    # Chem panel (right)
    ax.text(0.515, 0.89, "chemical (n = 11 candidate formulas)",
            fontsize=8, fontstyle="italic",
            transform=ax.transAxes)
    bottom_chem = draw_table(
        ax, x0=0.515, y_top=0.876,
        col_widths=cw_prev, headers=hdr_prev,
        rows=to_rows(chem_prev),
        body_align=body_align_prev,
        row_height=0.024, header_height=0.028,
    )
    bottom_c = min(bottom_bio, bottom_chem)

    # Interpretation note (italic prose, no box)
    interp = (
        "Six of nine biome variables appear in every one of the 12 candidate "
        "formulas (universal class), consistent with the reproducibility of "
        "the holobiont signal. Among chemical variables, only TC and NH4-N "
        "are universal across all 11 formulas, while CEC was the least "
        "prevalent (4 of 11 formulas; low class), echoing the non-significant "
        "chemical downstream paths in the SEM ensemble (Fig. 5)."
    )
    ax.text(0.0, bottom_c - 0.020, interp,
            ha="left", va="top", fontsize=7.4, fontstyle="italic",
            color=TEXT, wrap=True, transform=ax.transAxes)

    # ----------------------------------------------------------------
    # (d) Six SR pairs forwarded to exhaustive SEM enumeration
    # ----------------------------------------------------------------
    y_d = bottom_c - 0.13
    ax.text(0.0, y_d,
            "(d)  Six SR pairs forwarded to exhaustive SEM enumeration",
            ha="left", va="top", fontsize=9.5, fontweight="bold",
            transform=ax.transAxes)

    cw_pair = [0.18, 0.18, 0.10, 0.07, 0.10, 0.10]
    # 論文表示: SR_score1 = biome (内部 sr2), SR_score2 = chemistry (内部 sr1)
    hdr_pair = ["sr_biome (SR_score1)", "sr_chem (SR_score2)",
                "p-value (χ²)", "CFI", "SRMR", "WRMR"]
    body_align_pair = ["left", "left",
                       "center", "center", "center", "center"]

    p2 = phase2.sort_values("ph2_pvalue", ascending=False).reset_index(drop=True)
    rows_pair = []
    for _, row in p2.iterrows():
        rows_pair.append([
            row["sr2"], row["sr1"],
            f"{row['ph2_pvalue']:.3f}",
            f"{row['ph2_cfi']:.2f}",
            f"{row['ph2_srmr']:.3f}",
            f"{row['ph2_wrmr']:.3f}",
        ])

    draw_table(
        ax, x0=0.0, y_top=y_d - 0.022,
        col_widths=cw_pair, headers=hdr_pair, rows=rows_pair,
        body_align=body_align_pair,
        row_height=0.026, header_height=0.030,
    )

    # ---- Footnote ----
    ax.text(0.0, 0.025,
            "Class thresholds: universal, present in all candidate formulas; "
            "high, ≥ 80%; moderate, ≥ 45%; low, < 45%.",
            ha="left", va="bottom", fontsize=7,
            color=TEXT, transform=ax.transAxes)

    pdf.savefig(fig, bbox_inches=None)
    fig.savefig(f"{OUT_PNG_PREFIX}_p2.png", dpi=300, bbox_inches=None)
    plt.close(fig)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main() -> None:
    folder = INPUT_DIR.resolve()
    print(f"Input folder: {folder}")

    biome_hof = load_hall_of_fame(folder, "biome")
    chem_hof  = load_hall_of_fame(folder, "chem")
    biome_df = pd.DataFrame(build_records(biome_hof, BIOME_VARS, "biome"))
    chem_df  = pd.DataFrame(build_records(chem_hof,  CHEM_VARS,  "chem"))

    phase2 = pd.read_csv(find_file(folder, PHASE2_GLOB))
    qualified_chem  = set(phase2["sr1"])
    qualified_biome = set(phase2["sr2"])
    biome_df["in_qualified_6_pairs"] = biome_df["formula_id"].isin(qualified_biome)
    chem_df ["in_qualified_6_pairs"] = chem_df ["formula_id"].isin(qualified_chem)

    with PdfPages(OUT_PDF) as pdf:
        render_page1(pdf, biome_df, chem_df)
        render_page2(pdf, biome_df, chem_df, phase2)

    print(f"Saved: {OUT_PDF.resolve()}")
    print(f"Saved: {OUT_PNG_PREFIX}_p1.png, {OUT_PNG_PREFIX}_p2.png")


if __name__ == "__main__":
    main()

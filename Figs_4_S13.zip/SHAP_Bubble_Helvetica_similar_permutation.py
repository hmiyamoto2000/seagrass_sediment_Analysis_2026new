#完全コード

#このコードを例として shap_compare.py などに保存すれば、コマンドラインで python3.10 shap_compare.py と実行するだけで、Random Forest、XGBoost、LightGBM の SHAP を一つのグラフで比較可能

#target,feature1,feature2,feature3
#0,10.5,3.2,1
#1,8.1,5.6,0
#0,9.0,2.1,1
#...
#1列目がtarget（0 or 1）

#python3.10 shap_compare.py your_data.csv

# 修正済み shap_compare_fixed.py

# permutation_compare.py
# python3.10 permutation_compare.py your_data.csv

# permutation_compare.py
# 使用方法: python3.10 permutation_compare.py your_data.csv

import sys
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
import lightgbm as lgb
from sklearn.inspection import permutation_importance
from sklearn.metrics import accuracy_score
import matplotlib
import re

# ======== フォント設定 ========
if "Helvetica" in matplotlib.font_manager.findSystemFonts(fontpaths=None, fontext='ttf'):
    matplotlib.rcParams['font.family'] = 'Helvetica'
else:
    matplotlib.rcParams['font.family'] = 'Arial'

# ================ Permutation Importance 計算 =================
def compute_permutation_importance(model, X_test, y_test, model_name, output_dir, n_repeats=30):
    print(f"Computing Permutation Importance for {model_name}...")
    result = permutation_importance(model, X_test, y_test, n_repeats=n_repeats, random_state=42)
    mean_importance = result.importances_mean
    std_importance = result.importances_std

    df = pd.DataFrame({
        'Feature': X_test.columns,
        'Permutation_Importance': mean_importance,
        'PI_SD': std_importance
    }).sort_values(by='Permutation_Importance', ascending=False)

    csv_path = os.path.join(output_dir, f"{model_name}_Permutation.csv")
    df.to_csv(csv_path, index=False)
    print(f"Saved Permutation Importance CSV for {model_name} at {csv_path}")
    return csv_path

# ================ 横棒グラフ =================
def plot_horizontal_bar(csv_path, model_name, output_dir):
    df = pd.read_csv(csv_path)
    df_sorted = df.sort_values(by='Permutation_Importance')
    plt.figure(figsize=(10,6))
    plt.barh(df_sorted['Feature'], df_sorted['Permutation_Importance'], xerr=df_sorted['PI_SD'], color='skyblue', edgecolor='black')
    plt.xlabel('Permutation Importance')
    plt.title(f'{model_name} Permutation Importance (with SD error bars)')
    plt.tight_layout()
    png_path = os.path.join(output_dir, f"{model_name}_PI_horizontal.png")
    pdf_path = os.path.join(output_dir, f"{model_name}_PI_horizontal.pdf")
    plt.savefig(png_path, dpi=300)
    plt.savefig(pdf_path)
    plt.close()
    print(f"Saved horizontal bar plot for {model_name} at:\n  {png_path}\n  {pdf_path}")

# ================ バブルチャート =================
def plot_permutation_bubble_chart(rf_csv, xgb_csv, lgb_csv, output_dir):
    df_rf = pd.read_csv(rf_csv).rename(columns={'Permutation_Importance':'PI_RF'})
    df_xgb = pd.read_csv(xgb_csv).rename(columns={'Permutation_Importance':'PI_XGB'})
    df_lgb = pd.read_csv(lgb_csv).rename(columns={'Permutation_Importance':'PI_LGBM'})

    df_merge = df_rf[['Feature','PI_RF']].merge(
        df_xgb[['Feature','PI_XGB']], on='Feature', how='inner').merge(
        df_lgb[['Feature','PI_LGBM']], on='Feature', how='inner')

    x = df_merge['PI_XGB']
    y = df_merge['PI_RF']
    z = df_merge['PI_LGBM']
    labels = df_merge['Feature']

    # Bubble size: normalize LightGBM PI
    min_size = 50
    max_size = 1000
    if z.max() == z.min():
        sizes = np.full_like(z, (min_size + max_size)/2)
    else:
        norm_sizes = (z - z.min()) / (z.max() - z.min())
        sizes = norm_sizes * (max_size - min_size) + min_size

    cmap = plt.cm.viridis

    # ===== ラベル付き =====
    fig, ax = plt.subplots(figsize=(12,9))
    scatter = ax.scatter(x, y, s=sizes, c=z, cmap=cmap, alpha=0.85, edgecolors='black', linewidths=0.7)
    for i, txt in enumerate(labels):
        ax.annotate(txt, (x.iloc[i], y.iloc[i]), fontsize=8, alpha=0.7, textcoords="offset points", xytext=(5,3))
    cbar = fig.colorbar(scatter)
    cbar.set_label('LightGBM Permutation Importance')
    ax.set_xlabel('XGBoost Permutation Importance')
    ax.set_ylabel('Random Forest Permutation Importance')
    plt.title('Permutation Importance Bubble Chart (variable size/color, with labels)')
    plt.tight_layout()
    png_path = os.path.join(output_dir, "Permutation_bubble_variable_labels.png")
    pdf_path = os.path.join(output_dir, "Permutation_bubble_variable_labels.pdf")
    fig.savefig(png_path, dpi=300, bbox_inches='tight')
    fig.savefig(pdf_path, bbox_inches='tight')
    plt.close()

    # ===== ラベルなし =====
    fig2, ax2 = plt.subplots(figsize=(12,9))
    scatter2 = ax2.scatter(x, y, s=sizes, c=z, cmap=cmap, alpha=0.85, edgecolors='black', linewidths=0.7)
    cbar2 = fig2.colorbar(scatter2)
    cbar2.set_label('LightGBM Permutation Importance')
    ax2.set_xlabel('XGBoost Permutation Importance')
    ax2.set_ylabel('Random Forest Permutation Importance')
    plt.title('Permutation Importance Bubble Chart (variable size/color, no labels)')
    plt.tight_layout()
    png_path2 = os.path.join(output_dir, "Permutation_bubble_variable_no_labels.png")
    pdf_path2 = os.path.join(output_dir, "Permutation_bubble_variable_no_labels.pdf")
    fig2.savefig(png_path2, dpi=300, bbox_inches='tight')
    fig2.savefig(pdf_path2, bbox_inches='tight')
    plt.close()

    print(f"Saved bubble charts to:\n  {png_path}\n  {png_path2}")
    return df_merge

# ============== メイン関数 ==============
def main():
    if len(sys.argv) < 2:
        print("Usage: python permutation_compare.py path_to_your_data.csv")
        sys.exit(1)

    csv_path = sys.argv[1]
    df = pd.read_csv(csv_path)

    target_col = 'target'
    if target_col not in df.columns:
        print(f"Error: target column '{target_col}' not found")
        sys.exit(1)

    X = df.drop(columns=[target_col])
    y = df[target_col]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y)

    output_dir = 'Result_Permutation'
    os.makedirs(output_dir, exist_ok=True)

    # === Random Forest ===
    rf = RandomForestClassifier(random_state=42)
    rf.fit(X_train, y_train)
    print(f"RF Test Accuracy: {accuracy_score(y_test, rf.predict(X_test)):.4f}")
    rf_csv = compute_permutation_importance(rf, X_test, y_test, 'RandomForest', output_dir)
    plot_horizontal_bar(rf_csv, 'RandomForest', output_dir)

    # === XGBoost ===
    xgb_model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42)
    xgb_model.fit(X_train, y_train)
    print(f"XGBoost Test Accuracy: {accuracy_score(y_test, xgb_model.predict(X_test)):.4f}")
    xgb_csv = compute_permutation_importance(xgb_model, X_test, y_test, 'XGBoost', output_dir)
    plot_horizontal_bar(xgb_csv, 'XGBoost', output_dir)

    # === LightGBM ===
    lgb_model = lgb.LGBMClassifier(random_state=42)
    lgb_model.fit(X_train, y_train)
    print(f"LightGBM Test Accuracy: {accuracy_score(y_test, lgb_model.predict(X_test)):.4f}")
    lgb_csv = compute_permutation_importance(lgb_model, X_test, y_test, 'LightGBM', output_dir)
    plot_horizontal_bar(lgb_csv, 'LightGBM', output_dir)

    # === バブルチャート ===
    plot_permutation_bubble_chart(rf_csv, xgb_csv, lgb_csv, output_dir)

if __name__ == '__main__':
    main()

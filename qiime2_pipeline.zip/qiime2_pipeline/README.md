# QIIME2 amplicon-processing pipeline

Upstream sequence processing for the seagrass sediment microbiome study:
raw MiSeq reads → amplicon sequence variants (ASVs), taxonomy, and
α/β-diversity. These scripts reproduce the steps described in the
Supplementary Methods ("Detection of bacteria and eukaryotes" and
"Bacterial and eukaryotic diversity").

## Raw data
Raw paired-end MiSeq reads are deposited at the DNA Data Bank of Japan
(DDBJ), BioProject **PRJDB043178**. Download the reads and place each
sample's FASTQ files in a `reads/` folder next to the `02_...` script
before running.

## Software / references
- **QIIME2 2021.4** — sequence import, cutadapt (primer removal),
  DADA2 (denoise/merge, paired-end, no length truncation),
  classify-sklearn (taxonomy).
- **QIIME2 2022.11** — 16S α/β-diversity metrics only.
- Reference database: **SILVA 132** (99% OTUs), with reference reads
  extracted for each primer pair.
- Classifier: **naïve Bayes** (`fit-classifier-naive-bayes` →
  `classify-sklearn`).

## Primers
- 16S V3–V4: 341F `CCTACGGGNGGCWGCAG` / 805R `GACTACHVGGGTATCTAATCC`
- 18S V4: Euk454F `CCAGCASCYGCGGTAATTCC` / Euk964R `ACTTTCGTTCTTGATYRA`

## Contents
```
16S/
  01_qiime2_clasifier_prep_16S_V3V4.sh        build the V3–V4 classifier from SILVA 132
  02_qiime2_pipeline_16S_V3V4_re.sh           import → cutadapt → DADA2 → taxonomy → filtering
  03_qiime2_16S_pipeline_diversity_analysis.sh α/β-diversity (sampling depth 5000)
18S/
  01_qiime2_clasifier_prep_18S_V4.sh          build the V4 (Euk454F/Euk964R) classifier from SILVA 132
  02_qiime2_pipeline_18S_V4.sh                import → cutadapt → DADA2 → taxonomy → filtering
  03_qiime2_18S_pipeline_diversity_analysis.sh α/β-diversity (sampling depth 50)
sample-metadata.tsv                           per-sample attributes (QIIME2 format)
```

## Run order (per amplicon)
1. `01_...clasifier_prep...` — once, to build the SILVA 132 classifier.
2. `02_...pipeline...` — `reads/` → `table.qza`, taxonomy, filtered tables
   (features with <10 total reads and mitochondria/chloroplast/Archaea/
   Mammalia are removed).
3. `03_...diversity...` — α- and β-diversity.

## Metadata — `sample-metadata.tsv`
132 samples (72 seagrass / 60 non-seagrass). Columns:

| column | meaning |
|---|---|
| `sample-id` | sample identifier (matches the FASTQ sample names) |
| `Habitat` | `seagrass` or `non` |
| `Seagrass` | `1` (seagrass) / `0` (non) — numeric coding used downstream (CLR/SEM) |
| `Site` | Hakata, Noto, Tokyo-HK, Tokyo-KC, Okayama-G, Okayama-K, Kitsuki, Saiki |
| `Region` | A, B, C, D |
| `RegionName` | A = Sea of Japan, B = Pacific Ocean, C = Seto Inland Sea, D = Bungo Channel |

The `--m-metadata-column` arguments in the diversity scripts refer to
grouping variables; set them to the relevant column above
(e.g. `Habitat`, `Region`, or `Site`).

## Downstream
The filtered count tables produced here feed the analyses in the main
repository (feature selection, precision-matrix networks, symbolic
regression / SEM, and the figure/table bundles).

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# CODA-Lasso 可視化フルコード（棒グラフ順heatmap追加版）
# 使用例:
# python3.10 CODA-Lasso_graph_full_bar_heatmap_sorted.py coda_lasso_selected_taxa.csv

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# CODA-Lasso 可視化フルコード（棒グラフ順heatmap追加版）
# 使用例:
# python3.10 CODA-Lasso_graph_full_bar_heatmap_sorted.py coda_lasso_selected_taxa.csv

import sys
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import networkx as nx

# -----------------------------
# 入力引数チェック
# -----------------------------
if len(sys.argv) != 2:
    print("Usage: python CODA-Lasso_graph_full_bar_heatmap_sorted.py CODA-Lasso.csv")
    sys.exit(1)

input_csv = sys.argv[1]

# -----------------------------
# 出力フォルダ作成
# -----------------------------
output_folder = "CODA_Lasso_figures"
os.makedirs(output_folder, exist_ok=True)

# -----------------------------
# CSV読み込み
# -----------------------------
df = pd.read_csv(input_csv)
df = df.set_index("taxon")

if 'log_contrast_coef' not in df.columns:
    raise ValueError("CSVに 'log_contrast_coef' 列がありません。")

# -----------------------------
# 色設定関数（棒グラフ用）
# -----------------------------
def get_bar_colors(values):
    return ['#2ca02c' if v > 0 else '#d62728' for v in values]  # 緑/赤系

colors = get_bar_colors(df['log_contrast_coef'])

# -----------------------------
# 棒グラフ用データを係数順にソート
# -----------------------------
df_sorted = df.sort_values("log_contrast_coef", ascending=True)

# -----------------------------
# 1. 元の棒グラフ（枠付き）
# -----------------------------
fig, ax = plt.subplots(figsize=(10, max(6, len(df_sorted)/3)))
ax.barh(df_sorted.index, df_sorted["log_contrast_coef"], color=colors, edgecolor="black")
ax.set_xlabel("Log-contrast coefficient")
ax.set_ylabel("Taxa")
ax.set_title("CODA-LASSO log-contrast coefficients (Original)")
ax.axvline(0, color="black", linewidth=0.8)
plt.tight_layout()
for fmt in ["png", "pdf"]:
    plt.savefig(os.path.join(output_folder, f"barplot_original.{fmt}"), dpi=300)
plt.close()

# -----------------------------
# 2. R風改良版（枠なし・目盛り外向き）
# -----------------------------
fig, ax = plt.subplots(figsize=(12, max(6, len(df_sorted)/3)))
ax.barh(df_sorted.index, df_sorted["log_contrast_coef"], color=colors, edgecolor="none")
ax.set_xlabel("Log-contrast coefficient")
ax.set_ylabel("Taxa")
ax.set_title("CODA-LASSO log-contrast coefficients (R-style, no bar edge)")
ax.axvline(0, color="black", linewidth=0.8)

# 枠線を消す
for spine in ['top', 'right', 'left', 'bottom']:
    ax.spines[spine].set_visible(False)

# 目盛りを外向き
ax.tick_params(axis='x', which='both', direction='out', length=6, top=True, bottom=True)
ax.tick_params(axis='y', which='both', direction='out', length=6, left=True, right=True)

plt.subplots_adjust(left=0.3, right=0.95, top=0.9, bottom=0.2)
for fmt in ["png", "pdf"]:
    plt.savefig(os.path.join(output_folder, f"barplot_rstyle.{fmt}"), dpi=300)
plt.close()

# -----------------------------
# 3. ヒートマップ（X軸: taxa, 棒グラフ順、重複なし）
# -----------------------------
plt.figure(figsize=(10, 8))
ax = sns.heatmap(df_sorted[['log_contrast_coef']].T, annot=True, cmap="PiYG", center=0,
                 xticklabels=df_sorted.index, yticklabels=True)
plt.title("CODA-LASSO Coefficients Heatmap (X-axis taxa, sorted)")
plt.xlabel("Taxa")
plt.ylabel("Log-contrast coefficient")
plt.subplots_adjust(left=0.2, right=0.95, top=0.9, bottom=0.25)
for fmt in ["png", "pdf"]:
    plt.savefig(os.path.join(output_folder, f"heatmap_xaxis_sorted.{fmt}"), dpi=300)
plt.close()

# -----------------------------
# 4. ヒートマップ（Y軸: taxa, 棒グラフ順、正が上、重複なし）
# -----------------------------
plt.figure(figsize=(8, max(6, len(df_sorted)/3)))
# データとラベルを上下反転
df_rev = df_sorted.iloc[::-1]
ax = sns.heatmap(df_rev[['log_contrast_coef']], annot=True, cmap="PiYG", center=0,
                 yticklabels=df_rev.index)
plt.title("CODA-LASSO Coefficients Heatmap (Y-axis taxa, sorted, positive on top)")
plt.xlabel("Log-contrast coefficient")
plt.ylabel("Taxa")
plt.subplots_adjust(left=0.25, right=0.95, top=0.9, bottom=0.2)
for fmt in ["png", "pdf"]:
    plt.savefig(os.path.join(output_folder, f"heatmap_yaxis_sorted.{fmt}"), dpi=300)
plt.close()

# -----------------------------
# 5. ネットワーク図（ノードのみ）
# -----------------------------
G = nx.Graph()
for idx, row in df.iterrows():
    G.add_node(idx, coef=row['log_contrast_coef'], color='green' if row['log_contrast_coef']>0 else 'pink')

colors = [G.nodes[n]['color'] for n in G.nodes()]
sizes = [max(abs(G.nodes[n]['coef'])*500, 50) for n in G.nodes()]

plt.figure(figsize=(12,12))
pos = nx.spring_layout(G, seed=42)
nx.draw(G, pos, with_labels=True, node_color=colors, node_size=sizes, font_size=10)
plt.title("CODA-LASSO Network (Nodes only)")
for fmt in ["png", "pdf"]:
    plt.savefig(os.path.join(output_folder, f"network.{fmt}"), dpi=300)
plt.close()

# -----------------------------
# 完了メッセージ
# -----------------------------
print("=== 完了 ===")
print("出力先フォルダ:", output_folder)
print("可視化taxa数:", len(df))

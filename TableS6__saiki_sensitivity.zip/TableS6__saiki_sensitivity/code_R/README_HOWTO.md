# Phase 6d — portable scripts (run on any PC)

これらは元の sem_stage_g_phase6d_*.R を「パス自動解決」に書き換えたものです。
解析の中身（aovp による Seagrass×Region 交互作用の順列検定）は一切変えていません。
結果は元スクリプトと一致します（順列検定なので小数末尾のみ乱数で揺れます）。

## 使い方（各条件とも共通）

1. 条件ごとに1つのフォルダを作る（例：完全除外/ , seed2/ など）
2. そのフォルダに、次の3つを置く：
   - スクリプト本体（下表）
   - 入力CLRデータCSV（下表）
   - phase5c_full_fit.csv  ← その条件のモデルプール
3. ターミナルでそのフォルダに入り、スクリプトを実行：

   Rscript sem_stage_g_phase6d_seed2.R

   → スクリプトは「自分が置かれたフォルダ」を自動的に基準にします。
     もう絶対パスの書き換えは不要です。どのPC・どのユーザーでも動きます。

## 条件とファイルの対応

| 条件        | スクリプト                          | 入力データCSV                                              |
|-------------|-------------------------------------|------------------------------------------------------------|
| 完全除外    | sem_stage_g_phase6d_non_saiki.R     | New_seagrass_CLR_region_site_Chem_with_SR_non_saiki.csv    |
| sub-samp 1  | sem_stage_g_phase6d_seed1.R         | balanced_seed01.csv                                        |
| sub-samp 2  | sem_stage_g_phase6d_seed2.R         | balanced_seed02.csv                                        |
| sub-samp 3  | sem_stage_g_phase6d_seed3.R         | balanced_seed03.csv                                        |

どの条件も phase5c_full_fit.csv（その条件のプール）を同じフォルダに置いてください。

## 入力ファイル名が違う場合（任意）
コマンドライン引数で上書きもできます：
   Rscript sem_stage_g_phase6d_seed2.R  /path/to/data.csv  /path/to/phase5c_full_fit.csv

## 出力
同じフォルダに phase6d_per_variable.csv と phase6d_universality.csv を書き出します。
本文 Table S6 の interaction_p は phase6d_per_variable.csv の該当行です。

## 注意
- seed1 の入力CSVは balanced_seed01.csv を想定しています。実ファイル名が
  異なる場合は、スクリプト冒頭の DATA_NAME を1行直すか、上記の引数指定で渡してください。
- プール読み込みの基準は gfi>=0.95, agfi>=0.90, wrmr<=1.0（元のまま）。
  AGFI=0.90 は感度分析用に緩めた値で、本文の主基準(AGFI>=0.95)とは別です。

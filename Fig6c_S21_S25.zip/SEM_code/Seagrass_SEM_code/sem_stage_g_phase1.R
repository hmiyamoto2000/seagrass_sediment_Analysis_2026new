#!/usr/bin/env Rscript
# Stage gamma Phase 1: 132 SR pair minimal SEM
# model: Seagrass ~ SR1_chem + SR2_biome   (WLSMV, ordered="Seagrass")
suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tibble); library(purrr); library(stringr)
  library(lavaan); library(furrr); library(future)
})

ROOT    <- "/Fig6"
DATA_IN <- file.path(ROOT, "New_seagrass_CLR_region_site_Chem_with_SR.csv")
OUT_CSV <- file.path(ROOT, "phase1_sr_pair_results.csv")

dat <- read_csv(DATA_IN, show_col_types = FALSE)
cat(sprintf("[Phase1] Loaded: %d rows x %d cols\n", nrow(dat), ncol(dat)))

sr_cols  <- grep("^SR_", names(dat), value = TRUE)
chem_srs <- sort(sr_cols[str_detect(sr_cols, "^SR_chem_")])
biome_srs<- sort(sr_cols[str_detect(sr_cols, "^SR_biome_")])
pairs <- expand.grid(sr1 = chem_srs, sr2 = biome_srs, stringsAsFactors = FALSE)
cat(sprintf("[Phase1] Pairs: %d chem x %d biome = %d\n",
            length(chem_srs), length(biome_srs), nrow(pairs)))

fit_one <- function(sr1, sr2, dat) {
  d <- dat; d$.SR1 <- d[[sr1]]; d$.SR2 <- d[[sr2]]
  mod <- "Seagrass ~ .SR1 + .SR2"
  res <- tryCatch({
    fit <- lavaan::sem(mod, data = d, ordered = "Seagrass",
                       estimator = "WLSMV", se = "robust")
    fm  <- lavaan::fitMeasures(fit, c("chisq.scaled","df","pvalue.scaled",
                                      "cfi.scaled","tli.scaled",
                                      "rmsea.scaled","srmr"))
    pe  <- lavaan::parameterEstimates(fit, standardized = TRUE)
    b1  <- pe[pe$lhs=="Seagrass" & pe$op=="~" & pe$rhs==".SR1", ]
    b2  <- pe[pe$lhs=="Seagrass" & pe$op=="~" & pe$rhs==".SR2", ]
    tibble(sr1 = sr1, sr2 = sr2,
           converged = lavaan::lavInspect(fit, "converged"),
           chisq = unname(fm["chisq.scaled"]), df = unname(fm["df"]),
           pvalue = unname(fm["pvalue.scaled"]),
           cfi = unname(fm["cfi.scaled"]), tli = unname(fm["tli.scaled"]),
           rmsea = unname(fm["rmsea.scaled"]), srmr = unname(fm["srmr"]),
           sr1_std = b1$std.all[1], sr1_p = b1$pvalue[1],
           sr2_std = b2$std.all[1], sr2_p = b2$pvalue[1],
           error = NA_character_)
  }, error = function(e) {
    tibble(sr1=sr1, sr2=sr2, converged=FALSE, chisq=NA, df=NA, pvalue=NA,
           cfi=NA, tli=NA, rmsea=NA, srmr=NA,
           sr1_std=NA, sr1_p=NA, sr2_std=NA, sr2_p=NA,
           error=conditionMessage(e))
  })
  res
}

plan(multisession, workers = 24)
cat("[Phase1] Fitting 132 SEMs with furrr 24 workers...\n")
t0 <- Sys.time()
results <- future_map2_dfr(pairs$sr1, pairs$sr2,
             ~ fit_one(.x, .y, dat),
             .options = furrr_options(seed = TRUE),
             .progress = TRUE)
cat(sprintf("[Phase1] Done in %.1f sec\n", as.numeric(Sys.time()-t0, units="secs")))

results <- results %>% arrange(desc(pvalue), srmr)
write_csv(results, OUT_CSV)
cat("[Phase1] Wrote -> ", OUT_CSV, "\n", sep="")
cat(sprintf("[Phase1] Converged: %d/%d   Errors: %d\n",
            sum(results$converged, na.rm=TRUE), nrow(results),
            sum(!is.na(results$error))))

cat("\n[Phase1] Top 10 by pvalue (both paths SIG preferred):\n")
print(results %>%
        filter(converged, !is.na(pvalue)) %>%
        slice_head(n=10) %>%
        select(sr1, sr2, pvalue, cfi, tli, rmsea, srmr, sr1_std, sr1_p, sr2_std, sr2_p),
      width = Inf)

cat("\n=== Phase 1 complete ===\n")

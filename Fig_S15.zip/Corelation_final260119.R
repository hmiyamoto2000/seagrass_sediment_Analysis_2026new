

par(mfrow = c(1, 1))
par(mar = c(5, 4, 4, 2) + 0.1)

library(reshape2)
library(grid)
library(lattice)
library(corrplot)
library(shiny)
library(RColorBrewer)
library(RCurl)
library(PerformanceAnalytics)
library(ggcorrplot)
library(Hmisc)

r_p=read.csv("causal_learning_data_seagrass_CLR260115new.csv")

r=r_p[,-1]
dim(r)

mcor <- cor(r,method="spearman")

symnum(mcor)

res <- rcorr(as.matrix(r), type = "spearman")

mcor <- res$r
pval <- res$P

library(RColorBrewer)
col1 <- colorRampPalette(brewer.pal(11, "RdBu"))

# PDF ファイル名とサイズ（インチ）指定
pdf("corrplot_full.pdf", width = 10, height = 10)

corrplot(mcor,
         col = colorRampPalette(c("blue","white","red"))(100),
         tl.col = "black")

dev.off()  # デバイスを閉じる

#upper
pdf("corrplot_upper.pdf", width = 10, height = 10)
corrplot(mcor, type="upper", tl.col="black",tl.cex=1.0, tl.srt=45)
dev.off()

#lower
pdf("corrplot_lower.pdf", width = 10, height = 10)
corrplot(mcor, type="lower", tl.col="black",tl.cex=1.0, tl.srt=45)
dev.off()

#lower_col1
pdf("corrplot_lower_col1.pdf", width = 10, height = 10)
corrplot(mcor, type="lower", tl.col="black",tl.cex=1.0, tl.srt=45,col = col1(100))
dev.off()

#アスタリスクで有意差表記
corrplot(mcor,
         method = "color",
         col = col1(100),
         tl.col = "black",
         tl.cex = 1.0,
         tl.srt = 45,
         p.mat = pval,
         sig.level = 0.05,
         insig = "pch",      # 非有意のところに記号
         pch = "*",
         pch.cex = 0.8       # アスタリスクの大きさ
)



cor_vals <- mcor[upper.tri(mcor)]
summary(cor_vals)
summary(abs(cor_vals))

table(
  cut(abs(cor_vals),
      breaks = c(0, 0.2, 0.4, 0.6, 0.8, 1),
      labels = c("<0.2", "0.2–0.4", "0.4–0.6", "0.6–0.8", ">0.8"))
)

cor_df <- data.frame(correlation = cor_vals)
write.csv(cor_df, "pairwise_spearman_correlations_CLR.csv", row.names = FALSE)

flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = colnames(cormat)[col(cormat)[ut]],
    cor = cormat[ut],
    p = pmat[ut]
  )
}

flat <- flattenCorrMatrix(mcor, pval)

strong <- subset(flat, abs(cor) >= 0.4 & p < 0.05)

write.csv(strong,
          "strong_significant_correlations_CLR.csv",
          row.names = FALSE)

#png出力

# PNG ファイル名とサイズ・dpi指定
png("corrplot_full.png", width = 10, height = 10, units = "in", res = 300)
corrplot(mcor,
         col = colorRampPalette(c("blue","white","red"))(100),
         tl.col = "black")
dev.off()

png("corrplot_upper.png", width = 10, height = 10, units = "in", res = 300)
corrplot(mcor, type="upper", tl.col="black", tl.cex=1.0, tl.srt=45)
dev.off()

png("corrplot_lower.png", width = 10, height = 10, units = "in", res = 300)
corrplot(mcor, type="lower", tl.col="black", tl.cex=1.0, tl.srt=45)
dev.off()

png("corrplot_lower_col1.png", width = 10, height = 10, units = "in", res = 300)
col1 <- colorRampPalette(brewer.pal(11, "RdBu"))
corrplot(mcor, type="lower", tl.col="black", tl.cex=1.0, tl.srt=45, col = col1(100))
dev.off()

#全相関ペア数：190
#|r| ≥ 0.4：23（約12%) 無視できない総関数　→ promax

#| |r| ≥ 0.4 の割合 | 判断 |
#  |---|---|
#  | < 5% | varimax でも可 |
#  | 5–10% | 要注意 |
#  | >10% | promax 推奨 |
#  | >20% | 斜交必須 |
  
#seagrass_CLR: Among 190 pairwise Spearman correlations, 23 pairs (12.1%) showed moderate to strong correlations (|ρ| ≥ 0.4), indicating non-negligible inter-variable associations. Therefore, an oblique rotation (promax) was adopted rather than an orthogonal rotation.
#====================================================

#カラーパレット使用
col1 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "white", "cyan", 
                           "#007FFF", "blue", "#00007F"))
col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", 
                           "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061"))
col3 <- colorRampPalette(c("red", "white", "blue"))
col4 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "#7FFF7F", 
                           "cyan", "#007FFF", "blue", "#00007F"))
library(corrplot)

# col1 を使う場合
corrplot(mcor,
         col = col1(100),   # <- ここで呼び出し
         tl.col = "black",
         tl.cex = 1.0,
         tl.srt = 45)

# col2 を使う場合
corrplot(mcor,
         col = col2(100),
         tl.col = "black")

# col3 を使う場合（赤-白-青）
corrplot(mcor,
         col = col3(100),
         tl.col = "black")

# col4 を使う場合
corrplot(mcor,
         col = col4(100),
         tl.col = "black")


#==================================


# 必要パッケージ
library(corrplot)
library(RColorBrewer)

# --- データ準備 ---
data_incomplete <- data  # 元データ保存
data <- data[complete.cases(data), ]  # 欠損値を除去

method <- "spearman"  # 相関の種類
mat <- cor(data, method = method)  # 相関行列

# --- 各ペアの p 値行列を作成 ---
cor.mtest <- function(mat, method) {
  mat <- as.matrix(mat)
  n <- ncol(mat)
  p.mat <- matrix(NA, n, n)
  diag(p.mat) <- 0
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      tmp <- cor.test(mat[, i], mat[, j], method = method)
      p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
    }
  }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  p.mat
}

p.mat <- cor.mtest(data, method = method)

# --- カラーパレット定義 ---
col1 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "white", 
                           "cyan", "#007FFF", "blue", "#00007F"))
col2 <- colorRampPalette(c("#67001F", "#B2182B", "#D6604D", "#F4A582", "#FDDBC7", 
                           "#FFFFFF", "#D1E5F0", "#92C5DE", "#4393C3", "#2166AC", "#053061"))
col3 <- colorRampPalette(c("red", "white", "blue"))
col4 <- colorRampPalette(c("#7F0000", "red", "#FF7F00", "yellow", "#7FFF7F", 
                           "cyan", "#007FFF", "blue", "#00007F"))

palette_list <- list(col1=col1, col2=col2, col3=col3, col4=col4)

# --- 出力設定 ---
pdf_width <- 10
pdf_height <- 10
png_width <- 10
png_height <- 10
png_res <- 300

# オプション
number.font <- 2
number.cex <- 0.7
mar <- c(0,0,1,0)
type <- "full"
order <- "hclust"
tl.srt <- 45
sig.level <- 0.05
diag <- FALSE

# --- 描画と保存 ---
for (pal_name in names(palette_list)) {
  pal_func <- palette_list[[pal_name]]
  
  # PDF
  pdf_file <- paste0("corrplot_", pal_name, ".pdf")
  pdf(pdf_file, width=pdf_width, height=pdf_height)
  corrplot(mat,
           method = "color",
           col = pal_func(200),
           number.font = number.font,
           mar = mar,
           number.cex = number.cex,
           type = type,
           order = order,
           addCoef.col = "black",
           tl.col = "black",
           tl.srt = tl.srt,
           p.mat = p.mat,
           sig.level = sig.level,
           insig = "blank",
           diag = diag)
  dev.off()
  
  # PNG 300dpi
  png_file <- paste0("corrplot_", pal_name, ".png")
  png(png_file, width=png_width, height=png_height, units="in", res=png_res)
  corrplot(mat,
           method = "color",
           col = pal_func(200),
           number.font = number.font,
           mar = mar,
           number.cex = number.cex,
           type = type,
           order = order,
           addCoef.col = "black",
           tl.col = "black",
           tl.srt = tl.srt,
           p.mat = p.mat,
           sig.level = sig.level,
           insig = "blank",
           diag = diag)
  dev.off()
}


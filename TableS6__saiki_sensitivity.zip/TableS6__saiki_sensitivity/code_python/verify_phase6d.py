#!/usr/bin/env python3
"""
Independent Python verification of the Saiki site-balance sensitivity analysis
(Supplementary Table S6).

This reproduces, with an independent implementation and language, the
Seagrass x Region interaction p-values computed in R (sem_stage_g_phase6d_*.R,
lmPerm::aovp). The interaction p-value is computed per variable directly from
the CLR-transformed data, so it does NOT require the SEM model pool
(phase5c_full_fit.csv) -- only the per-condition data CSV.

Method: permutation test of the Seagrass:Region interaction term using the
Freedman-Lane procedure (permute residuals of the additive reduced model),
which is an independent permutation scheme from R's lmPerm. Agreement in the
0.05 decision and approximate magnitude confirms the result is not an artefact
of one particular permutation implementation.

Usage:
    python3 verify_phase6d.py <target_folder> [--nperm 4999] [--seed 1]

<target_folder> is a condition folder containing the CLR data CSV, e.g.
    python3 verify_phase6d.py /path/to/R_Table_S6/seed2

Results are printed and also written to <target_folder>/verify_phase6d_python.csv.

The script auto-detects the data file in the folder:
  - New_seagrass_CLR_region_site_Chem_with_SR_non_saiki.csv  (complete exclusion)
  - balanced_seed0*.csv                                       (sub-sampling)
  - otherwise: the single *.csv that contains Seagrass + Region + the hub columns
"""
import sys, os, glob, argparse
import numpy as np
import pandas as pd

HUBS = ["B_Desulfobulbaceae", "E_Corallinophycidae",
        "E_Intramacronucleata", "E_Diatomea"]

def find_data_csv(folder):
    # priority patterns
    pats = ["*non_saiki*.csv", "balanced_seed*.csv",
            "New_seagrass_CLR*with_SR.csv", "*.csv"]
    seen = []
    for p in pats:
        for f in sorted(glob.glob(os.path.join(folder, p))):
            if f in seen:
                continue
            seen.append(f)
            try:
                cols = pd.read_csv(f, nrows=0).columns
            except Exception:
                continue
            if "Seagrass" in cols and "Region" in cols and any(h in cols for h in HUBS):
                return f
    raise FileNotFoundError(
        f"No suitable data CSV (with Seagrass, Region and hub columns) found in {folder}")

def design(df, formula_full=True):
    import patsy
    rhs = "C(Seagrass)*C(Region)" if formula_full else "C(Seagrass)+C(Region)"
    return np.asarray(patsy.dmatrix(rhs, df, return_type="dataframe"))

def ssr(X, y):
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X @ beta
    return float(r @ r)

def interaction_perm_p(df, v, nperm=4999, seed=1):
    d = df[[v, "Seagrass", "Region"]].rename(columns={v: "y"}).copy()
    d["Seagrass"] = d["Seagrass"].astype(str)
    d["Region"] = d["Region"].astype(str)
    y = d["y"].to_numpy(float)
    if np.nanstd(y) == 0:
        return None, "zero-sd overall", None
    reg_sd = d.groupby("Region")["y"].std().fillna(0)
    zero_reg = bool((reg_sd == 0).any())
    Xf = design(d, True)
    Xr = design(d, False)
    beta_r, *_ = np.linalg.lstsq(Xr, y, rcond=None)
    fitted = Xr @ beta_r
    res = y - fitted
    ss_obs = ssr(Xr, y) - ssr(Xf, y)
    rng = np.random.default_rng(seed)
    n = len(y)
    cnt = 0
    for _ in range(nperm):
        yp = fitted + res[rng.permutation(n)]
        ss = ssr(Xr, yp) - ssr(Xf, yp)
        if ss >= ss_obs - 1e-12:
            cnt += 1
    p = (cnt + 1) / (nperm + 1)
    return p, ("zero-sd-region" if zero_reg else ""), ss_obs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", help="condition folder containing the CLR data CSV")
    ap.add_argument("--nperm", type=int, default=4999)
    ap.add_argument("--seed", type=int, default=1)
    args = ap.parse_args()

    folder = os.path.abspath(args.folder)
    data_csv = find_data_csv(folder)
    df = pd.read_csv(data_csv)
    print(f"[verify] folder   = {folder}")
    print(f"[verify] data CSV = {os.path.basename(data_csv)}  ({len(df)} rows)")
    print(f"[verify] permutations = {args.nperm}, seed = {args.seed}")
    print(f"[verify] method = Freedman-Lane permutation of Seagrass:Region interaction")
    print()
    print(f"{'hub':22s}{'interaction_p':>15s}  note")
    rows = []
    for h in HUBS:
        if h not in df.columns:
            print(f"{h:22s}{'(absent)':>15s}  not a column in this data")
            rows.append({"hub": h, "interaction_p": "", "universal": "",
                         "note": "absent (not a column in this data)",
                         "nperm": args.nperm, "seed": args.seed,
                         "data_file": os.path.basename(data_csv), "n_rows": len(df)})
            continue
        p, note, _ = interaction_perm_p(df, h, nperm=args.nperm, seed=args.seed)
        ps = f"{p:.4f}" if isinstance(p, float) else str(p)
        verdict = ""
        if isinstance(p, float):
            verdict = "universal (p>=0.05)" if p >= 0.05 else "non-universal (p<0.05)"
        print(f"{h:22s}{ps:>15s}  {verdict} {('['+note+']') if note else ''}")
        rows.append({"hub": h,
                     "interaction_p": (round(p, 4) if isinstance(p, float) else ""),
                     "universal": ("" if not isinstance(p, float) else ("yes" if p >= 0.05 else "no")),
                     "note": note, "nperm": args.nperm, "seed": args.seed,
                     "data_file": os.path.basename(data_csv), "n_rows": len(df)})
    out_csv = os.path.join(folder, "verify_phase6d_python.csv")
    pd.DataFrame(rows, columns=["hub", "interaction_p", "universal", "note",
                                "nperm", "seed", "data_file", "n_rows"]).to_csv(out_csv, index=False)
    print()
    print(f"[verify] wrote -> {out_csv}")

if __name__ == "__main__":
    main()

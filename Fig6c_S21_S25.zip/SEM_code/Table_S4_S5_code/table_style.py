"""
table_style.py
==============
Shared style and rendering helpers for Supplementary Tables S4 and S5,
matching the Nature-style minimalist convention used in Tables S1-S3
(white background, horizontal rules only, Arial sans-serif).
"""
from __future__ import annotations

import matplotlib as mpl

# ----------------------------------------------------------------------
# Global rcParams — call apply_style() once at module entry.
# ----------------------------------------------------------------------
def apply_style() -> None:
    mpl.rcParams.update({
        "font.family":     "Helvetica",
        "pdf.fonttype":    42,
        "ps.fonttype":     42,
        "savefig.dpi":     300,
        "axes.linewidth":  0.5,
    })


# ----------------------------------------------------------------------
# Palette and dimensions
# ----------------------------------------------------------------------
TEXT       = "#000000"
RULE_HEAVY = "#000000"   # outer horizontal rules
RULE_LIGHT = "#888888"   # optional sub-rules (unused in current layout)

A4_W, A4_H = 11.69, 8.27   # landscape A4 in inches


# ----------------------------------------------------------------------
# Minimalist table renderer
# ----------------------------------------------------------------------
def draw_table(
    ax, *,
    x0: float, y_top: float,
    col_widths: list[float],
    headers: list[str],
    rows: list[list],
    body_align: list[str] | None = None,
    row_height: float = 0.024,
    header_height: float = 0.028,
    header_fontsize: float = 8.0,
    body_fontsize: float = 7.5,
    header_weights: list[str] | None = None,
) -> float:
    """Draw a Nature-style minimalist table.
    Layout: top rule → header row → header bottom rule → body rows → bottom rule.
    No vertical rules, no cell fills.
    Returns the y-coordinate of the bottom rule.

    header_weights : optional per-column font weight ("bold" or "normal").
        Defaults to all "bold". Useful for distinguishing specific
        highlighted columns (e.g. SEM main-hub variables) within an
        otherwise uniformly-weighted header row by setting the others
        to "normal".
    """
    n_cols = len(col_widths)
    if body_align is None:
        body_align = ["center"] * n_cols
    if header_weights is None:
        header_weights = ["bold"] * n_cols
    total_width = sum(col_widths)

    # Column x-positions (left edges)
    col_x = [x0]
    for w in col_widths:
        col_x.append(col_x[-1] + w)

    # ---- Top rule ----
    ax.plot([x0, x0 + total_width], [y_top, y_top],
            color=RULE_HEAVY, lw=0.7, transform=ax.transAxes,
            solid_capstyle="butt")

    # ---- Header row ----
    hdr_bottom = y_top - header_height
    for j, h_text in enumerate(headers):
        cx = col_x[j]
        w  = col_widths[j]
        ha = body_align[j]
        tx = cx + (0.005 if ha == "left"
                    else (w - 0.005 if ha == "right" else w / 2))
        ax.text(tx, hdr_bottom + header_height / 2, h_text,
                ha=ha, va="center",
                fontsize=header_fontsize, fontweight=header_weights[j],
                color=TEXT, transform=ax.transAxes)

    # ---- Sub-rule beneath header ----
    ax.plot([x0, x0 + total_width], [hdr_bottom, hdr_bottom],
            color=RULE_HEAVY, lw=0.4, transform=ax.transAxes,
            solid_capstyle="butt")

    # ---- Body rows ----
    cy = hdr_bottom
    for row in rows:
        cy -= row_height
        for j, val in enumerate(row):
            cx = col_x[j]
            w  = col_widths[j]
            ha = body_align[j]
            tx = cx + (0.005 if ha == "left"
                        else (w - 0.005 if ha == "right" else w / 2))
            txt = "" if val is None or (isinstance(val, str) and val == "") \
                  else str(val)
            ax.text(tx, cy + row_height / 2, txt,
                    ha=ha, va="center",
                    fontsize=body_fontsize, color=TEXT,
                    transform=ax.transAxes)

    # ---- Bottom rule ----
    ax.plot([x0, x0 + total_width], [cy, cy],
            color=RULE_HEAVY, lw=0.7, transform=ax.transAxes,
            solid_capstyle="butt")

    return cy
